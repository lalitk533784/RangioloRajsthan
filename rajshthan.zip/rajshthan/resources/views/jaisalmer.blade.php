<!doctype HTML>
 <html lang="en">

<head>
  <title>Jaislarmer</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   

</head>

<body>
  <header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
    
  <main>
    <div class="container-fluid front" style="background-image: url(https://cdn1.tripoto.com/media/filter/tst/img/1807984/Image/1574356381_jaisalmerfort_tripoto.jpg);">
      <h1 class="home"> JAISALMER </h1>
      <h3 class="home1">THE GOLDEN CITY</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>Jodhpur</h1>
          <h2>The Golden City</h2>
          </div>
          <div class="conte">
            <P>
                Jaisalmer, often referred to as the "Golden City," holds a significant position as the guardian of the western frontier of Rajasthan, and indeed, India. Situated in close proximity to the Pakistan border and the vast Thar Desert, it boasts a unique geographical location. The city's most iconic landmark is the Jaisalmer Fort, also known as Sonar Qila or the Golden Fort. Unlike many other forts in India that are primarily tourist attractions, Jaisalmer Fort is a bustling living fort that houses shops, hotels, and ancient havelis (traditional homes) where generations of families continue to reside.
            </P>
            <P>
                The history of Jaisalmer dates back to the 12th century when Rawal Jaisal, the eldest heir of the Rawal of Deoraj, was denied the throne of Lodurva in favor of his younger half-brother. Seeking a new capital, Rawal Jaisal encountered the sage Eesul, who revealed Krishna's prophecy stating that a descendant of his Yaduvanshi clan would establish a kingdom at the very same location. In 1156, Rawal Jaisal constructed a mud fort, naming it Jaisalmer after himself, and declared it as his capital.
            </P>
            <P>
                Jaisalmer's rich history, combined with its geological marvels and architectural splendor, makes it an enchanting destination for travelers. Exploring the Wood Fossil Park and immersing oneself in the living heritage of Jaisalmer Fort are experiences that offer a glimpse into the city's captivating past and vibrant present.
            </P>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN JAISALMER
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://www.rajasthandirect.com/wp-content/uploads/2012/11/Jaisalmer-Fort.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="jaisalmerfort">JAISALMER FORT</h1></li>
                                        <li><p>Jaisalmer Fort, also known as Sonar Qila or the Golden Fort, is an iconic landmark in Jaisalmer, Rajasthan, India. It is a living fort, unlike many other forts in the country, with shops, hotels, and ancient havelis (homes) still inhabited by generations of families. Built in 1156 AD by Rawal Jaisal, the fort's golden sandstone walls rise majestically against the backdrop of the Thar Desert, captivating visitors with its architectural beauty and historical significance.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.tripsavvy.com/thmb/Auovh9uxC0WSdBUc9GInz4kePN0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Jaisalmer_War_Museum-1584bdb6b29d4c6f89f0a121fb12cc8e.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="jaisalmergovernmentmuseum"> JAISALMER GOVERNMENT MUSEUM</h1></li>
                                        <li><p>Jaisalmer Government Museum showcases an extensive collection of artifacts representing the rich cultural heritage of Jaisalmer. Located within the majestic Jaisalmer Fort, the museum exhibits a diverse range of historical items, including coins, weapons, artwork, manuscripts, and fossils. It offers visitors a fascinating insight into the history, art, and traditions of the region. The Jaisalmer Government Museum serves as a valuable resource for preserving and promoting the cultural legacy of Jaisalmer, attracting history enthusiasts and curious travelers alike.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/palaces-to-visit/JAISALMER003.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="jaisalmerwarmuseum"> JAISALMER WAR MUSEUM</h1></li>
                                  <li><p>Jaisalmer War Museum is a significant attraction located in Jaisalmer, Rajasthan, India. The museum pays tribute to the bravery and sacrifices of the Indian armed forces, particularly during the Indo-Pak wars fought in the region. It showcases a vast collection of war artifacts, including weapons, uniforms, and documents, providing visitors with insights into the military history of the area. Jaisalmer War Museum serves as a solemn reminder of the valor displayed by the Indian armed forces.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.activeindiatours.com/cdn/in-public/amar_sagar_lake.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="amarsagarlake">AMAR SAGAR LAKE</h1></li>
                                  <li><p>Amar Sagar Lake is a picturesque artificial lake located near Jaisalmer in Rajasthan, India. Constructed in the 17th century by Maharaja Amar Singh, it offers a serene and tranquil atmosphere amidst the arid desert landscape. The lake is surrounded by magnificent cenotaphs, temples, and a beautifully carved pavilion known as Amar Sagar Jain Temple. With its peaceful ambiance and architectural marvels, Amar Sagar Lake is a popular tourist attraction, captivating visitors with its charm and historical significance.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://thumbs.dreamstime.com/b/ancient-temple-ruins-gadi-sagar-gadisar-lake-jaisalmer-rajasthan-sunset-gadisar-lake-jaisalmer-rajasthan-ancient-179620661.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="gadisarlake">GADISAR LAKE</h1></li>
                                <li><p>Gadisar Lake is a serene and historic water reservoir located in Jaisalmer, Rajasthan, India. Built in the 14th century, it served as a crucial water source for the city. Surrounded by temples, shrines, and ghats, the lake offers a picturesque setting for visitors to enjoy boating and witness stunning sunsets. The intricately carved entrance gateway and chattris (cenotaphs) add to the charm of Gadisar Lake, making it a popular tourist attraction in Jaisalmer.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://rajasthanstudio.com/wp-content/uploads/2022/02/d1-1-1024x576.jpeg" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="desertnationalpark">DESERT NATIONAL PARK</h1></li>
                                <li><p>The Desert National Park is a protected area located in Rajasthan, India. Spanning approximately 3,162 square kilometers, it is renowned for its unique ecosystem and biodiversity. The park showcases the Thar Desert's diverse flora and fauna, including rare and endangered species such as the Great Indian Bustard. Visitors can explore the vast sand dunes, rocky terrain, and observe wildlife in their natural habitat. The Desert National Park offers a remarkable opportunity to experience the enchanting desert landscape and its fascinating wildlife.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://www.themaharajaexpress.org/blog/wp-content/uploads/2018/07/Akal-Wood-Fossil-Park.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="akalwoodfossilpark">AKAL WOOD FOSSIL PARK</h1></li>
                            <li><p>The Akal Wood Fossil Park is located approximately 15 kilometers from Jaisalmer, Rajasthan. It showcases geologic remnants and tragedies that occurred in the Thar Desert around 180 million years ago. The park offers visitors a unique opportunity to explore and trace the ancient history of the region through fossilized wood specimens. With its intriguing displays and geological significance, the Akal Wood Fossil Park is a must-visit destination for those interested in geology and the fascinating natural history of the area.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.mapofholiday.com/wp-content/uploads/2023/03/35620639300_fb525df70c_b-1-min.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="ramdevratemple">RAMDEVRA TEMPLE</h1></li>
                            <li><p>Ramdevra Temple, located in the village of Ramdevra in Rajasthan, India, is a significant pilgrimage site dedicated to the folk deity Baba Ramdevji. The temple is believed to be the final resting place of Baba Ramdevji, a revered saint known for his miracles and devotion. Devotees from various faiths visit the temple to seek blessings and offer prayers. The annual Ramdevra Fair, held in his honor, attracts a large number of devotees who participate in religious rituals and cultural festivities.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                          <li> <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/07/ae/8c/f4/tanot-mata-temple.jpg?w=1200&h=-1&s=1" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="tanotmatatemple">TANOT MATA TEMPLE</h1></li>
                        <li><p>Tanot Mata Temple is a renowned Hindu temple located in the Western Rajasthan region of India. Situated near the India-Pakistan border, the temple is dedicated to Goddess Tanot Mata, considered a manifestation of the divine feminine power. The temple holds immense religious significance and is believed to have divine protection, with legends recounting miraculous events during the Indo-Pakistani war of 1965. Tanot Mata Temple attracts devotees and tourists who seek blessings and witness the sacred aura surrounding this holy place.</p></li>
                            </div>
                       
                    </ul>
                    <ul>
                      <li> <img src="https://static2.tripoto.com/media/filter/tst/img/1621497/TripDocument/1607598782_img_20201018_112340.jpg"  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="laungewalawarmemorial">LAUNGEWALA WAR MEMORIAL</h1></li>
                        <li><p>The Laungewala War Memorial commemorates the heroic Battle of Laungewala during the Indo-Pakistani War of 1971. Located in the Thar Desert near Tanot, Rajasthan, India, the memorial pays tribute to the Indian Army's valiant defense against a much larger Pakistani force. The battle witnessed exceptional bravery and resilience, and the memorial stands as a reminder of the sacrifices made by the Indian soldiers who defended the nation's borders with unwavering determination.</p></li>
                        </div>
                       
                    </ul> 

                </div>







                <div class="list">
                  <ul>
                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/140.jpg" alt=""  class="c"></li>
                      <div class="paragraph">
                  <li><h1 id="mandirpalace">MANDIR PALACE</h1></li>
                  <li><p>Mandir Palace, located in Jaisalmer, Rajasthan, is a stunning heritage hotel that showcases the architectural beauty of the region. Built in the 19th century, the palace was initially a lavish residence for the rulers of Jaisalmer. Today, it stands as a testament to the opulence and grandeur of the past, offering guests a unique blend of luxury and history. The intricate carvings, exquisite artwork, and regal ambiance make Mandir Palace a captivating destination for travelers seeking a royal experience.</p></li>
                      </div>
                 
              </ul>
              <ul>
                <li> <img src="https://static.toiimg.com/photo/msid-26048178,width-96,height-65.cms"  class="c"></li>
                  <div class="paragraph">
                  <li><h1 id="nathmaljikihaveli">NATHMAL JI KI HAVELI</h1></li>
                  <li><p>Nathmal Ji Ki Haveli is a renowned architectural marvel located in Jaisalmer, Rajasthan, India. Built in the 19th century by two brothers, Hathi and Lulu, it is a splendid example of Rajasthani craftsmanship. The haveli showcases intricate stone carvings, exquisite balconies, and delicate jharokhas (overhanging enclosed balconies). The symmetrical design of the haveli is said to have been created by the two brothers independently, resulting in a captivating blend of artistic finesse and unique architectural charm.</p></li>
                  </div>
                 
              </ul> 

          </div>




                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                Jaisalmer has the civil airport facility and has direct air connectivity from Jaipur, delhi, mumbai, Banglore and surat in jaislmer.                            </p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Jaisalmer is connected to Jodhpur, Bikaner and Jaipur by bus and taxi.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p> There is a direct train service between Jaisalmer and Delhi, with a few trains connecting the two cities.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/10.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT  JAISALMER</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR JAISALMER</h3>
                    <div class="place">
                    <div><a href="./bikaner"><img src="/rimages/bikaner.jpg" alt="BIKANER"></a>
                    <h4>BIKANER</h4>
                    <p>330KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>265KM</p></div>
                        <div><a href="./udaipur"><img src="/rimages/udaipur.jpg" alt="UDAI"></a>
                        <h4>UDAIPUR</h4>
                        <p>498KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script> -->
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>



<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>

  </html>