<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forts</title>
    <link rel="stylesheet" href="./rcss/main.css">
    <link rel="stylesheet" href="./rcss/navbar.css">
</head>
<style>
     /* .navbar{
            max-height: 40px;
        } */
</style>
<header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
<body>
    <!-- <div id="navbar-placeholder" id="topbar"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#navbar-placeholder").load("navbar");
      });
    </script> -->


    <div class="top-bar">
        <h1>FORTS IN RAJASTHAN</h1>
        <h5>EXPLORE THE SPLENDOUR</h5>
    </div>
    <div class="list">
        <ul>
            <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/101.jpg');">
                    <h1 class="hide-h1">NAHARGARH FORT</h1>
                    <div class="hit">
                    <h2>NAHARGARH FORT</h2>
                    <p>Perched on the Aravalli hills overlooking Jaipur, Nahargarh Fort offers a breathtaking panoramic view of the Pink City. Built in the 18th century, this majestic fort served as a defensive stronghold and a retreat for the royals. With its rugged walls, intricate architecture....</p>
                    <a href="./jaipur#nahargarhfort">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/124.jpg);">
                    <h1 class="hide-h1">JAIGARH FORT</h1>
                    <div class="hit" >
                    <h2>JAIGARH FORT</h2>
                    <p>Jaigarh Fort, situated on the Aravalli hills above Amer Fort in Jaipur, is a magnificent testament to Rajput military prowess. Built in the 18th century, it served as a defensive stronghold and houses impressive structures like the world's largest cannon on wheels, Jaivana...</p>
                    <a href="./jaipur#jaigarhfort">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/155.jpg);">
                    <h1 class="hide-h1">KHEJARLA FORT</h1>
                    <div class="hit">
                    <h2>KHEJARLA FORT</h2>
                    <p>Located 85 kilometres from the main city, the 400-year old Khejarla Fort is situated in a rural setting. The stunning red sandstone monument, now a hotel, is an example of Rajput architecture. Visitors will be mesmerised by the fort's picturesque settings, latticework friezes and intricate Jharokas.....</p>
                    <a href="./jodhpur#khejarlafort">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/132.jpg);">
                    <h1 class="hide-h1">JAISALMER FORT</h1>
                    <div class="hit">
                    <h2>JAISALMER FORT</h2>
                    <p>The Jaisalmer Fort also goes by the name Sonar Quila (Golden Fort) as it rises from the desert itself and seems to become one with the golden hues of the sand. .....</p>
                    <a href="./jaisalmer#jaisalmerfort">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://cdn.wallpapersafari.com/3/42/6iktoV.jpg);">
                    <h1 class="hide-h1">KUMBHALGARH FORT</h1>
                    <div class="hit" >
                    <h2>KUMBHALGARH FORT</h2>
                    <p>Kumbhalgarh Fort, located in Rajasthan, India, is a historic stronghold famous for its massive walls, intricate architecture, and breathtaking views of the surrounding landscape....</p>
                    <a href="./udaipur#kumbhalgarhfort">Explore</a>
                </div>
            </li>
        </ul>
         <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/154.jpg);">
                <h1 class="hide-h1">MEHRANGARH FORT</h1>
                    <div class="hit" >
                    <h2>MEHRANGARH FORT</h2>
                    <p>Rising perpendicular and impregnable from a hill which is 125 metres above Jodhpur’s skyline is the Mehrangarh Fort. This historic fort is one of the most famous in India and is packed with history and legends. Mehrangarh Fort still bears the imprints of cannonball attacks courtesy the armies...</p>
                    <a href="./jodhpur#mehrangarhfort">Explore</a>
                </div>
            </div>


    <div class="list">
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/GWT01.jpg);">
                            <h1 class="hide-h1">TARAGARH FORT</h1>
                            <div class="hit">
                            <h2>TARAGARH FORT</h2>
                            <p>"Taragarh Fort: Majestic Hilltop Citadel in Historic Ajmer, Rajasthan".</p>
                            <a href="./ajmer#taragarhfort">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/KFL01.jpg);">
                            <h1 class="hide-h1">KISHANGARH FORT</h1>
                            <div class="hit" >
                            <h2>KISHANGARH FORT</h2>
                            <p>Kishangarh Fort: Ancient Splendor of Rajasthan's Architectural Heritage.</p>
                            <a href="./ajmer#kishangarhfort">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://res.cloudinary.com/thrillophilia/image/upload/c_fill,dpr_1.0,f_auto,fl_progressive.strip_profile,g_center,h_450,q_auto,w_753/v1/filestore/rbttp51i5uss2zefjctmfsef64sr_original-P0000137559.jpg);">
                            <h1 class="hide-h1">BALA QILA</h1>
                            <div class="hit">
                            <h2>BALA QILA</h2>
                            <p>Bala Qila: Majestic Fortress Overlooking the City's Rich History.</p>
                            <a href="./alwar#balaqila">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/300.jpg);">
                            <h1 class="hide-h1">NEEMRANA FORT</h1>
                            <div class="hit">
                            <h2>NEEMRANA FORT</h2>
                            <p>"Neemrana Fort: Majestic Heritage, Architectural Splendor, Timeless Luxury Retreat".</p>
                            <a href="./alwar#neemranafort">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://c0.wallpaperflare.com/preview/257/531/581/india-bikaner.jpg);">
                            <h1 class="hide-h1">JUNAGARH FORT</h1>
                            <div class="hit" >
                            <h2>JUNAGARH FORT</h2>
                            <p>Junagarh Fort is a historical fort located in Bikaner, Rajasthan, India..</p>
                            <a href="./bikaner#junagarhfort">Explore</a>
                        </div>
                    </li>
                </ul>
                 <ul>
                    <li class="s" style="background-image: url(https://assets-news.housing.com/news/wp-content/uploads/2022/08/13090152/CHITORGARH-FEATURE-compressed.jpg);">
                        <h1 class="hide-h1">CHITTORGARH FORT</h1>
                            <div class="hit" >
                            <h2>CHITTORGARH FORT</h2>
                            <p>
                                The Chittorgarh Fort, often referred to as the "Pride of Rajasthan," holds a rich historical legacy. When considering a title for the fort, one option could be:
                                "Chittorgarh Fort: A Majestic Citadel of Valor and Resilience".</p>
                            <a href="./chittorghar#chittorgarhfort">Explore</a>
                        </div>
                    </div>

                    <div class="list">
                    </ul>

                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/CH536.jpg);">
                                <h1 class="hide-h1">BHAINSRORGARH FORT</h1>
                                <div class="hit">
                                <h2>BHAINSRORGARH FORT</h2>
                                <p>"Bhainsrorgarh Fort: A Timeless Marvel Embracing History's Enchanting Secrets"</p>
                                <a href="./chittorghar#bhainsrorgarhfort">Explore</a>
                                </div>
                        </li>
                    </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.trawell.in/admin/images/upload/080966595Lonavala_Lohagad_Fort_Main.jpg);">
                                    <h1 class="hide-h1">LOHAGARH FORT</h1>
                                    <div class="hit">
                                    <h2>LOHAGARH FORT</h2>
                                    <p>"Lohagarh Fort: The Invincible Citadel Defying Time's Relentless March".</p>
                                    <a href="./bharatpur#lohagarhfort">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        
                     
                         <ul>
                            <li class="s" style="background-image: url(https://www.abumount.com/wp-content/uploads/2023/04/achalgarh-fort.webp);">
                                <h1 class="hide-h1">ACHALGARH FORT</h1>
                                    <div class="hit" >
                                    <h2>ACHALGARH FORT</h2>
                                    <p>"Achalgarh Fort: A Tranquil Sentinel Guarding Legends of the Past"</p>
                                    <a href="./mountabu#achalgarhfort">Explore</a>
                                </div>
                            </div>
              
            </li>
        </ul>
    </div>
   
</body>
<footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>

      
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>
