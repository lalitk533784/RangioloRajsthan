<!doctype HTML>
<html lang="en">

<head>
  <title>Chittorgarh</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   

</head>


 
    <!-- place navbar here -->

    <header>
      <div class="navbaar" id="topbar">
        <div class="nav-top"></div>
      
      <ul class="navbar">
       <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Discover</a>
        <ul class="dropdown-menu">
          <li class="dropdown-submenu">
              <a href="./destination" class="dropdown-toggle">Destination </a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
                <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
                <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
                <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
                <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
                <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
                <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
                <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
                <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
                <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
              </ul>
              </li>
          <li class="dropdown-submenu">
            <a href="./forts" class="dropdown-toggle">Fort</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
              <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
              <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
              <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
              <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
              <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
              <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
              <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
              <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
              <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
              <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
              <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
              <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
              <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
            </ul>
          </li>
          <li class="dropdown-submenu">
            <a href="./lakes" class="dropdown-toggle">Lake</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
              <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
              <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
              <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
              <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
              <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
            </ul>
          </li>
  
  
          <li class="dropdown-submenu">
            <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
              <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
              <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
              <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
              <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
              <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
              <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
              <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
              <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
              <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
            </ul>
          </li>
  
  
          <li class="dropdown-submenu">
            <a href="./place" class="dropdown-toggle">Places</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
              <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
              <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
              <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
              <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
              <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
              <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
              <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
              <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
              <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
              <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
              <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
              <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
              <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
              <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
              <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
              <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
              <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
              <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
              <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
              <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
              <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
              <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
              <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
              <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
              <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
              <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
              <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
              <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
              <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
              <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
              <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
              <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
              <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
              <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
              <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
              
            </ul>
          </li>
          
          <li class="dropdown-submenu">
            <a href="./museum" class="dropdown-toggle">Museum</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
              <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
              <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
              <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
              <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
              <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
              <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
              <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
              <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
              <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
              <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
              <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
              <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
             
            </ul>
          </li>
          <li class="dropdown-submenu">
            <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
              <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
              <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
              <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
              <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
              <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
              <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
              <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
              <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
              <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
              <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
              <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
              <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
              <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
              <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
              <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
              <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
              <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
              <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
              <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
              <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
            </ul>
          </li> 
        </ul>
        
  
  
      </li>
  
  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Experience</a>
        <ul class="dropdown-menu">
           <li class="dropdown-submenu">
              <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
              </li>
              <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
              <a href="./adventures" class="dropdown-toggle">Adventures </a>
        </ul>
      </li>
  
  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Plan</a>
        <ul class="dropdown-menu">
           <li class="dropdown-submenu">
              <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
              </li>
              <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
              <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
        </ul>
      </li>
      
  
      <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
     
    </ul>
    
      <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
    
  </div>
  <script>
      window.addEventListener('DOMContentLoaded', function () {
    var dropdowns = document.getElementsByClassName('dropdown');
    for (var i = 0; i < dropdowns.length; i++) {
      dropdowns[i].addEventListener('mouseover', function () {
        this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
      });
      dropdowns[i].addEventListener('mouseout', function () {
        this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
      });
    }
  });
  
  
  </script>
  </header> 
  <body>
  <main>
    <div class="container-fluid front " style="  background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/banners/desk/Chittorgarh-Fort-banner.png);">
      <h1 class="home"> CHITTORGARH </h1>
      <h3 class="home1">CHITTORGARH FORT</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>CHITTORGARH</h1>
          <h2> THE LAND OF INDIA’S FINEST FORT</h2>
          </div>
          <div class="conte">
           <p>
            Chittorgarh, known for its tales of Rajputana bravery, pride, and passion, is a city steeped in history and legend. Its most iconic structure is the Chittorgarh Fort, perched atop a 180-meter high hill, sprawling across 700 acres. This formidable fort has witnessed turbulent times, enduring three major attacks. In 1303, Sultan Ala-ud-din Khilji of Delhi besieged the fort to capture Queen Padmini, with whom he was infatuated. Almost two centuries later, in 1533, Sultan Bahadur Shah of Gujarat unleashed destruction upon Chittorgarh. Then, in 1568, Mughal Emperor Akbar conquered and seized the fort. It wasn't until 1616, during the reign of Emperor Jahangir, that the fort was eventually returned to the Rajputs. The tales of heroism and resilience associated with Chittorgarh Fort resonate through the narratives passed down by bards, known by people of all ages in the city.
           </p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN CHITTORGARH
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/banners/desk/Chittorgarh-Fort-banner.png" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="chittorgarhfort">CHITTORGARH FORT</h1></li>
                                        <li><p>Chittorgarh Fort, perched atop a 180-meter hill, is a symbol of Rajput valor and heritage in Chittorgarh, Rajasthan, India. Spanning 700 acres, it has witnessed historic battles and sieges, including attacks by Alauddin Khilji, Bahadur Shah, and Akbar. It stands as a testament to the resilience and bravery of the Rajput warriors.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/CH536.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="bhsinsrorgarhfort">BHAINSRORGARH FORT</h1></li>
                                        <li><p>Bhainsrorgarh Fort, situated in Rajasthan, India, is a majestic fortress steeped in history. Perched on a hill overlooking the Chambal River, it offers breathtaking views of the surrounding landscape. The fort has witnessed significant events and stands as a testament to the rich heritage and architectural splendor of the region.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/75.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="fatehprakashpalace">FATEH PRAKASH PALACE (GOVERNMENT MUSEUM)</h1></li>
                                  <li><p>Fateh Prakash Palace, also known as the Government Museum, is a majestic palace-turned-museum located in Udaipur, Rajasthan, India. Built in the 19th century, it showcases a remarkable collection of artifacts, including royal memorabilia, vintage cars, weapons, miniature paintings, and more, providing visitors with a glimpse into the rich cultural heritage of the region.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.rajras.in/wp-content/uploads/2019/11/Bassi-Wildlife-Sanctuary-in-Rajasthan-scaled.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="bassivillageandwildlifesanctuary">BASSI VILLAGE AND WILDLIFE SANCTUARY</h1></li>
                                  <li><p>Bassi village, located in Rajasthan, India, is a charming destination known for its wildlife sanctuary. The Bassi Wildlife Sanctuary is nestled amidst picturesque landscapes and is home to diverse flora and fauna. Visitors can explore the sanctuary, go on nature trails, and spot wildlife like antelopes, birds, and other native species.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Sanvliya-ji-Temple.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="sanwaliyajitemple">SANWALIYA JI TEMPLE</h1></li>
                                <li><p>On the Chittorgarh Udaipur Highway a grand temple of Sanwaliya ji situated in Mandafiya village, where millions of devotees visit every year. According to the local residents, in the year 1840, on the basis of the dream of a shepherd named Bholanath Gurjar, three idols were found in the excavation on the border of Bhadsauda-Bagund village, in which one idol was established on the boundary of Bhadsauda-Bagund village and the temple was constructed is known as Prakatya Sthal. The second idol was installed in Bhadsauda village and the temple was constructed there is the oldest temple. </p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/83.jpg" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="meerabaitemple">MEERABAI TEMPLE</h1></li>
                                <li><p>Meerabai, an ardent devotee of Lord Krishna’s, worshipped him at this temple. The structure is designed in the classic North Indian style of temples. It rises from a raised plinth and its conical roof can be seen from far. The temple houses a beautiful shrine surrounded by an open porch with four small pavilions in four corners.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/72.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="padminipalace">PADMINI'S PALACE</h1></li>
                            <li><p>There is a beautiful palace in the middle of the pond, which is known as 'Padmini palace'. It is believed that Rana Ratan Singh's wife Mahani Padmini was believed to be very beautiful, clever and brave, and this palace was named after her.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/252.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="ratansinghpalace">RATAN SINGH PALACE</h1></li>
                            <li><p>The winter palace of the royal family, it overlooks a small lake. Although fairly rundown now, it is an interesting place to explore and attracts many tourists.</p></li>
                            </div>
                           
                        </ul>
                    </div>


                    <div class="list">
                        <ul>
                          <li> <img src="https://i.ytimg.com/vi/5j6YN_RgsOo/maxresdefault.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="ranakumbhapalace">RANA KUMBHA PALACE</h1></li>
                        <li><p>Rana Kumbha Palace is a majestic architectural marvel located within the Chittorgarh Fort in Rajasthan, India. Constructed by Rana Kumbha, a revered Rajput ruler, the palace showcases intricate craftsmanship and intricate designs. It served as the royal residence and witnessed significant historical events, making it a prominent attraction for history enthusiasts and visitors alike.</p></li>
                            </div>
                        
                    </ul>
                    <ul>
                      <li> <img src="https://i.pinimg.com/originals/0a/c1/72/0ac172952cb6b79d09e065e48c1284d0.jpg" alt=""  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="jaimalandpatta'spalace">JAIMAL AND PATTA’S PALACE</h1></li>
                        <li><p>Jaimal and Patta's Palace, also known as Jaimal Palace and Patta Haveli, is a historic palace located within the premises of the majestic Chittorgarh Fort in Rajasthan, India. These palaces were named after the brave Rajput warriors, Jaimal Rathore and Patta Rathore, who valiantly defended the fort during the siege by Mughal Emperor Akbar in 1568. Today, the palaces stand as a testament to their courage and heroism.</p></li>
                        </div>
                       
                    </ul>
                </div>
                    
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                Nearest Airport Maharana Pratap Airport, Dabok at approx 90 km.</p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Regular buses are available to Chittorgarh from all major cities in Rajasthan.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p>Chittorgarh is connected by rail to and from Udaipur, Ajmer, Jaipur and Delhi.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/7.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT CHITTORGARH</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR CHITTORGARH</h3>
                    <div class="place">
                    <div><a href="./ajmer"><img src="/rimages/29.jpg" alt="PUSHKAR"></a>
                    <h4>AJMER</h4>
                    <p>198KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>320KM</p></div>
                        <div><a href="./udaipur"><img src="/rimages/udaipur.jpg" alt="JODHPUR"></a>
                        <h4>UDAIPUR</h4>
                        <p>115KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>

    
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>