@extends('layouts.app')

@section('content')
<style>
    body{
        background-image: aquamarine;
        background-image: url(https://www.solidbackgrounds.com/images/2560x1440/2560x1440-light-yellow-solid-color-background.jpg);
    }
    .card-header{
        text-align: center;
    }
    .card{
        border-radius: 10px;
        box-shadow: 2px 3px 10px black;
        background-image: url(https://1.bp.blogspot.com/-ScvBLRJ7tF4/XRd4S4QoFOI/AAAAAAAAo5c/20BX-OID694VzAewk72zbradk58axsWoQCLcBGAs/s1600/Rajasthan%2BImages%2BHD%2B8.jpg);
        color: white;
        font-size: 20px;
        background-size: cover;
        background-repeat: no-repeat;
        min-height: 300px;
    }
    .form-control{
        background-color: transparent;
        border-radius: 20px;
        color: white
        ;
    }
    li{
        list-style: none;
       
    }
 
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4" style="display:flex;  justify-content: space-between;">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                                      @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link hii" style=" text-align:center; " href="{{ route('login') }}">{{ __('For Login click here') }}</a>
                                </li>
                            @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
