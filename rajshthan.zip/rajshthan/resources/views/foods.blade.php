<HTML !doctype>
    <html lang="en">
   
   <head>
     <title>Ajmer</title>
     <link rel="stylesheet" href="./rcss/page.css">
     <link rel="stylesheet" href="./rcss/navbar.css">
    
     
      
   
   </head>
   
   <body>
     <header>
       <div class="navbaar" id="topbar">
         <div class="nav-top"></div>
       
       <ul class="navbar">
        <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
       <li class="dropdown">
         <a href="#" class="dropdown-toggle ">Discover</a>
         <ul class="dropdown-menu">
           <li class="dropdown-submenu">
               <a href="./destination" class="dropdown-toggle">Destination </a>
               <ul class="sub-dropdown-menu">
                 <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
                 <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
                 <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
                 <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
                 <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
                 <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
                 <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
                 <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
                 <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
                 <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
               </ul>
               </li>
           <li class="dropdown-submenu">
             <a href="./forts" class="dropdown-toggle">Fort</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
               <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
               <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
               <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
               <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
               <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
               <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
               <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
               <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
               <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
               <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
               <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
               <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
               <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
               <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
             </ul>
           </li>
           <li class="dropdown-submenu">
             <a href="./lakes" class="dropdown-toggle">Lake</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
               <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
               <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
               <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
               <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
               <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
               <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
               <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
               <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
               <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
               <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
             </ul>
           </li>
   
   
           <li class="dropdown-submenu">
             <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
               <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
               <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
               <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
               <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
               <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
               <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
               <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
               <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
               <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
             </ul>
           </li>
   
   
           <li class="dropdown-submenu">
             <a href="./place" class="dropdown-toggle">Places</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
               <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
               <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
               <li><a class="dropdown-item" href="./ajmer#shahidsmarkajmer">Sahid Smark Ajmer</a></li>
               <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
               <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
               <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
               <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
               <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
               <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
               <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
               <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
               <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
               <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
               <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
               <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
               <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
               <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
               <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
               <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
               <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
               <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
               <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
               <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
               <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
               <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
               <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
               <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
               <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
               <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
               <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
               <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
               <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
               <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
               <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
               <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
               <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
               <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
               <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
               
             </ul>
           </li>
           
           <li class="dropdown-submenu">
             <a href="./museum" class="dropdown-toggle">Museum</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
               <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
               <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
               <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
               <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
               <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
               <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
               <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
               <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
               <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
               <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
               <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
               <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
               <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
               <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
               <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
               <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
               <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
               <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
              
             </ul>
           </li>
           <li class="dropdown-submenu">
             <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
             <ul class="sub-dropdown-menu">
               <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
               <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
               <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
               <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
               <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
               <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
               <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
               <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
               <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
               <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
               <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
               <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
               <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
               <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
               <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
               <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
               <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
               <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
               <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
               <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
               <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
               <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
               <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
               <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
               <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
               <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
               <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
               <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
             </ul>
           </li> 
         </ul>
         
   
   
       </li>
   
   
       <li class="dropdown">
         <a href="#" class="dropdown-toggle ">Experience</a>
         <ul class="dropdown-menu">
            <li class="dropdown-submenu">
               <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
               </li>
               <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
               <a href="./adventures" class="dropdown-toggle">Adventures </a>
         </ul>
       </li>
   
   
       <li class="dropdown">
         <a href="#" class="dropdown-toggle ">Plan</a>
         <ul class="dropdown-menu">
            <li class="dropdown-submenu">
               <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
               </li>
               <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
               <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
         </ul>
       </li>
       
   
       <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
       <!-- <li class="dropdown-toggle "><a href="./home">Login</a></li> -->
      
     </ul>
     
       <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
     
   </div>
   <script>
       window.addEventListener('DOMContentLoaded', function () {
     var dropdowns = document.getElementsByClassName('dropdown');
     for (var i = 0; i < dropdowns.length; i++) {
       dropdowns[i].addEventListener('mouseover', function () {
         this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
       });
       dropdowns[i].addEventListener('mouseout', function () {
         this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
       });
     }
   });
   
   
   </script>
   </header>
     <!-- <header> -->
       <!-- place navbar here -->
       <!-- <div id="navbar-placeholder"></div>
       <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <script>
         $(function() {
           $("#navbar-placeholder").load("navbar");
         });
       </script> -->
     <!-- <div id="navbar-placeholder"></div>
   
     <script>
       fetch('navbar')
         .then(response => response.text())
         .then => {
           document.getElementById('navbar-placeholder').innerHTML =;
         });
     </script>
      -->
   
   
   <!-- main -->
     <main>
       <div class="container-fluid front " style="background-image: url(https://ik.imagekit.io/shortpedia/Voices/wp-content/uploads/2021/12/rajasthani-thaali-1200x900@voices.jpg);">
         <h1 class="home"> Foods of Rajasthan </h1>
         <h3 class="home1"></h3>
       </div>
   
       <div class="history">
         <div class="title">
           <h1>Foods of Rajasthan</h1>
             <h2></h2>
             </div>
             <div class="conte">
               <p>
                Rajasthan, a state located in northern India, has a rich culinary tradition that is influenced by its arid climate and the availability of ingredients in the region. Rajasthani cuisine is known for its vibrant flavors and robust dishes. Here are some popular foods of Rajasthan:
               </p>
               </div>
             </div>
   
   
                           <div class="part2">
                               <div class="title2">
                                   <h2>
                                    Rajasthan's Delights: A Royal Feast for Your Taste Buds!
                                   </h2>
                               </div>
                                       <div class="list">
                                           <ul>
                                             <li>
                                             <div> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/dal-bati-churma-1-1024x870.jpg" alt=""  class="c"></div></li>     
                                             <div class="paragraph">
                                           <li><h1 id="#">Dal Bati Churma</h1></li>
                                           <li><p>This iconic Rajasthani dish consists of three components. Dal is a lentil curry with a smoky flavor, Bati is a baked wheat dough dumpling, and Churma is a sweetened crushed wheat dish. The Bati is traditionally cooked in an earthen oven and then dipped in ghee (clarified butter) before being served with dal and churma. It is a wholesome and filling meal.</p></li>
                                             </div>  
                                     </ul>
   
                                       <ul>
                                         <li> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/Rajasthani-Gatte-ki-Sabzi.jpg" alt=""  class="c"></li>
                                           <div class="paragraph">
                                           <li><h1 id="#">Gatte ki Sabzi</h1></li>
                                           <li><p>Gatte ki Sabzi is a popular vegetarian dish in Rajasthan. It consists of gram flour dumplings (gatte) cooked in a spicy yogurt-based gravy. The dumplings are simmered until soft and then served with steamed rice or roti (Indian bread). The tangy and spicy flavors make it a delectable treat.</p></li>
                                           </div>  
                                       </ul>
                                   </div>
   
   
                                   <div class="list">
                                     <ul>
                                       <li>
                                       <div> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/Ker-Sangri-1.jpg" alt=""  class="c"></div></li>     
                                       <div class="paragraph">
                                     <li><h1 id="#">Ker Sangri</h1></li>
                                     <li><p>Ker Sangri is a unique and traditional Rajasthani dish made from dried desert beans (sangri) and dried berries (ker). It is typically cooked with spices, including dried red chili, cumin, and coriander. This dish is a specialty of the arid regions of Rajasthan and is often paired with Bajra Roti (millet bread) or Rice.</p></li>
                                       </div>  
                                     </ul>
   
                                      <ul>
                                       <li> <img src="https://blogger.googleusercontent.com/img/a/AVvXsEh8ljjR7gocweIinyQp_Pu0vbtfTv2dTFwM8tOVt9jpEmiA9HcndVThiKnn7tV-dF5kcUYBtcg8tEoHEkM8uD6lcrrKk4GgOscPZCfl5bejiHENNdp6D3mEKFloijy0ObAvF74AFiw8tq__ZGUGolscVAGiLNMOCugczZjCFK8iyOBIRyOOTXeixPt8bQ=w640-h480" alt=""  class="c"></li>
                                     <div class="paragraph">
                                     <li><h1 id="#">Bajra Roti</h1></li>
                                     <li><p>Bajra Roti is a staple bread in Rajasthan, especially in the rural areas. It is made from Bajra (pearl millet) flour and is traditionally cooked on a hot griddle. The rotis have a rustic flavor and are best enjoyed with a dollop of ghee and a side of curries or chutneys.</p></li>
                                     </div>  
                                 </ul>
                             </div>
   
   
   
                               
   
                               <div class="list">
   
                                   <ul>
                                     <li> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/IMG_9546-1-768x512.jpg" alt=""  class="c"></li>
                                       <div class="paragraph">
                                   <li><h1 id="">Laal Maas</h1></li>
                                   <li><p>Laal Maas is a spicy mutton curry that is popular in Rajasthan. The name "Laal Maas" translates to "Red Meat" in English, referring to its fiery red color. It is prepared with a rich blend of spices, including red chili, garlic, and yogurt. The dish is slow-cooked to perfection, resulting in tender and flavorful meat.</p></li>
                                       </div>
                                   
                               </ul>
   
                               <ul>
                                 <li> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/Pyaz-kachori.jpg" alt="" class="c"></li>
                                   <div class="paragraph">
                                   <li><h1 id="">Pyaaz Kachori</h1></li>
                                   <li><p>Pyaaz Kachori is a popular street food in Rajasthan. It is a deep-fried pastry filled with a spiced onion mixture. The flaky and crispy kachori is often served with tamarind chutney and is a favorite breakfast or tea-time snack among the locals.</p></li>
                                   </div>
                                   
                               </ul>
                           </div>
                           
                           <div class="list">
                               <ul>
                                 <li> <img src="https://crazymasalafood.com/wp-content/images/mohan-mas.jpg.webp" alt=""  class="c"></li>
                                   <div class="paragraph">
                               <li><h1 id="">Mohan Maas</h1></li>
                               <li><p>Mohan Maas is a royal Rajasthani dish known for its indulgent flavors. It is a slow-cooked mutton dish prepared in a rich gravy made from milk, cream, and spices. The dish is sweetened with saffron, cardamom, and rose petals, giving it a distinct aroma and taste.</p></li>
                                   </div>
                               
                           </ul>
                           <ul>
                             <li> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/ghewar-sweet-food_57665-577.jpg" alt=""  class="c"></li>
                               <div class="paragraph">
                               <li><h1 id="">Ghevar</h1></li>
                               <li><p>Ghevar is a popular Rajasthani sweet delicacy that is enjoyed during festivals like Teej and Raksha Bandhan. It is a deep-fried dessert made from a batter of all-purpose flour, ghee, and milk. The crispy and honeycomb-like texture is then soaked in sugar syrup and garnished with dry fruits and silver foil.</p></li>
                               </div>
                              
                           </ul>
                       </div>
                       <div class="list">
                           <ul>
                             <li> <img src="https://www.jaipurstuff.com/wp-content/uploads/2019/09/Mawa_Kachori.jpg" alt=""  class="c"></li>
                               <div class="paragraph">
                           <li><h1 id="">Mawa Kachori</h1></li>
                           <li><p>Mawa Kachori is a sweet variation of the traditional kachori. It is stuffed with a mixture of khoya (reduced milk solids), nuts, and cardamom. The kachori is deep-fried until golden and then dipped in sugar syrup before being served. It is a rich and indulgent dessert loved by locals and tourists alike.</p></li>
                               </div>
                          
                       </ul>
                       <ul>
                         <li> <img src="https://www.sailusfood.com/wp-content/uploads/2014/03/rabdi-recipe.jpg" alt=""  class="c"></li>
                           <div class="paragraph">
                           <li><h1 id="">Rabri</h1></li>
                           <li><p>Rabri is a popular Rajasthani dessert made by reducing milk until it thickens and attains a creamy consistency. It is sweetened with sugar and flavored with cardamom, saffron, and nuts. Rabri is often served chilled and is enjoyed as a refreshing treat, especially during summers.</p></li>
                           </div>
                          
                       </ul> 
                       </div>
                </div>
            </body>
            <footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>

      
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>

            </html>           
   
                   