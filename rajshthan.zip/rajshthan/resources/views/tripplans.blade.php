<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomePage</title>
    <link rel="stylesheet" href="./rcss/navbar.css">
    <link rel="stylesheet" href="./rcss/main.css">
</head>
<style>



.list1{
    display: grid;
    grid-template-columns: 38% 62%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid red; */
    
}
.list2{
    display: grid;
    grid-template-columns: 34% 33% 33%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid black; */
    
}
.view{
  margin-top: 50px;
  border: 1px solid orange;
}

.st {
    /* background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/101.jpg'); */
    background-repeat: no-repeat;
    background-size: cover;
    /* border-radius: 20px; */
}

.list1>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed green; */
    /* margin: 0; */
}
.list2>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed gold; */
}

 .list1>ul:nth-child(2) .hit1{
    background-color: gold
} 
.list2>ul:nth-child(1) .hit1{
    background-color: rgb(153, 255, 0)
}
.list2>:nth-child(2) .hit1{
    background-color: rgb(143, 145, 151)
}
.list2>ul:nth-child(3) .hit1{
    background-color:rgb(255, 0, 200)
}

.list1>ul>li h1 {
    color: white;
    padding-top: 80px;
}
.list2>ul>li h1 {
    color: white;
    padding-top: 80px;
}

.hit1 {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: hsl(0, 97%, 64%);
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    transition: all 0.2s ease;
    /* border-radius: 20px; */
}
.hit1>p,h2{
    margin-bottom: 20px;
    /* font-family: Arial, Helvetica, sans-serif; */
    font-style: italic;
    font-variant: small-caps;
}

.hit1>a {
    color: #000;
    text-decoration: none;
    background-color: #5dd5e7;
    padding: 10px 20px;
    border-radius: 10px;
}
.hide-h1:hover{
    display: none;
}

.list1>ul>li:hover .hit1{
    display: flex;
}
.list2>ul>li:hover .hit1{
    display: flex;
}
.exraj{
  text-align: center;
          background-image: url(./orange-star-img.png),url(./orange-star-img.png);
          background-repeat: no-repeat,no-repeat;
          background-position:0 0.35em, right 0.35em;
          /* background-size: 20px auto 20px auto; */
          /* border: 2px solid black; */
          width: 50%;
          margin: auto;
          font-size: 50px;
          margin-top: 4%;
          text-shadow:2px 2px 2px goldenrod;
}



</style>
  <header class="nnavbar">
  <div class="navbaar" id="topbar">
    <div class="nav-top"></div>
  
  <ul class="navbar">
   <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Discover</a>
    <ul class="dropdown-menu">
      <li class="dropdown-submenu">
          <a href="./destination" class="dropdown-toggle">Destination </a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
            <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
            <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
            <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
            <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
            <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
            <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
            <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
            <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
          </ul>
          </li>
      <li class="dropdown-submenu">
        <a href="./forts" class="dropdown-toggle">Fort</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
          <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
          <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
          <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
          <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./lakes" class="dropdown-toggle">Lake</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
          <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
          <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
          <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
          <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./place" class="dropdown-toggle">Places</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
          <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
          <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
          <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
          <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
          <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
          <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
          <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
          <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
          <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
          <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
          <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
          <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
          <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
          <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
          <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
          <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
          <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
          <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
          <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
          <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
          <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
          <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
          <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
          <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
          
        </ul>
      </li>
      
      <li class="dropdown-submenu">
        <a href="./museum" class="dropdown-toggle">Museum</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
          <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
          <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
          <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
          <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
          <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
          <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
         
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
          <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
          <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
          <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
          <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
          <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
          <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
          <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
          <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
          <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
          <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
          <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
          <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
          <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
          <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
        </ul>
      </li> 
    </ul>
    


  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Experience</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
          <a href="./adventures" class="dropdown-toggle">Adventures </a>
    </ul>
  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Plan</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
          </li>
          <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
          <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
    </ul>
  </li>
  

  <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>

  <!-- <li><button id="changeColorButton">Change Color</button></li> -->

</ul>

  <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->

</div>
<script>
  window.addEventListener('DOMContentLoaded', function () {
var dropdowns = document.getElementsByClassName('dropdown');
for (var i = 0; i < dropdowns.length; i++) {
  dropdowns[i].addEventListener('mouseover', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
  });
  dropdowns[i].addEventListener('mouseout', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
  });
}
});




 
  // const changeColorButton = document.getElementById('changeColorButton');

  
  // changeColorButton.addEventListener('click', function() {
 
  //   document.body.style.backgroundColor = ' #ceec74';

   
  //   const navbar = document.querySelector('.navbar');
  //   navbar.style.backgroundColor = ' #ceec74';

  //   const navtop=document.querySelector('.nav-top');
  //   navtop.style.backgroundColor=' #ceec74';
    
  //   const footer = document.querySelector('.foot');
  //   footer.style.backgroundColor = ' #ceec74';
  // });







</script>
</header>
<body>
    
      
    
       <h1 class="exraj">TRIP PLANS</h1>       


    <div class="view">
      <div class="list1">
        <ul style="background-color: rgb(255, 204, 127);">
            <h2 style="margin-top: 40px; color: orangered;">RAJSTHAN</h2>
            <h3>The Land Of Maharaj's</h3>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://1.bp.blogspot.com/-MdTqkXrjMIg/XXeRzDGV3mI/AAAAAAAAAAQ/s3QFO7DvZ-kXPPJHabE2viEay5QEl-MWQCLcBGAs/s1600/images.jpg);">
                    <h1 class="hide-h1"></h1>
                    <div class="hit1" >
                    <h2>10 DAYS  TRIP PLAN</h2>
                    <p>In a 10-day trip, you can visit Jaipur, Udaipur, Jaisalmer, Jodhpur, Alwar, Bikaner, Mount Abu, Ajmer, Bharatpur, and Chittorgarh.</p>
                    <a href="/bookingform">BOOK</a>
                    </div>
            </li>
        </ul>
        </div>
        <div class="list2">

        <ul>
            <li class="st" style="background-image: url(https://d3d5bpai12ti8.cloudfront.net/wp-content/uploads/20200911134852/Rajasthan-Approves-New-Tourism-Policy-With-Focus-On-Lesser-known-Destinations.jpg);">
                    <h1 class="hide-h1"></h1>
                    <div class="hit1">
                    <h2>7-8 DAYS TRIP PLAN</h2>
                    <p>In a 7-8 day trip, you can explore Jaipur, Udaipur, Jaisalmer, Jodhpur, Bikaner, Mount Abu, and Chittorgarh in Rajasthan.</p>
                    <a href="/bookingform">BOOK</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://th.bing.com/th/id/OIP.y9YywPH4yFmwI2ErcG_MSgHaE8?w=206&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7);">
                    <h1 class="hide-h1"></h1>
                    <div class="hit1">
                    <h2>5-6 DAYS TRIP PLAN</h2>
                    <p>In a 5-6 day trip, you can discover Jaipur, Udaipur, Jaisalmer, Jodhpur, Mount Abu, and Chittorgarh in Rajasthan.</p>
                    <a href="/bookingform">BOOK</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://th.bing.com/th/id/OIP.GAzQyIuBEP03wMD6uGULvwHaDt?w=350&h=175&c=7&r=0&o=5&dpr=1.5&pid=1.7);">
                    <h1 class="hide-h1"></h1>
                    <div class="hit1" >
                    <h2>1-3 DAYS TRIP PLAN</h2>
                    <p>In a 1-3 day trip, you can visit Jaipur, the capital city of Rajasthan, known for its magnificent palaces and vibrant culture.</p>
                    <a href="/bookingform">BOOK</a>
                </div>
            </li>
        </ul>
         <ul>
            </div>
    </div>
        
</body>

</html>







