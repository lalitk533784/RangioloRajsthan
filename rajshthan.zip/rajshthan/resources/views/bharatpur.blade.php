<!doctype HTML>
 <html lang="en">

<head>
  <title>Bharatpur</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   

</head>

<body>
  <header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
  <!-- <header> -->
    <!-- place navbar here -->

    <!-- <div id="navbar-placeholder"></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(function() {
    $("#navbar-placeholder").load("navbar");
  });
</script> -->
   
  <main>
    <div class="container-fluid front " style="  background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/banners/desk/7.jpg);">
      <h1 class="home"> BHARATPUR </h1>
      <h3 class="home1">KEOLADEO GHANA NATIONAL PARK</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>BHARATPUR</h1>
          <h2>WORLD’S MOST FASCINATING BIRD RESERVE</h2>
          </div>
          <div class="conte">
            <p>
                Bharatpur, with a history dating back to the 5th century BC, was once the prosperous kingdom of Matsya. According to legends, the city's name is derived from Bharat, the younger brother of Lord Ram, with Laxman, the other brother, revered as the family deity of Bharatpur's ruling family. Maharaja Suraj Mal, in the early 18th century, captured the fort and established Bharatpur as a kingdom by defeating Khemkaran, a rival chieftain. Known for his vision of expansion, Maharaja Suraj Mal constructed numerous forts and palaces, including the magnificent Pleasure Palace Complex at Deeg.
            </p>
            <p>
                Bharatpur's Keoladeo Ghana National Park, also called the Bharatpur Bird Sanctuary, is a renowned bird watching destination. The park's creation can be traced back 250 years when the ruler built embankments to transform the area into a marsh. Spanning 29 square kilometers, this man-made wetland is home to a diverse range of migratory birds, including ducks, geese, raptors, flycatchers, and more. During the winter season, bird enthusiasts and ornithologists visit the park to observe and study the fascinating avian species. With over 370 recorded species, the park has also been a habitat for the Siberian crane and is recognized as a UNESCO World Heritage Site.
            </p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN BHARATPUR
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/248.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="lohagarhfort">LOHAGARH FORT</h1></li>
                                        <li><p>Lohagarh Fort, also known as the Iron Fort, is a formidable historic fortress located in Bharatpur, Rajasthan, India. Built in the 18th century, it earned its name for its impregnable structure that withstood numerous attacks. Lohagarh Fort symbolizes the indomitable spirit and strength of the rulers of Bharatpur.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/244.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="bharatpurpalaceandmuseum">BHARATPUR PALACE AND MUSEUM</h1></li>
                                        <li><p>Located within the premises of the Bharatpur Palace is Kamra Khas, a museum that contains a vast number of antiques, over 581 stone sculptures, 861 local art and craft wares and ancient scriptures that depict the art and culture typical of Bharatpur. The palace itself was built in stages by various Maharajas and is a fine fusion of Mughal and Rajput architecture. The various apartments in the palace have a variety of richly patterned floor tiles decorated with exquisite designs.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/247.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="keoladeoghananationalpark">KEOLADEO GHANA NATIONAL PARK</h1></li>
                                  <li><p>Every year, thousands of migratory waterfowl birds such as green sandpiper and cranes visit the park during winter. It was created in mid 18th century as a small reservoir located 5 kilometres to the southeast of Bharatpur. The construction of the Ajan Bund (dam) and the subsequent flooding of this natural depression led to one of the world’s most fascinating and spectacular bird reserves. The Keoladeo Ghana National Park is considered to be one of the richest bird areas in the world today.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/251.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="bandbaretha">BAND BARETHA</h1></li>
                                  <li><p>Band Baretha is an old wildlife reserve of the rulers of Bharatpur, currently under the administration of the Forest Department. The construction of the dam on Kakund River was started by Maharaj Jaswant Singh in 1866 AD and completed by Maharaj Ram Singh in 1897 AD. The palace inside the reserve was built by Maharaj Kishan Singh and is the private property of the Bharatpur royal family.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/245.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="gangamandir">GANGA MANDIR</h1></li>
                                <li><p>The Ganga Mandir, which resides in the heart of the city of Bharatpur is one of the most beautiful temples in Rajasthan. In it lies the magnificent deity of Ganga Maharaj made of pristine white marble. Maharaja Balwant Singh started constructing this temple in the mid-19th century. However, he had a very unique request that required all the affluent inhabitants of the city to donate one month’s pay to help towards the temple’s creation.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/laxman-mandir01.jpg" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="laxmanmandir">LAXMAN MANDIR</h1></li>
                                <li><p>This temple is dedicated to Laxman, brother of Lord Rama, and is famous for its typical Rajasthani style of architecture and beautiful pink stonework. Visitors will enjoy the intricate carvings of flowers and birds on doorways, ceilings, pillars, walls and arches.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/250.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="deeg">DEEG</h1></li>
                            <li><p>Deeg is a beautiful garden town situated north of Bharatpur. It has many embellished palaces that add to the beauty of the place. Known for its forts, palaces, gardens and fountains, the highlight of Deeg is an impressive fort surrounded by moats and gateways. It was built by Raja Suraj Mal and stands over a slightly elevated point. Although the interiors are almost in ruins, the watch tower containing a gun still maintains watch over the city.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/252.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="kaman">KAMAN</h1></li>
                            <li><p>The locals also know Kaman as Kamaban. This old town is located at the north of Bharatpur and is a part of the Brij area where Lord Krishna spent his early years. It is a place of pilgrimage and is annually visited by a large number of Vaishnavs in the month of Bhadhva as a part of the Banyatara. The ruins of a temple / mosque consisting of 84 pillars named Chaurasi Khamba are the main attraction.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                The closest airport is Agra and is about 56 kms away.</p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>A network of buses links Bharatpur with several cities within and outside the State.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p>Bharatpur is on the Delhi-Mumbai broad gauge line. It is well-connected to Sawai Madhopur, Kota and Agra.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/16.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT BHARATPUR</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR BHARATPUR</h3>
                    <div class="place">
                    <div><a href="./ajmer"><img src="/rimages/29.jpg" alt="AJMER"></a>
                    <h4>AJMER</h4>
                    <p>318KM</p></div>
                    <div><a href="./alwar"><img src="/rimages/alwar.jpg" alt="ALWAR"></a>
                        <h4>ALWAR</h4>
                        <p>103KM</p></div>
                        <div><a href="./jaipur"><img src="/rimages/jaipur.jpg" alt="JODHPUR"></a>
                        <h4>JAIPUR</h4>
                        <p>185KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>
    
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>