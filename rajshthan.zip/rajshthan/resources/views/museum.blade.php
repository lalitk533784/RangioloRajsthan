<!DOCTYPE HTML>
 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Museum</title>
    <link rel="stylesheet" href="./rcss/main.css">
    <link rel="stylesheet" href="./rcss/navbar.css">
    <!-- <link rel="stylesheet" href="/css/navbar.css"> -->
</head>
<style>
     /* .navbar{
            max-height: 40px;
        } */
</style>
<header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
<body>
   


    <div class="top-bar">
        <h1>MUSEUMS IN RAJASTHAN</h1>
        <h5>EXPLORE THE SPLENDOUR</h5>
    </div>
    <div class="list">
        <ul>
            <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/ajmer-gov-museum.jpg');">
                    <h1 class="hide-h1">AJMER GOVERNMENT MUSEUM</h1>
                    <div class="hit">
                    <h2>AJMER GOVERNMENT MUSEUM</h2>
                    <p>"Ajmer Government Museum: Unveiling the Cultural Tapestry of History".</p>
                    <a href="./ajmer#ajmergovernmentmuseum">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Alwar-museum.jpg);">
                    <h1 class="hide-h1">GOVERNMENT MUSEUM ALWAR</h1>
                    <div class="hit" >
                    <h2>GOVERNMENT MUSEUM ALWAR</h2>
                    <p>"Government Museum Alwar: Delving into the Treasures of Heritage and Art".</p>
                    <a href="./alwar#governmentmuseumalwar">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.holidify.com/images/cmsuploads/compressed/4610568192_a1331097b8_b_20190116144720.jpg);">
                    <h1 class="hide-h1">BHARATPUR PALACE AND MUSEUM</h1>
                    <div class="hit">
                    <h2>BHARATPUR PALACE AND MUSEUM</h2>
                    <p>"Bharatpur Palace and Museum: A Regal Abode Preserving History's Splendor".</p>
                    <a href="./bharatpur#bharatpurpalaceandmuseum">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://lalgarh-palace-bikaner.booked.net/data/Photos/OriginalPhoto/2935/293591/293591224/Lallgarh-Palace-Hotel-Bikaner-Exterior.JPEG);">
                    <h1 class="hide-h1">LALGARH PALACE AND MUSEUM</h1>
                    <div class="hit">
                    <h2>LALGARH PALACE AND MUSEUM</h2>
                    <p>"Lalgarh Palace and Museum: Where Royalty Meets Cultural Splendor".</p>
                    <a href="./bikaner#lalgarhpalaceandmuseum">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/39.jpg);">
                    <h1 class="hide-h1">GANGA GOVERNMENT MUSEUM</h1>
                    <div class="hit" >
                    <h2>GANGA GOVERNMENT MUSEUM</h2>
                    <p>"Ganga Government Museum: Exploring the Vibrant Heritage of the Region".</p>
                    <a href=".//bikaner#gangagovernmentmuseum">Explore</a>
                </div>
            </li>
        </ul>
         <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/41.jpg);">
                <h1 class="hide-h1">PRACHINA MUSEUM</h1>
                    <div class="hit" >
                    <h2>PRACHINA MUSEUM</h2>
                    <p>"Prachina Museum: Journeying through Time to Embrace Traditional Elegance".</p>
                    <a href="./bikaner#prachinamuseum">Explore</a>
                </div>
            </div>


    <div class="list">
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/75.jpg);">
                            <h1 class="hide-h1">FATEH PRAKASH PALACE (GOVERNMENT MUSEUM)</h1>
                            <div class="hit">
                            <h2>FATEH PRAKASH PALACE (GOVERNMENT MUSEUM)</h2>
                            <p>"Fateh Prakash Palace (Government Museum): Reliving the Glorious Tales of Rajput Heritage".</p>
                            <a href="./chittorghar#fatehprakashpalace">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Rajasthan_Vidhansabha.png);">
                            <h1 class="hide-h1">MUSEUM ON POLITICAL NARRATIVES</h1>
                            <div class="hit" >
                            <h2>MUSEUM ON POLITICAL NARRATIVES</h2>
                            <p>"Narrative Museum: Unveiling the Power of Political Stories"</p>
                            <a href="./jaipur#museumonpoliticalnarratives">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/museum-legacies.jpg);">
                            <h1 class="hide-h1">MUSEUM OF LEGACIES</h1>
                            <div class="hit">
                            <h2>MUSEUM OF LEGACIES</h2>
                            <p>"Museum of Legacies: Preserving the Stories that Shape Our History".</p>
                            <a href="./jaipur#museumoflegacies">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Amrapali-museum.jpg);">
                            <h1 class="hide-h1">AMRAPALI MUSEUM</h1>
                            <div class="hit">
                            <h2>AMRAPALI MUSEUM</h2>
                            <p>"Amrapali Museum: Celebrating the Timeless Beauty of Indian Artistry".</p>
                            <a href="./jaipur#amrapalimuseum">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/museum-of-gem-and-jewellery-jaipur.jpg);">
                            <h1 class="hide-h1">MUSEUM OF GEM AND JEWELLERY</h1>
                            <div class="hit" >
                            <h2>MUSEUM OF GEM AND JEWELLERY</h2>
                            <p>"Museum of Gems and Jewellery: A Dazzling Journey into Precious Treasures".</p>
                            <a href="./jaipur#museumofgemandjewellery">Explore</a>
                        </div>
                    </li>
                </ul>
                 <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/J540.jpg);">
                        <h1 class="hide-h1">JAIPUR WAX MUSEUM</h1>
                            <div class="hit" >
                            <h2>JAIPUR WAX MUSEUM</h2>
                            <p>"Jaipur Wax Museum: Immersive Encounters with Wax Figures and History"</p>
                            <a href="./jaipur#jaipurwaxmuseum">Explore</a>
                        </div>
                    </div>


                    <div class="list">
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/115.jpg);">
                                    <h1 class="hide-h1">ANOKHI MUSEUM OF HAND PRINTING</h1>
                                    <div class="hit">
                                    <h2>ANOKHI MUSEUM OF HAND PRINTING</h2>
                                    <p>"Anokhi Museum of Hand Printing: Celebrating the Artistry of Traditional Textiles".</p>
                                    <a href="./jaipur#anokhimuseumofhandprinting">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/110.jpg);">
                                    <h1 class="hide-h1">ALBERT HALL MUSEUM</h1>
                                    <div class="hit" >
                                    <h2>ALBERT HALL MUSEUM</h2>
                                    <p>"Albert Hall Museum: Discovering the Tapestry of Rajasthan's Cultural Heritage"</p>
                                    <a href="./jaipur#alberthallmuseum">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/133.jpg);">
                                    <h1 class="hide-h1">JAISALMER GOVERNMENT MUSEUM</h1>
                                    <div class="hit">
                                    <h2>JAISALMER GOVERNMENT MUSEUM</h2>
                                    <p>"Jaisalmer Government Museum: Unveiling the Rich History of the Golden City"</p>
                                    <a href="./jaisalmer#jaisalmergovernmentmuseum">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/JAISALMERWAR002.jpg);">
                                    <h1 class="hide-h1">JAISALMER WAR MUSEUM</h1>
                                    <div class="hit">
                                    <h2>JAISALMER WAR MUSEUM</h2>
                                    <p>"Jaisalmer War Museum: Honoring Valor and Sacrifice on the Sands of Rajasthan".</p>
                                    <a href="./jaisalmer#jaisalmerwarmuseum">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/163.jpg);">
                                    <h1 class="hide-h1">JODHPUR GOVERNMENT MUSEUM</h1>
                                    <div class="hit" >
                                    <h2>JODHPUR GOVERNMENT MUSEUM</h2>
                                    <p>"Jodhpur Government Museum: Immersing in the Royal Legacy of Marwar".</p>
                                    <a href="./jodhpur#jodhpurgovernmentmuseum">Explore</a>
                                </div>
                            </li>
                        </ul>
                         <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/mehrangarh-fort-and-museum.jpg);">
                                <h1 class="hide-h1">MEHRANGARH FORT AND MUSEUM</h1>
                                    <div class="hit" >
                                    <h2>MEHRANGARH FORT AND MUSEUM</h2>
                                    <p>"Mehrangarh Fort and Museum: A Majestic Citadel Unveiling Centuries of History"</p>
                                    <a href="./jodhpur#mehrangarhfortandmuseum">Explore</a>
                                </div>
                            </div>
        

                    <div class="list">
                    </ul>

                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/225.jpg);">
                                <h1 class="hide-h1">AHAR MUSEUM</h1>
                                <div class="hit">
                                <h2>AHAR MUSEUM</h2>
                                <p>"Ahar Museum: Tracing the Glorious Past of Mewar's Archaeological Heritage"</p>
                                <a href="udaipur#aharmuseum">Explore</a>
                                </div>
                        </li>
                    </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/others/UD383.jpg);">
                                    <h1 class="hide-h1">WAX MUSEUM</h1>
                                    <div class="hit">
                                    <h2>WAX MUSEUM</h2>
                                    <p>"Wax Museum: Lifelike Encounters with Historical Icons and Celebrities".</p>
                                    <a href="./udaipur#waxmuseum">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                     
                         <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/VCC568.jpg);">
                                <h1 class="hide-h1">VINTAGE CAR COLLECTION</h1>
                                    <div class="hit" >
                                    <h2>VINTAGE CAR COLLECTION</h2>
                                    <p>"Vintage Car Collection: Exploring the Timeless Beauty of Classic Automobiles"</p>
                                    <a href="./udaipur#vintagecarcollection">Explore</a>
                                </div>
                            </div>
              
            </li>
        </ul>
    </div>
   
</body>
<footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>
