<!doctype HTML>
<html lang="en">

<head>
  <title>Udaipur</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
 
</head>
<header>
  <div class="navbaar" id="topbar">
    <div class="nav-top"></div>
  
  <ul class="navbar">
   <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Discover</a>
    <ul class="dropdown-menu">
      <li class="dropdown-submenu">
          <a href="./destination" class="dropdown-toggle">Destination </a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
            <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
            <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
            <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
            <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
            <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
            <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
            <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
            <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
          </ul>
          </li>
      <li class="dropdown-submenu">
        <a href="./forts" class="dropdown-toggle">Fort</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
          <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
          <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
          <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
          <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./lakes" class="dropdown-toggle">Lake</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
          <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
          <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
          <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
          <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./place" class="dropdown-toggle">Places</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
          <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
          <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
          <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
          <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
          <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
          <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
          <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
          <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
          <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
          <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
          <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
          <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
          <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
          <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
          <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
          <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
          <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
          <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
          <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
          <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
          <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
          <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
          <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
          <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
          
        </ul>
      </li>
      
      <li class="dropdown-submenu">
        <a href="./museum" class="dropdown-toggle">Museum</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
          <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
          <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
          <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
          <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
          <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
          <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
         
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
          <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
          <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
          <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
          <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
          <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
          <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
          <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
          <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
          <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
          <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
          <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
          <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
          <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
          <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
        </ul>
      </li> 
    </ul>
    


  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Experience</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
          <a href="./adventures" class="dropdown-toggle">Adventures </a>
    </ul>
  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Plan</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
          </li>
          <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
          <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
    </ul>
  </li>
  

  <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
 
</ul>

  <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->

</div>
<script>
  window.addEventListener('DOMContentLoaded', function () {
var dropdowns = document.getElementsByClassName('dropdown');
for (var i = 0; i < dropdowns.length; i++) {
  dropdowns[i].addEventListener('mouseover', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
  });
  dropdowns[i].addEventListener('mouseout', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
  });
}
});


</script>
</header>
<body>

    <!-- place navbar here -->
    <!-- <div id="navbar-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#navbar-placeholder").load("navbar");
      });
    </script> -->
  <main>
    <div class="container-fluid front " style="  background-image: url(https://i.pinimg.com/originals/70/7f/92/707f922dbaa0b74a7c992e0fc08788dc.jpg);">
      <h1 class="home"> UDAIPUR </h1>
      <h3 class="home1">THE LAKE CITY</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>UDAIPUR</h1>
          <h2>The Lake City</h2>
          </div>
          <div class="conte">
            <p>
                Udaipur, often called the 'Venice of the East', is a city of lakes nestled amidst the verdant Aravalli hills. Its enchanting beauty is exemplified by the exquisite Lake Palace on Lake Pichola. Jaisamand Lake, Asia's second-largest man-made sweet water lake, and the majestic City Palace and Sajjangarh (Monsoon Palace) further enhance the city's architectural splendor. Udaipur is renowned for its abundance of zinc and marble. The unique Solar Observatory on Lake Fateh Sagar, modeled after California's Big Bear Lake, is India's sole island-based observatory. The Shilpgram Festival, spanning ten days, attracts art and craft enthusiasts from far and wide between December 21 and 30. Founded in 1553 as Mewar's new capital by Maharana Udai Singh II, Udaipur's location in the fertile Girwa Valley holds historical significance.</p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN UDAIPUR
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://www.tripsavvy.com/thmb/_f-HF05nfCdg7A7sj8hHI1nowW8=/2121x1414/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-80336550-d0145c67798547dcbd5b1618bb90995e.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="kumbhalgarhfort">KUMBHALGHAR FORT</h1></li>
                                        <li><p>Kumbhalgarh Fort is a historic marvel located in Rajasthan, India. Built during the 15th century, it stands as a testament to the architectural brilliance of the Rajput era. With its massive walls spanning over 36 kilometers, it is known for being the second longest continuous wall after the Great Wall of China. The fort offers breathtaking panoramic views of the surrounding Aravalli Range.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/225.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="aharmuseum">AHAR MUSEUM</h1></li>
                                        <li><p>Ahar Museum, situated in Udaipur, India, is a renowned archaeological museum. It houses a vast collection of artifacts and archaeological remains from the ancient civilization of the region. The museum provides insights into the rich cultural heritage of Rajasthan, including sculptures, pottery, coins, and other fascinating relics, offering visitors a glimpse into the historical past.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/others/UD383.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="waxmuseum">WAX MUSEUM</h1></li>
                                  <li><p>The Hollywood Wax Museum is an exciting interactive visitor attraction located on Sajjangarh road. The Museum has been designed to deliver an interactive experience taking you on a journey through wax effigy. the exceptional life-like wax work characters you can expect at the celebrity wax museum .The Museum is the ultimate entertainment experience for all . The wax museum also offers 9 D Action cinema ,Gaming Zone, Mirror Image & Horror Show .</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/VCC568.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="vintagecarcollection">VINTAGE CAR COLLECTION</h1></li>
                                  <li><p>The collection within the grounds of the Garden Hotel comprises a variety of vintage and classic vehicles like Cadillac, Chevrolet, Morris etc owned by the Maharanas of Udaipur. They used these automobiles as their luxurious modes of transport.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/228.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="fatehsagarlake">FATEH SAGAR LAKE</h1></li>
                                <li><p>Fateh Sagar Lake is a captivating water body in Udaipur, Rajasthan. It offers a serene escape with its tranquil waters and picturesque surroundings. The lake is adorned with three small islands, including Nehru Park, where visitors can enjoy boat rides. It is a popular destination for locals and tourists seeking relaxation and natural beauty.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/229.jpg" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="lakepichola">LAKE PICHOLA</h1></li>
                                <li><p>Picholi was the name of a village that lent its name to the lake. The islands of Jagniwas and Jagmandir are housed in this lake. Along the eastern banks of the lake lies the City Palace. A boat ride in the lake around sunset offers a breathtaking view of the Lake and City Palace.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://www.udaipurblog.com/wp-content/uploads/2022/03/udai-sagar-1.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="udaisagarlake">UDAI SAGAR LAKE</h1></li>
                            <li><p>Udai Sagar Lake is a picturesque reservoir located near Udaipur in Rajasthan, India. Constructed in the 16th century by Maharana Udai Singh II, the lake spans across a vast area and provides a serene retreat. Surrounded by scenic hills and adorned with beautiful temples, Udai Sagar Lake is a popular destination for boating, picnics, and enjoying the tranquil ambiance.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/338.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="doodhtalailake">DOODH TALAI LAKE</h1></li>
                            <li><p>The road that takes visitors to Pichola Lake has another popular destination – the Doodh Talai Lake. The lake is nestled between several small hillocks which themselves are tourist attractions. The Deen Dayal Upadhyay Park and the Manikya Lal Verma Garden are part of the Doodh Talai Lake Garden.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/343.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="jaisamandlake">JAISAMAND LAKE</h1></li>
                        <li><p>Jaisamand Lake is known for being the second largest man-made sweet water lake in Asia. It is popular among the locals as a weekend picnic destination. Locals say that the lake was constructed to halt the waters of Ruparel River. This lake boasts of a large island, which is home to various species of birds, at its centre.</p></li>
                            </div>
                       
                    </ul>
                    <ul>
                      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/BadiLakeUdaipur.jpg"  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="badilake">BADI LAKE</h1></li>
                            <li><p>Badi Lake is an artificial lake that was built by Maharana Raj Singh to help the city counterbalance the devastating effects of drought. He named the lake Jiyan Sagar after his mother Jana Devi. During the drought of 1973, the lake proved to be a blessing for the people of Udaipur. And today, the lake has become a popular attraction in the city, for both locals and tourists. </p></li>
                        </div>
                       
                    </ul> 

                </div>







                <div class="list">
                  <ul>
                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Sajjangarh.jpg" alt=""  class="c"></li>
                      <div class="paragraph">
                  <li><h1 id="sajjangarhbiologicalpark">SAJJANGARH BIOLOGICAL PARK</h1></li>
                  <li><p>Located just outside the Sajjangarh Wildlife Sanctuary, at the foot hills of Bans-Dahara hills is the Sajjangarh Biological Park spread over 36 hectares of land. In this park one can see the Carnivores and Herbivores animals moving around in their natural habitat. One can visit the Park on foot or by Golf car on payment basis.</p></li>
                      </div>
                 
              </ul>
              <ul>
                <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/menar.jpg"  class="c"></li>
                  <div class="paragraph">
                  <li><h1 id="menar">MENAR</h1></li>
                  <li><p>Well-known as the City of Lakes, Udaipur is home to a number of beautiful lakes. Menar is a village known as house of number of species of Migratory Birds during winters. There are two ponds namely Brahm Talab and Dand Talab which hosts migratory birds. This village is a hidden tourist destination, can be one of the most favoured spots amongst birders.</p></li>
                  </div>
                 
              </ul> 

          </div>




          <div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/226.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="jagdishtemple">JAGDISH TEMPLE</h1></li>
            <li><p>An example of the Indo-Aryan style of architecture, Jagdish Temple was built in 1651 and continues to be one of the most famous temples in and around Udaipur. Dedicated to Lord Vishnu, the structure is an architectural marvel with carved pillars, graceful ceilings and painted walls. This three-storied temple was built by Maharana Jagat Singh I.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/SBT01.jpg"  class="c"></li>
            <div class="paragraph">
            <li><h1 id="sahastrabahutemple">SAHASTRA BAHU TEMPLE</h1></li>
            <li><p>Located about 22 km from Udaipur, in Nagda village on NH-8, stands the Sahastra Bahu Temple. The temple is dedicated to Lord Vishnu, and the name means ‘one with a million arms’, which is one of the forms of Vishnu. The site of the temple borders green marshlands, and is home to numerous date palms which give the temple a unique oasis-like ambiance. The temple is a 10 th century complex and is featured on the Archaeological Survey of India’s list of heritage monuments.</p></li>
            </div>
           
        </ul> 

    </div>


    



    <div class="list">
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/221.jpg" alt=""  class="c"></li>
            <div class="paragraph">
        <li><h1 id="citypalaceudaipur">CITY  PALACE</h1></li>
        <li><p>A majestic architectural marvel towering over the lake on a hill surrounded by crenelated walls, it is a conglomeration of courtyards, pavilions, terraces, corridors, rooms and hanging gardens. The main entrance is through the triple arched gate, the "Tripolia" with eight marble porticos, The Maharanas were weighed under the gate in gold, the equivalent amount of which was distributed among the populace. The surajgokhada, the balcony of the sun, is where the SuryanshiMaharanas of Mewar presented themselves to the people in the time of trouble to restore their confidence. </p></li>
            </div>
       
    </ul>
    <ul>
      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/224.jpg"  class="c"></li>
        <div class="paragraph">
        <li><h1 id="monsoonpalace">MONSOON PALACE</h1></li>
        <li><p>Situated just outside Udaipur, this 19th-century palace is built on top of Bansdara hills. Used as a monsoon palace and hunting lodge, its builder, Maharana Sajjan Singh, originally planned to make it an astronomical center. The plan was cancelled with Maharana Sajjan Singh's premature death. It is still an awe-inspiring sight on the Udaipur skyline and offers spectacular views of the city and the areas around.</p></li>
        </div>
       
    </ul> 

</div>



<div class="list">
    <ul>
      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/235.jpg" alt=""  class="c"></li>
        <div class="paragraph">
    <li><h1 id="shilpgram">SHILPGRAM</h1></li>
    <li><p>Situated 7 kms west of Udaipur near Lake Fateh Sagar is the Centre's Shilpgram - the Rural Arts and Crafts Complex. Spread over 70 acres, and surrounded by the Aravallis, the Rural Arts and Crafts Complex has been conceived as a living museum to depict the lifestyles of the folk and tribal people of the west zone.</p></li>
        </div>
   
</ul>
<ul>
  <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/The-Crystal-Gallery.jpg"  class="c"></li>
    <div class="paragraph">
    <li><h1 id="thecrystalgallery">THE CRYSTAL GALLERY</h1></li>
    <li><p>The Udaipur Collection of crystal is one of the largest and most complete collections of Osler cut glass in existence. In both diversity of objects and in the quality and grandeur of the included pieces, it holds a unique place in the decorative art world. Most of this collection was commissioned by Maharana Sajjan Singh in 1878, with the larger commissions of the furniture pieces being given to Osler in 1881. The exquisite crystal items in the gallery range from dining table, table, sofa set, washing bowl, goblet, tray, decanter, to perfume bottles, candle stands, crockery and even beds.</p></li>
    </div>
   
</ul> 

</div>

<div class="list">
    <ul>
      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/234.jpg" alt=""  class="c"></li>
        <div class="paragraph">
    <li><h1 id="bagorekihaveli">BAGORE KI HAVELI</h1></li>
    <li><p>Bagore-ki-Haveli is located by Lake Pichola, at Gangaur Ghat. Amar Chand Badwa, the Prime Minister of Mewar, built it in the 18th century. The massive palace has over a hundred rooms that display costumes and modern art. The glass and mirrors in the interiors are structured in classical haveli style.</p></li>
        </div>
   
</ul>


</div>


         
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                Dabok Airport, also known as Maharana Pratap Airport, is approximately 25 km northeast of the city center. Daily flights connect Delhi and Mumbai via Jet Airways, Air India, and SpiceJet.</p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Udaipur is well-connected by road to major destinations in India, including Chittorgarh, Ahmedabad, Jodhpur, Ajmer, Jaipur, Agra, Delhi, Mumbai, and Khajuraho.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p>Udaipur has railway connections to Chittorgarh, Ahmedabad, Ajmer, Sawai Madhopur, Jaipur, Agra, Delhi, Mumbai, and Khajuraho in India.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/15.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT UDAIPUR</h2>
                    <button><a href="home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR UDAIPUR</h3>
                    <div class="place">
                    <div><a href="./chittorghar"><img src="/rimages/chittorgarh.jpg" alt="PUSHKAR"></a>
                    <h4>CHITTORGARH</h4>
                    <p>111KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>249KM</p></div>
                        <div><a href="./ajmer"><img src="/rimages/ajmer.jpg" alt="JODHPUR"></a>
                        <h4>AJMER</h4>
                        <p>284KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>

  </html>