<!DOCTYPE HTML>
 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wildlife</title>
    <link rel="stylesheet" href="./rcss/main.css">
    <link rel="stylesheet" href="./rcss/navbar.css">
</head>
<style>
     /* .navbar{
            max-height: 40px;
        } */
</style>
<header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
<body>
    

    <div class="top-bar">
        <h1>WILDLIFE IN RAJASTHAN</h1>
        <h5>EXPLORE THE SPLENDOUR</h5>
    </div>
    <div class="list">
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Jhalana-jaipur.jpg);">
                    <h1 class="hide-h1">JHALANA SAFARI PARK IN JAIPUR</h1>
                    <div class="hit">
                    <h2>JHALANA SAFARI PARK</h2>
                    <p>Jhalana Safari Park: Thriving wildlife sanctuary in Jaipur, Rajasthan, renowned for leopard sightings..</p>
                    <a href="./jaipur#jhalanasafaripark">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/421.jpg);">
                    <h1 class="hide-h1">NAHARGARH BIOLOGICAL PARK</h1>
                    <div class="hit" >
                    <h2>NAHARGARH BIOLOGICAL PARK</h2>
                    <p>Nahargarh Biological Park: Wildlife reserve near Jaipur, Rajasthan, showcasing diverse flora and fauna..</p>
                    <a href="./jaipur#nahargarhbiologicalpark">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/RG02.jpg);">
                    <h1 class="hide-h1">RAM NIWAS GARDEN</h1>
                    <div class="hit">
                    <h2>RAM NIWAS GARDEN</h2>
                    <p>Ram Niwas Garden: Lush garden in Jaipur, Rajasthan, featuring beautiful landscapes, a zoo, and historical attractions like Albert Hall Museum..</p>
                    <a href="./jaipur#ramniwasgarden">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://jodhpurtourism.in/images/places-to-visit/headers/machiya-safari-park-jodhpur-entry-fee-timings-holidays-reviews-header.jpg);">
                    <h1 class="hide-h1">MACHIYA SAFARI PARK</h1>
                    <div class="hit">
                    <h2>MACHIYA SAFARI PARK</h2>
                    <p>Machiya Safari Park: Nature reserve in Jodhpur, Rajasthan, offering wildlife encounters and eco-tourism activities...</p>
                    <a href="./jodhpur#machiyasafaripark">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/355.jpg);">
                    <h1 class="hide-h1">DESERT NATIONAL PARK</h1>
                    <div class="hit" >
                    <h2>DESERT NATIONAL PARK</h2>
                    <p>Desert National Park: Expansive protected area in Rajasthan, showcasing the Thar Desert's unique ecosystem and diverse wildlife, including the Great Indian Bustard..</p>
                    <a href="./jaisalmer#desertnationalpark">Explore</a>
                </div>
            </li>
        </ul>
         <ul>
            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/AKALWOOD.jpg);">
                <h1 class="hide-h1">AKAL WOOD FOSSIL PARK</h1>
                    <div class="hit" >
                    <h2>AKAL WOOD FOSSIL PARK</h2>
                    <p>Akal Wood Fossil Park: Fossil park in Rajasthan, preserving 180-million-year-old petrified wood fossils and offering insights into prehistoric times..</p>
                    <a href="./jaisalmer#akalwoodfossilpark">Explore</a>
                </div>
            </div>


         <div class="list">
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Sajjangarh.jpg);">
                            <h1 class="hide-h1">SAJJANGARH BIOLOGICAL PARK</h1>
                            <div class="hit">
                            <h2>SAJJANGARH BIOLOGICAL PARK</h2>
                            <p>Sajjangarh Biological Park: Wildlife sanctuary near Udaipur, Rajasthan, housing a variety of animal species in their natural habitat..</p>
                            <a href="./udaipur#sajjangarhbiologicalpark">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/menar.jpg);">
                            <h1 class="hide-h1">MENAR</h1>
                            <div class="hit" >
                            <h2>MENAR</h2>
                            <p>Menar is a village known as house of number of species of Migratory Birds during winters..</p>
                            <a href="./udaipur#menar">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/247.jpg);">
                            <h1 class="hide-h1">KEOLADEO GHANA NATIONAL PARK</h1>
                            <div class="hit">
                            <h2>KEOLADEO GHANA NATIONAL PARK</h2>
                            <p>Keoladeo Ghana National Park: Internationally renowned bird sanctuary in Bharatpur, Rajasthan, known for its rich avian diversity and wetland ecosystem..</p>
                            <a href="./bharatpur#keoladeoghananationalpark">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/251.jpg);">
                            <h1 class="hide-h1">BAND BARETHA</h1>
                            <div class="hit">
                            <h2>BAND BARETHA</h2>
                            <p>Band Baretha: A wildlife sanctuary near Bharatpur, Rajasthan, encompassing a reservoir and diverse bird species, offering a picturesque natural setting..</p>
                            <a href="./bharatpur#bandbaretha">Explore</a>
                            </div>
                    </li>
                </ul>
                <ul>
                    <li class="s" style="background-image: url(https://static.india.com/wp-content/uploads/2018/08/Maharashtra-Tadoba.jpg?impolicy=Medium_Resize&w=1200&h=800);">
                            <h1 class="hide-h1">BASSI VILLAGE AND WILDLIFE SANCTUARY</h1>
                            <div class="hit" >
                            <h2>BASSI VILLAGE AND WILDLIFE SANCTUARY</h2>
                            <p>Bassi Village and Wildlife Sanctuary: A charming village near Chittorgarh, Rajasthan, known for its wildlife sanctuary that preserves the natural habitat and diverse fauna..</p>
                            <a href="./chittorghar#bassivillageandwildlifesantuary">Explore</a>
                        </div>
                    </li>
                </ul>
                 <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/others/B001.jpg);">
                        <h1 class="hide-h1">JORBEED</h1>
                            <div class="hit" >
                            <h2>JORBEED</h2>
                            <p>If you are a birder, then Jorbeed is your ‘spot of opportunities’. .</p>
                            <a href="./bikaner#jorbeed">Explore</a>
                        </div>
                    </div>
      
                    
                    <div class="list">
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/49.jpg);">
                                    <h1 class="hide-h1">GAJNER WILDLIFE SANCTUARY</h1>
                                    <div class="hit">
                                    <h2>GAJNER WILDLIFE SANCTUARY</h2>
                                    <p>Gajner Wildlife Sanctuary: A picturesque wildlife sanctuary located near Bikaner, Rajasthan, known for its diverse flora, fauna, and scenic landscapes..</p>
                                    <a href="./bikaner#gajnerwildlifesantuary">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/sariska-tiger-reserve.jpg);">
                                    <h1 class="hide-h1">SARISKA TIGER RESERVE</h1>
                                    <div class="hit" >
                                    <h2>SARISKA TIGER RESERVE</h2>
                                    <p>Sariska Tiger Reserve: A renowned tiger reserve located in Alwar, Rajasthan, offering an opportunity to observe the majestic Royal Bengal Tigers and other wildlife species in their natural habitat..</p>
                                    <a href="./cities/alwar#sariskatigerreserve">Explore</a>
                                    </div>
                            </li>
                        </ul>
                        
                        
                         <ul>
                            <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/AMS01.jpg);">
                                <h1 class="hide-h1">MOUNT ABU SANCTUARY</h1>
                                    <div class="hit" >
                                    <h2>MOUNT ABU SANCTUARY</h2>
                                    <p>Mount Abu Wildlife Sanctuary: A sanctuary located in the Aravalli Range in Mount Abu, Rajasthan, known for its rich biodiversity, including a variety of flora, fauna, and bird species..</p>
                                    <a href="./cities/mountabu#mountabusanctuary">Explore</a>
                                </div>
                            </div>
                
            </li>
        </ul>
    </div>
   
</body>
<footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>
