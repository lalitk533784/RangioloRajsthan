<!doctype HTML>
 <html lang="en">

<head>
  <title>Jodhpur</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   

</head>

<body>
  <header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
  <main>
    <div class="container-fluid front " style="  background-image: url(./rimages/21.png);">
      <h1 class="home"> JODHPUR </h1>
      <h3 class="home1">THE BLUE CITY</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>Jodhpur</h1>
          <h2>The Blue City</h2>
          </div>
          <div class="conte">
            <p>
                Jodhpur, the second largest city in Rajasthan, is renowned as the Blue City due to its striking blue-hued architecture. The forts, palaces, temples, havelis, and even houses are adorned in vivid shades of blue, lending a unique and captivating charm to the city. One of the most impressive sights is the formidable Mehrangarh Fortress, which towers over the landscape from a rocky ridge, with eight gates leading out of its mighty walls. The newer part of the city is situated outside the fortress.</p>
                <p>

                    The origins of Jodhpur date back to the year 1459 AD, and its rich history revolves around the Rathore clan. Rao Jodha, the chief of the Rathore Clan, is credited with founding Jodhpur in India. The city was established in place of the ancient capital, Mandore, which belonged to the state of Manwar. As a result, the people of Jodhpur and the surrounding areas are commonly known as Marwaris. It is believed that remnants of Mandore can still be observed in the Mandore Gardens, serving as a testament to the city's past. </p>
                    <p>
                        Moreover, Jodhpur is famous for its exceptional breed of horses known as Marwari or Malani, which can only be found in this region. </p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN JODHPUR
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://c4.wallpaperflare.com/wallpaper/484/985/153/jodhpur-rajasthan-india-wallpaper-preview.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="mehrangarhfort">MEHRANGARH FORT</h1></li>
                                        <li><p>Mehrangarh Fort in Jodhpur, Rajasthan, is an awe-inspiring architectural gem that stands atop a rocky hill. Built in the 15th century, it serves as a testament to the opulence and might of the Rathore dynasty. The fort's intricate carvings, magnificent palaces, and panoramic views offer a captivating experience, providing a glimpse into the vibrant history and cultural heritage of Rajasthan. It is a must-visit destination for history enthusiasts and admirers of architectural splendor.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1a/e1/98/d8/photo2jpg.jpg?w=1400&h=-1&s=1" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="khejarlafort">KHEJARLA FORT</h1></li>
                                        <li><p>Khejarla Fort, located near Jodhpur in Rajasthan, is a historic fortress that offers a glimpse into the glorious past of the region. Constructed in the 17th century, the fort showcases stunning architecture and intricate detailing. With its imposing structure, grand courtyards, and ornate interiors, it exudes a regal charm. Khejarla Fort has been converted into a heritage hotel, allowing visitors to experience royal hospitality and immerse themselves in the rich cultural heritage of Rajasthan while enjoying the serene surroundings and elegant ambiance of the fort.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/177.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="balsamandlake">BALSAMAND LAKE</h1></li>
                                  <li><p>Balsamand Lake, located near Jodhpur, Rajasthan, is a serene and picturesque artificial lake built in the 13th century. Surrounded by lush green gardens and groves, it offers a tranquil oasis away from the bustling city. The lake was constructed to provide water for the nearby Balsamand Palace, which now serves as a heritage hotel. Visitors can enjoy a leisurely walk along the lake's promenade or relax in the serene ambiance, making it a popular spot for picnics and outings.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/172.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="kailanalake">KAILANA LAKE</h1></li>
                                  <li><p>Kailana Lake is a picturesque man-made lake located on the outskirts of Jodhpur, Rajasthan. Built in 1872 by Pratap Singh, it serves as a vital water source for the city. Spread across an area of approximately 84 square kilometers, the lake offers a serene and tranquil ambiance, attracting visitors and locals alike. It is a popular spot for boating, picnics, and enjoying stunning sunset views. The lake is surrounded by lush greenery, making it a peaceful retreat from the bustling city life.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://www.jcrcab.com/wp-content/uploads/2023/01/Gulab_Sagar_Talab_Jodhpur.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="gulabsagarlake">GULAB SAGAR LAKE</h1></li>
                                <li><p>Gulab Sagar Lake is a picturesque water body located in Jodhpur, Rajasthan. It was built in the 18th century by Gulab Rai, a royal lady of Jodhpur. The lake is known for its serene ambiance, with stunning views of the surrounding architecture, including the nearby Mehrangarh Fort and the historic temples. Visitors can enjoy boating and witness the beautiful reflections of the forts and havelis on the tranquil waters, making it a popular spot for tourists and locals alike.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://lh5.googleusercontent.com/AJ_Q0_VbP7xIEX53Ac5kMAyFIatGUEsnCynXP7mOL-37cxcbg4Evt3xrgska-wugG0-Z7rMssUu71BsYwxQjTfoercPcWssRIjc1cVzM3DcagY4vRvyfG29N6Ck1GbvX4Ww2YONA_jyWrNuranBmZwviFcY2iRRrsrmexbcDTAe54n-Ak5KMa5yELA" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="machiyasafaripark">MACHIYA SAFARI PARK</h1></li>
                                <li><p>Machiya Safari Park is a popular wildlife destination located near Jodhpur in Rajasthan, India. Spread across a vast area, the park offers visitors the opportunity to observe and appreciate a diverse range of wildlife in their natural habitat. The park is home to various species, including deer, antelopes, birds, and reptiles. Visitors can embark on safari rides to explore the park, enjoy bird-watching, and experience the tranquility of nature. Machiya Safari Park provides an immersive wildlife experience and is a favored spot for nature lovers and wildlife enthusiasts.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://jodhpurtourism.in/images/places-to-visit/headers/sardar-government-museum-jodhpur-tourism-entry-fee-timings-holidays-reviews-header.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="jodhpurgovernmentmuseum">JODHPUR GOVERNMENT MUSEUM</h1></li>
                            <li><p>The Jodhpur Government Museum is a prominent cultural institution located in Jodhpur, Rajasthan, India. It houses a vast collection of artifacts, including sculptures, paintings, textiles, weapons, and manuscripts. The museum showcases the rich history and heritage of the region, offering visitors a glimpse into the royal past of Jodhpur. With its diverse exhibits and informative displays, the Jodhpur Government Museum is a must-visit for history enthusiasts and art lovers.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.mytravelframes.com/wp-content/uploads/2021/01/IMG_8570.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="mehrangarhfortandmuseum">MEHRANGARH FORT AND MUSEUM</h1></li>
                            <li><p>Mehrangarh Fort and Museum is a historic fortress located in Jodhpur, Rajasthan, India. Built in the 15th century, it stands on a hilltop overlooking the city and offers breathtaking views of the surrounding landscape. The fort showcases exquisite architecture and houses a fascinating museum with an extensive collection of artifacts, including weaponry, textiles, and art. It is a popular tourist attraction, attracting visitors with its rich history and cultural significance.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/167.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="mandaleshwarmahadev">MANDALESHWAR MAHADEV</h1></li>
                        <li><p>Mandaleshwar Mahadev is a revered Hindu temple located in Jodhpur, Rajasthan, India. Dedicated to Lord Shiva, it holds significant religious importance for devotees. The temple is known for its architectural beauty, adorned with intricate carvings and sculptures. It attracts pilgrims and tourists alike who seek spiritual solace and admire the craftsmanship of the structure. Mandaleshwar Mahadev temple stands as a symbol of devotion and offers a serene environment for prayer and contemplation.</p></li>
                            </div>
                       
                    </ul>
                    <ul>
                      <li> <img src="https://i.ytimg.com/vi/g7fvCX-VXdo/maxresdefault.jpg"  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="chamundamatajitemple">CHAMUNDA MATAJI TEMPLE</h1></li>
                        <li><p>Chamunda Mataji Temple is a revered Hindu temple located in Jodhpur, Rajasthan, India. Dedicated to Goddess Chamunda, it is situated on the outskirts of the city and is known for its spiritual significance and architectural beauty. The temple attracts devotees who seek blessings and wish to pay homage to the goddess. It offers a serene and peaceful environment, where visitors can engage in prayers and rituals, while also enjoying panoramic views of the surrounding landscape.</p></li>
                        </div>
                       
                    </ul> 

                </div>







                <div class="list">
                  <ul>
                    <li> <img src="https://img.freepik.com/fotos-premium/moti-mahal-palacio-perlas-sala-audiencias-mehrangarh-fort-jodhpur-rajasthan-india_163782-5157.jpg?w=2000" alt=""  class="c"></li>
                      <div class="paragraph">
                  <li><h1 id="motimahal">MOTI MAHAL</h1></li>
                  <li><p>Moti Mahal, located in Jodhpur, Rajasthan, is a magnificent palace known for its architectural splendor. Constructed in the 18th century, it served as the residence of the royal family of Jodhpur. Moti Mahal, meaning "Pearl Palace," features intricate carvings, ornate mirror work, and beautiful frescoes. It is adorned with stunning domes and balconies, showcasing the opulence and grandeur of the era. Today, Moti Mahal stands as a testament to Jodhpur's rich history and attracts visitors with its majestic beauty.</p></li>
                      </div>
                 
              </ul>
              <ul>
                <li> <img src="https://live.staticflickr.com/626/23542548302_81273a6bcc_b.jpg"  class="c"></li>
                  <div class="paragraph">
                  <li><h1 id="phoolmahal">PHOOL MAHAL</h1></li>
                  <li><p>Phool Mahal, located within the Mehrangarh Fort in Jodhpur, Rajasthan, is a magnificent palace known for its stunning beauty and architectural grandeur. Built in the 18th century, it served as a private chamber for the Maharajas of Jodhpur. Phool Mahal translates to "Flower Palace," and it derives its name from the exquisite floral motifs and intricate detailing adorning its walls and ceilings. Today, it stands as a testament to the opulence and splendor of the Rajput era.</p></li>
                  </div>
                 
              </ul> 

          </div>




          <div class="list">
            <ul>
              <li> <img src="https://www.kayak.co.in/rimg/himg/e1/31/f8/leonardo-1124409-Baradari_Dining_O-762078.jpg?width=1366&height=768&crop=true" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="umaidbhawanpalace">UMAID BHAWAN PALACE</h1></li>
            <li><p>Umaid Bhawan Palace is a magnificent architectural marvel located in Jodhpur, India. Completed in 1943, it serves as a luxury hotel, museum, and residence for the royal family of Jodhpur. Spread over 26 acres, the palace showcases a blend of Indo-Saracenic and Art Deco styles. With its opulent interiors, lush gardens, and panoramic views of the city, Umaid Bhawan Palace offers a regal experience to its guests, reflecting the grandeur of Rajasthan's heritage.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://travelogyindia.b-cdn.net/blog/wp-content/uploads/2019/02/Jaswant-Thada-Jodhpur.jpg"  class="c"></li>
            <div class="paragraph">
            <li><h1 id="jaswantthada">JASWANT THADA</h1></li>
            <li><p>Jaswant Thada is a memorial located in Jodhpur, Rajasthan, India. Built in the 19th century, it is a beautiful marble cenotaph dedicated to Maharaja Jaswant Singh II, the ruler of Marwar. The monument is renowned for its intricate carvings, delicate marble work, and peaceful surroundings. Jaswant Thada serves as a memorial to commemorate the contributions and legacy of Maharaja Jaswant Singh II, attracting visitors with its architectural charm and historical significance.</p></li>
            </div>
           
        </ul> 

    </div>
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                              Jodhpur is connected to Delhi and Mumbai and the airport is about 5 kilometres from the city centre.                             </p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Jodhpur is well-connected by road to all major cities and towns.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p> Jodhpur is well-connected by direct trains from all metros and major cities in India
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/12.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT JODHPUR</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR JODHPUR</h3>
                    <div class="place">
                    <div><a href="./ajmer"><img src="/rimages/29.jpg" alt="PUSHKAR"></a>
                    <h4>AJMER</h4>
                    <p>203KM</p></div>
                    <div><a href="./bikaner"><img src="/rimages/bikaner.jpg" alt="JODHPUR"></a>
                        <h4>BIKANER</h4>
                        <p>253KM</p></div>
                        <div><a href="./jaisalmer"><img src="/rimages/jaisalmer.jpg" alt="jais"></a>
                        <h4>JAISALMER</h4>
                        <p>265KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script> -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>

  </html>