<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Booking;

class BookingController extends Controller
{
    public function submit(Request $request)
    {
        $validatedData = $request->validate([
            'name'=>'required',
            'email' => 'required|email',
            'mobile' => 'required|numeric|digits:10',
            'source' => 'required',
            'destination' => 'required|array',
            'days' => 'required|integer|min:1|max:30',
            'date' => 'required|date',
        ]);

        $booking = new Booking();
        $booking->name=$validatedData['name'];
        $booking->email = $validatedData['email'];
        $booking->mobile = $validatedData['mobile'];
        $booking->source = $validatedData['source'];
        $booking->destination = implode(',', $validatedData['destination']);
        $booking->days = $validatedData['days'];
        $booking->date = $validatedData['date'];
        $booking->save();

        // Redirect to submission page with success message
        return back()->with('success', 'Booking submitted successfully!');
        
    }

    }
