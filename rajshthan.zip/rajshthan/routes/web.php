<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Logincontrollerontroller;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\BookingController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');








Route::get('/navbar', function () {
    return view('navbar');
});
Route::get('/footer', function () {
    return view('footer');
});
Route::get('/ajmer', function () {
    return view('ajmer');
});
Route::get('/alwar', function () {
    return view('alwar');
});
Route::get('/besttime to visit', function () {
    return view('besttime to visit');
});
Route::get('/bharatpur', function () {
    return view('bharatpur');
});
Route::get('/bikaner', function () {
    return view('bikaner');
});
Route::get('/chittorghar', function () {
    return view('chittorghar');
});
Route::get('/destination', function () {
    return view('destination');
});
Route::get('/fair and festival ', function () {
    return view('fair and festival ');
});
Route::get('/adventures ', function () {
    return view('adventures');
});
Route::get('/culture ', function () {
    return view('culture');
});Route::get('/foods ', function () {
    return view('foods');
});

Route::get('/aboutus ', function () {
    return view('aboutus');
});



Route::get('/forts ', function () {
    return view('forts ');
});Route::get('/forgin ', function () {
    return view('forgin ');
});Route::get('/index', function () {
    return view('index');
});Route::get('/jaipur', function () {
    return view('jaipur ');
});Route::get('/jaisalmer ', function () {
    return view('jaisalmer');
});Route::get('/jodhpur', function () {
    return view('jodhpur');
});Route::get('/lakes', function () {
    return view('lakes');
});Route::get('/message', function () {
    return view('message ');
});Route::get('/mountabu', function () {
    return view('mountabu');
});Route::get('/museum', function () {
    return view('museum');
});Route::get('/place', function () {
    return view('place');
});Route::get('/RELIGIOUS', function () {
    return view('RELIGIOUS');
});Route::get('/SUGGESTED ITINERARIES', function () {
    return view('SUGGESTED ITINERARIES');
});Route::get('/udaipur', function () {
    return view('udaipur');
});Route::get('/WILDLIFE', function () {
    return view('WILDLIFE');
});
Route::get('/tripplans', function () {
    return view('tripplans');
});

Route::get('/bookingform', function () {
    return view('bookingform');
});

Route::post('booking', [BookingController::class, 'submit']);