


<?php $__env->startSection('content'); ?>


    <style>
      .form{
        box-shadow: 2px 2px 3px 3px gray;
        border-radius: 3%;
        border: 2px solid black;
        width: 30%;
        margin: auto;
        padding: 10px;
        margin-top: 3%;
        background-color: blanchedalmond;
      }
    </style>
</head>
<div class="form">
<form action="booking" method="POST" >
  <?php echo csrf_field(); ?>

  <label for="name">Name:</label>
  <input type="name" id="name" name="name" required><br><br>

  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required><br><br>

  <label for="mobile">Mobile No.:</label>
  <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" required><br><br>

  <label for="source">Where are you from:</label>
  <input type="text" id="source" name="source" required><br><br>

  <label>Want to Visit Destinations:</label><br>
  <input type="checkbox" id="destination_jaipur" name="destination[]" value="Jaipur">
  <label for="destination_jaipur">Jaipur</label>
  <input type="checkbox" id="destination_udaipur" name="destination[]" value="Udaipur">
  <label for="destination_udaipur">Udaipur</label><br>
  <input type="checkbox" id="destination_jaisalmer" name="destination[]" value="Jaisalmer">
  <label for="destination_jaisalmer">Jaisalmer</label>


  <input type="checkbox" id="destination_alwar" name="destination[]" value="Alwar">
  <label for="destination_alwar">Alwar</label><br>
  <input type="checkbox" id="destination_ajmer" name="destination[]" value="Ajmer">
  <label for="destination_ajmer">Ajmer</label>
  <input type="checkbox" id="destination_bharatpur" name="destination[]" value="Bharatpur">
  <label for="destination_bharatpur">Bharatpur</label><br>

  <input type="checkbox" id="destination_bikaner" name="destination[]" value="Bikaner">
  <label for="destination_bikaner">Bikaner</label>
  <input type="checkbox" id="destination_chittorgarh" name="destination[]" value="Chittorgarh">
  <label for="destination_chittorgarh">Chittorgarh</label><br>
  <input type="checkbox" id="destination_mountabu" name="destination[]" value="MOUNT ABU">
  <label for="destination_mountabu">MOUNT ABU</label>
  <input type="checkbox" id="destination_jodhpur" name="destination[]" value="Jodhpur">
  <label for="destination_jodhpur">Jodhpur</label><br>
  <!-- Add more checkboxes for other cities -->

  <label for="days">Trip in days:</label>
  <input type="number" id="days" name="days" min="1" max="30" required><br><br>

  <label for="date">Date of Visit:</label>
  <input type="date" id="date" name="date" required><br><br>

  <input type="submit"  style="background-color: green;" value="Submit" >
  <button style="background-color:yellow;"><a href="/home">Go Back</a></button>
  
</form>

</div>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>

    
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

// function booking(){
//   alert("Booking Succefull")
// }


</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/bookingform.blade.php ENDPATH**/ ?>