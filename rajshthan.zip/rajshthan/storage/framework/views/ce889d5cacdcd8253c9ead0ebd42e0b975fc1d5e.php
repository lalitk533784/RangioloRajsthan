<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./rcss/navbar.css">
    <style>
        *{
            font-family: 'Gill Sans', 'Gill Sans MT', 'Trebuchet MS', sans-serif;
            
        }
        body{
            width: 100%;
            background-color: rgb(252, 250, 229);
        }
        .container{
            height: 80vh;
            width: 100%;
            background-image: url(https://www.akshartours.com/wp-content/uploads/2020/06/Rajasthan-04.jpg);
            background-position: center;
            background-size: cover;
            border: 10px;

        }
        .main{
            height: 100%;
            margin-left: 50px;
            margin-right: 50px;
        }
        .main1{
            height: 100%;
            margin-left: 50px;
            margin-right: 50px;
        }
        .main h1{
            text-align: center;
        }
        .main p{
            text-align: justify;
            
        }
        .main span{
            font-weight: bold;
        }
        .container-list>ul li{
            list-style: none;
            
        }
    </style>
</head>
<header>
  <div class="navbaar" id="topbar">
    <div class="nav-top"></div>
  
  <ul class="navbar">
   <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Discover</a>
    <ul class="dropdown-menu">
      <li class="dropdown-submenu">
          <a href="./destination" class="dropdown-toggle">Destination </a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
            <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
            <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
            <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
            <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
            <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
            <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
            <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
            <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
          </ul>
          </li>
      <li class="dropdown-submenu">
        <a href="/" class="dropdown-toggle">Fort</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
          <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
          <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
          <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
          <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./lakes" class="dropdown-toggle">Lake</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
          <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
          <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
          <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
          <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./place" class="dropdown-toggle">Places</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
          <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
          <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
          <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
          <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
          <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
          <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
          <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
          <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
          <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
          <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
          <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
          <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
          <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
          <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
          <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
          <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
          <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
          <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
          <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
          <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
          <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
          <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
          <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
          <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
          
        </ul>
      </li>
      
      <li class="dropdown-submenu">
        <a href="./museum" class="dropdown-toggle">Museum</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
          <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
          <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
          <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
          <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
          <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
          <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
         
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
          <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
          <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
          <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
          <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
          <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
          <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
          <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
          <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
          <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
          <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
          <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
          <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
          <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
          <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
        </ul>
      </li> 
    </ul>
    


  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Experience</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
          <a href="./adventures" class="dropdown-toggle">Adventures </a>
    </ul>
  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Plan</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
          </li>
          <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
          <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
    </ul>
  </li>
  

  <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
 
</ul>

  <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->

</div>
<script>
  window.addEventListener('DOMContentLoaded', function () {
var dropdowns = document.getElementsByClassName('dropdown');
for (var i = 0; i < dropdowns.length; i++) {
  dropdowns[i].addEventListener('mouseover', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
  });
  dropdowns[i].addEventListener('mouseout', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
  });
}
});


</script>
</header>

<body>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#navbar-placeholder").load("navbar");
      });
      </script>
      <div id="navbar-placeholder"></div> -->
  
    <div class="container">
        <!-- <img src="https://www.akshartours.com/wp-content/uploads/2020/06/Rajasthan-04.jpg" alt=""> -->  
        

    </div>
    <div class="main">
        <h1>BEST TIME TO VISIT</h1>
<p>
    Rajasthan, often referred to as the "Land of Kings," is a mesmerizing state located in northern India. It is known for its rich cultural heritage, magnificent palaces, vibrant festivals, and breathtaking landscapes. When planning a trip to Rajasthan, it is essential to consider the best time to visit to make the most of your experience. The climate in Rajasthan varies significantly throughout the year, so let's explore the different seasons and their characteristics.
</p>
        
            <h3>
                Rajasthan during the different times of the year
            </h3>
        <p>
           <span>Winters</span>  – The winters are marked as being the best season to visit Rajasthan. While various parts of India experience an extreme drop in temperatures and chilly weather, the princely state enjoys a mild weather with temperatures ranging between 10°C – 30°C for most parts. Winters in Rajasthan usually commence around October and extend to January. While it is nice and sunny during the day, it is mostly the nights that get chilly during this time of the year.
        </p>
        <p>
            Another significant reason that makes winters the best time to visit Rajasthan is the series of colourful and exciting fairs and festivals that take place in various cities. Some of the most popular festivals that the state is known for, including the Jaipur Literature Festival, Udaipur World Music Festival, Camel Fair, and Pushkar Fair, are observed during the winter season.
        </p>
        <p>
            <span>Monsoons –</span>
            The South-West Monsoon and Western Disturbances are the main causes of rainfall in Rajasthan. The Aravalli range running across Rajasthan from Guru Shikhar in the south west to Khetri in the north east, divides the state in a 60 by 40 ratio. So, while 60% of the state lies to the north west of the range, 40% of it lies to the south east. Lying parallel to the incoming southwest monsoon winds, the mountain range fails to intercept them, resulting in a dry and sandy north west region. On the contrary, the eastern and south eastern parts of Rajasthan are both better watered and more fertile. Rainfall in Rajasthan ranges in between 100-165 mm during the monsoon season. The presence of impervious rocks in the western parts of Rajasthan can also sometimes cause them to flood up.
        </p>
        <p>
            Visiting Rajasthan during the monsoon season, you will be welcomed by lush greenery, rainbows, and peacocks dancing around. You will also get to catch up on some cultural extravaganzas, as various parts of the state ready up for the Teej festival in the monsoon season.
        </p>
        <p>
            <span>Summers – </span>
            Summers in Rajasthan are usually hot and dry, with temperatures rising up to as high as 48 degrees Celsius. Scorching heat and high temperatures make things challenging for people here. Temperatures in areas around the Thar Desert are usually the harshest. However, summers in places like Mount Abu, Ranakpur, and Kumbhalgarh in Rajasthan, which are the places to which tourists mostly flock to when visiting the state in this season, are rather pleasant.
        </p>
        <p>
            For people who have a problem with extreme weather conditions, this might not be the best time to visit Rajasthan. However, if you plan on coming to Rajasthan during this time of the year, make sure that you bring along things like sunscreen and comfortable and light cotton clothes with you. It will also help save you from sunburns if these attires are full-sleeved.
        </p>
    </div>
    <div class="main1">
        <h3>TEMPERATURE & RAINFALL AROUND THE YEAR</h3>
<div class="container-list">
    <ul>
        <li><h4>JANUARY TO MARCH</h4></li>
        <li>50F - 80F</li>
        <li>10°C - 27°C</li>
        <li>4MM - 7MM</li>
    </ul>
    <ul>
        <li><h4>APRIL TO JUNE</h4></li>
        <li>75F - 105F</li>
        <li>24°C - 45°C</li>
        <li>11MM - 30MM</li>
    </ul>
    <ul>
        <li><h4>JULY  TO SEPTEMBER</h4></li>
        <li>70F - 95F</li>
        <li>10°C - 27°C</li>
        <li>100MM - 165MM</li>
    </ul>
    <ul>
        <li><h4>OCTOBER  TO DECEMBER</h4></li>
        <li>55F - 85F</li>
        <li>13°C - 30°C</li>
        <li>3MM - 8MM</li>
    </ul>
</div>
    </div>
    
</body>
<footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>
    
    
    
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html><?php /**PATH C:\xampp\htdocs\prjct\rajshthan\resources\views/besttime to visit.blade.php ENDPATH**/ ?>