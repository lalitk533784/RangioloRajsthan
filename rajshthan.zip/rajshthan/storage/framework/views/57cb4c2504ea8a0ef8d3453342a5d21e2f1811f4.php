<!doctype HTML>
<html lang="en">

<head>
  <title>Jaipur</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   


</head>

<body>
  <header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
<main>
    <div class="container-fluid front ">
      <h1 class="home"> JAIPUR </h1>
      <h3 class="home1">JAL MAHAL</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>Jaipur</h1>
          <h2>The Pink City</h2>
          </div>
          <div class="conte">
            <p>
            Jaipur, the capital city of the Indian state of Rajasthan, has a rich 
            and vibrant history. It was founded in 1727 by Maharaja Sawai Jai Singh II,
             the ruler of Amber, who planned and designed the city according to Vastu
              Shastra and architectural principles. Jaipur is renowned for its
               well-planned layout, wide streets, and stunning architecture,
                including the iconic Hawa Mahal and the majestic City Palace. 
                The city played a significant role in Rajasthan's history and 
                served as a major center for trade and commerce.
                 Today, Jaipur stands as a testament to its royal heritage,
                  blending tradition with modernity.</p><p>

                  Planned by Vidyadhar Bhattacharya, Jaipur holds the distinction of being the first planned city of India. Renowned globally for its coloured gems, the capital city of Rajasthan combines the allure of its ancient history with all the advantages of a metropolis. The bustling modern city is one of the three corners of the golden triangle that includes Delhi, Agra and Jaipur.
                  </p><p>
                  The story goes that in 1876, the Prince of Wales visited India on a tour. Since the colour pink was symbolic of hospitality, Maharaja Ram Singh of Jaipur painted the entire city pink. The pink that colours the city makes for a marvellous spectacle to behold. Jaipur rises up majestically against the backdrop of the forts Nahargarh, Jaigarh and Garh Ganesh Temple.
                </p><p>
                  Jaipur traces back its origins to 1727 when it was established by Jai Singh II, the Raja of Amber. He shifted his capital from Amber to the new city because of the rapidly-growing population and an increasing water scarcity. Noted architect Vidyadhar Bhattacharya used the established principles of Vastu Shastra to build the city.
                </p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN JAIPUR
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://rajasthantraditional.com/wp-content/uploads/2020/10/amar-jawan-jyoti-jaipur2-1024x683.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="amarjavanjyoti">AMAR JAWAN JYOTI</h1></li>
                                        <li><p>Amar Jawan Jyoti is a memorial in Jaipur, Rajasthan, India, dedicated to the martyrs who sacrificed their lives for the nation. Located in the heart of the city, it symbolizes eternal flame and pays homage to the brave soldiers. The memorial serves as a reminder of their courage, valor, and sacrifice, instilling a sense of patriotism in the hearts of visitors. Amar Jawan Jyoti stands as a tribute to the indomitable spirit of the Indian Armed Forces.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://media.architecturaldigest.in/wp-content/uploads/2019/01/Featured-Image2.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="jaipur#madhvendrapalace,nahargarh">MADHVENDRA PALACE, NAHARGARH</h1></li>
                                        <li><p>Madhavendra Palace, located in Nahargarh, Jaipur, is a stunning architectural gem. Built in the 19th century by Maharaja Sawai Madho Singh II, the palace is a magnificent example of Rajput architectural style. It consists of a series of interconnected suites designed for the king and his queens. The palace offers breathtaking panoramic views of Jaipur city and the surrounding landscapes. Today, it stands as a popular tourist attraction, showcasing the opulence and grandeur of Rajasthan's royal history.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/125.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="amberpalace">Amber Palace</h1></li>
                                  <li><p>Nestled on a hill in Jaipur, Amber Palace exudes regal splendor. This ancient fortress transports visitors to a bygone era with its intricate architecture, exquisite frescoes, and panoramic views. Wander through ornate chambers, adorned with delicate mirror work and intricate carvings, and immerse yourself in the opulence of Rajasthan's rich heritage. Discover the captivating allure of Amber Palace, a true architectural marvel.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/103.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="citypalacejaipur">CITY PALACE</h1></li>
                                  <li><p>Situated in the heart of Jaipur, City Palace is a captivating marvel that epitomizes the city's royal legacy. This magnificent palace complex showcases a harmonious fusion of Rajput and Mughal architectural styles. From its ornate gates and stunning courtyards to its opulent halls and museums, City Palace offers a glimpse into the opulent lifestyle of Jaipur's erstwhile rulers. Adorned with intricate carvings, vibrant murals, and a stunning collection of artifacts, the palace stands as a testament to the city's rich cultural heritage.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://assets.vogue.in/photos/5ce42fa13bf9b4375bb1ccd5/4:3/w_1440,h_1080,c_limit/feature-amrapali-museum-of-jewellery.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="amrapalimuseum">AMRAPALI MUSEUM</h1></li>
                                <li><p>Amrapali Museum in Jaipur is a captivating cultural treasure that showcases the exquisite artistry of Jaipur's jewelry. Named after the renowned royal courtesan Amrapali, the museum exhibits a dazzling collection of antique jewelry, gemstones, and artifacts. It offers a fascinating glimpse into the rich heritage of Jaipur's jewelry craftsmanship, featuring intricately designed pieces that reflect the city's royal legacy. Amrapali Museum is a must-visit destination for those seeking to admire and appreciate the opulence and mastery of traditional Rajasthani jewelry art.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://th.bing.com/th/id/R.9e7eab8324000d1302b793a212aad0b3?rik=G5sAFelRoj2Hwg&riu=http%3a%2f%2fassets.serenity.co.uk%2f48000-48999%2f48980%2f1296x864.jpg&ehk=c74Uxb49fJXtcEj%2bCdSE5RF5FrkgyPxqsgVnGoJUdYs%3d&risl=&pid=ImgRaw&r=0" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="hawamahal">HAWA MAHAL </h1></li>
                                <li><p>Hawa Mahal, also known as the "Palace of Winds," is an iconic landmark in Jaipur, India. This architectural marvel was built in 1799 with a unique honeycomb design featuring 953 intricately carved windows. Designed for royal women to observe street processions while maintaining privacy, Hawa Mahal is a stunning blend of Rajput and Mughal styles. Its pink sandstone façade, adorned with delicate lattice work, adds to its ethereal beauty. A symbol of Jaipur's rich history and heritage, Hawa Mahal remains an enchanting attraction that leaves visitors in awe.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/110.jpg" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="alberthallmuseum">ALBERT HALL MUSEUM (CENTRAL MUSEUM)</h1></li>
                            <li><p>The Albert Hall Museum, also known as the Central Museum, is a magnificent cultural treasure in Jaipur. Built in 1876, it showcases a blend of Indo-Saracenic architecture with elements of Rajput and Mughal styles. Housing a vast collection of artifacts including ancient sculptures, exquisite paintings, intricate jewelry, and historical artifacts, the museum offers a captivating journey through Rajasthan's rich heritage. The stunning central dome, beautiful courtyards, and ornate galleries make the Albert Hall Museum a must-visit destination for history and art enthusiasts.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/101.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="nahargarhfort">NAHARGARH FORT</h1></li>
                            <li><p>Perched on the Aravalli hills overlooking Jaipur, Nahargarh Fort offers a breathtaking panoramic view of the Pink City. Built in the 18th century, this majestic fort served as a defensive stronghold and a retreat for the royals. With its rugged walls, intricate architecture, and beautiful frescoes, Nahargarh Fort immerses visitors in the regal history of Rajasthan. The fort also houses a fascinating wax museum and a rooftop restaurant, making it a popular destination for history buffs and those seeking stunning vistas.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/124.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="jaigarhfort">JAIGARH FORT</h1></li>
                        <li><p>Jaigarh Fort, situated on the Aravalli hills above Amer Fort in Jaipur, is a magnificent testament to Rajput military prowess. Built in the 18th century, it served as a defensive stronghold and houses impressive structures like the world's largest cannon on wheels, Jaivana. The fort's robust architecture, sprawling courtyards, and underground passages fascinate visitors. Offering panoramic views of the surrounding landscape, Jaigarh Fort invites exploration of its armory, museum, and captivating history, leaving visitors in awe of its grandeur.</p></li>
                            </div>
                       
                    </ul>
                    <ul>
                      <li> <img src="https://external-preview.redd.it/hHh_2rXDnX99GA6JjwCN9R5UZOMRmKa5GepXVKOhk9k.jpg?auto=webp&s=8eabd1440df57ee00934e98a92a82597ae0080ae" alt=""  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="jalmahal">JAL MAHAL</h1></li>
                        <li><p>Jal Mahal, meaning "Water Palace," is an exquisite architectural gem floating in the middle of Man Sagar Lake in Jaipur. Built in the 18th century, this five-story palace showcases a unique blend of Rajput and Mughal styles. With its intricate facade, stunning reflection in the tranquil waters, and the backdrop of the Aravalli hills, Jal Mahal creates a mesmerizing sight. While the palace itself is mostly submerged, its beauty and charm make it a popular spot for photography and serene boat rides.</p></li>
                        </div>
                       
                    </ul> 

                </div>


                <div class="list">
                  <ul>
                    <li> <img src="https://images.squarespace-cdn.com/content/v1/4f8337ef24ac66e9aae7464b/1463366281933-PZHZR8JPI15T1USRKVZB/image-asset.jpeg?format=1000w" alt=""  class="c"></li>
                      <div class="paragraph">
                  <li><h1 id="anokhimuseumofhandprinting">ANOKHI MUSEUM OF HAND PRINTING</h1></li>
                  <li><p>The Anokhi Museum of Hand Printing is a cultural institution located in Jaipur, Rajasthan, India. It showcases the art of hand block printing, a traditional textile technique practiced in the region for centuries. The museum exhibits a vast collection of hand-printed textiles, tools, and artifacts, providing visitors with insights into the history, techniques, and cultural significance of this ancient craft. It serves as a platform for preserving and promoting the rich heritage of hand block printing in Rajasthan.</p></li>
                      </div>
                 
              </ul>
              <ul>
                <li> <img src="https://i0.wp.com/www.rajasthandirect.com/wp-content/uploads/2017/09/Jaipur-Wax-Museum.jpg?fit=900%2C460&ssl=1" alt=""  class="c"></li>
                  <div class="paragraph">
                  <li><h1 id="jaipurwaxmuseum">JAIPUR WAX MUSEUM</h1></li>
                  <li><p>The Jaipur Wax Museum is a popular tourist attraction in Jaipur, Rajasthan, India. Located within the Nahargarh Fort, the museum showcases lifelike wax statues of prominent personalities from various fields, including history, politics, sports, and entertainment. Visitors can marvel at the detailed craftsmanship and realistic portrayal of these wax figures. The Jaipur Wax Museum provides an interactive and immersive experience, allowing visitors to learn about and admire notable individuals from different walks of life.</p></li>
                  </div>
                 
              </ul> 

          </div>



          <div class="list">
            <ul>
              <li> <img src="https://i0.wp.com/www.rajasthandirect.com/wp-content/uploads/2018/05/gem-museum.jpg?fit=1086%2C539&ssl=1" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="museumofgemandjewellary">MUSEUM OF GEM AND JEWELLERY</h1></li>
            <li><p>The Museum of Gem and Jewellery is a captivating destination for enthusiasts and connoisseurs of precious stones and ornaments. Located in an exquisite setting, the museum showcases a diverse collection of rare gemstones, exquisite jewelry pieces, and historical artifacts. Visitors can explore the intricate craftsmanship, learn about the history of gemstones, and appreciate the beauty and cultural significance of these precious treasures. The museum provides a fascinating insight into the world of gems and jewelry, leaving visitors spellbound by its splendor and elegance.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/museum-legacies.jpg" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="museumoflegacies">MUSEUM OF LEGACIES</h1></li>
            <li><p>Housed in a nearly 200-year old building in the historic Kishanpole Bazaar of Jaipur's Pink City area, Museum of Legacies opened on 9 December, 2017. The aim is to create an artspace that exclusively displays the rich cultural heritage of Rajasthan, with a diverse collection that includes everything from textiles, jewellery, stoneware and inlay work, painting, pottery and more. Apart from this, indigenous art from different parts of India are also given a platform here. This is a very inclusive space that caters to locals and tourists alike. Museum of Legacies currently has with eight active galleries. Each has been allotted to an individual who has been instrumental in the art and culture scene of India. </p></li>
            </div>
           
        </ul> 

    </div>
<!-- pending -->
    <div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/RG02.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="ramniwaspark">RAM NIWAS GARDEN</h1></li>
            <li><p>This historical garden was built by Maharaja Sawai Ram Singh in 1868. Located in the heart of the city, the garden houses the Albert Hall Museum (now known as Central Museum), a bird park, a zoo, the Ravindra Rang Manch theatre, an art gallery and an exhibition ground.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/421.jpg" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="nahargarhbilogicalpark">NAHARGARH BIOLOGICAL PARK</h1></li>
            <li><p>Nahargarh Biological Park is a wildlife sanctuary located near the Nahargarh Fort in Jaipur, India. Spread over an area of 7.2 square kilometers, it serves as a habitat for various species of animals including tigers, leopards, lions, deer, and many more. The park offers visitors a chance to observe and appreciate the diverse flora and fauna in a natural setting. </p></li>
            </div>
           
        </ul> 

    </div>

    <div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Jhalana-jaipur.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="jhalanasafaripark">JHALANA SAFARI PARK IN JAIPUR</h1></li>
            <li><p>Jhalana Safari Park, located in Jaipur, India, is a renowned wildlife reserve known for its thriving population of leopards. Spanning approximately 20 square kilometers, the park offers visitors a unique opportunity to spot and observe these elusive big cats in their natural habitat, making it a popular destination for wildlife enthusiasts and photographers.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Jagat-Shiromani-Temple.jpg" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="jagatshiromanitemple">JAGAT SHIROMANI TEMPLE</h1></li>
            <li><p>The Jagat Shiromani Temple is a Hindu temple located in Amer, Jaipur. Possessing an extraordinary architecture which enchants with its greatness and beauty, it is a site of immense fascination for the tourists. The temple is devoted to Hindu gods Lord Krishna and Lord Vishnu, and is said to be built around 1599-1608 AD by Queen Kanakwati, the wife of King Man Singh I, in the memory of their son Jagat Singh. ‘Jagat Shiromani’, meaning ‘Head Jewel of Lord Vishnu’, is an epochal facet of the ancient history of Rajasthan. The temple houses the idols of Lord Krishna, Lord Vishnu and Meera Bai.  </p></li>
            </div>
           
        </ul> 

    </div>

    <div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/AKT552.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="akshardhamtemple">AKSHARDHAM TEMPLE</h1></li>
            <li><p>One of the most-visited temples in the city of Jaipur, the Akshardham Temple depicts real architectural wonders. Surrounded by lush green gardens and charming fountains, the Akshardham Temple has unique architectural features, including the walls which are covered with a number of carvings and sculptures that are beautiful to look at. This helps create an amazing atmosphere of peace and serenity, attracting not just thousands of devotees, but also a number of tourists throughout the year.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/121.jpg" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="galtaji">GALTAJI</h1></li>
            <li><p>Galtaji is an ancient pilgrimage centre in Jaipur. Set amidst low hills and packed with locals and tourists alike, the attractive spot has temples, pavilions and holy kunds (natural springs and water tanks). Visitors to Galtaji will come across the complex of Ramgopalji temple, locally called the Monkey temple (Galwar Bagh). It gets this moniker because of a large group of resident monkeys. The green landscape and chattering monkeys add to the delight of the area. </p></li>
            </div>
           
        </ul> 

    </div>

    <div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/118.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="motidoongriganeshtemple">MOTI DOONGRI GANESH TEMPLE</h1></li>
            <li><p>Moti Doongri is a small hill around which the city of Jaipur flourishes. Moti Doongri means pearl hill, because the hill indeed resembles a pearl drop. Visitors go there to pay homage at the famous Ganesh temple, the most auspicious and important religious temple in Jaipur. The Ganesh temple was built by Seth Jai Ram Paliwal, sometime in the early 18th century. A legend goes, the King of Mewar was heading back to his palace after a long journey and was carting a massive Ganesh idol on a bullock cart. The king had decided that he would build a temple for the idol of Lord Ganesh wherever the bullock cart stopped.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/116.jpg" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="govinddevjitemple">GOVIND DEVJI TEMPLE</h1></li>
            <li><p>The Krishna temple is a rare spire-less temple and houses the idol of Govind Devji that Sawai Jai Singh brought from Vrindavan. The deity, worshipped by the erstwhile royal family, is also revered by the the locals in the area. </p></li>
            </div>
           
        </ul> 

    </div>

   

<!-- pending -->
    <div class="list">
      <ul>
        <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Rajasthan_Vidhansabha.png" alt=""  class="c"></li>
          <div class="paragraph">
      <li><h1 id="museumonpoliticalnarratives">MUSEUM ON POLITICAL NARRATIVES</h1></li>
      <li><p>After Chief Minister Shri Ashok Gehlot made an announcement in the House on July 29, 2019, this museum was constructed by the Jaipur Smart City Limited on the directions of Assembly Speaker Shri C.P Joshi. The museum was inaugurated by the then Chief Justice of India, Honorable Justice Shri N.V.Ramana on July 16, 2022. Built in the majestic Rajasthan Legislative Assembly, this museum will keep alive the memories of the contribution of those great politicians who have led this state on the path of development. The museum also showcases the history of Rajputana, the role of Rajasthan in the Indian freedom struggle and the political journey leading to the formation of the Rajasthan state. </p></li>
          </div>
     
  </ul>
  <ul>
    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/S550.jpg" alt=""  class="c"></li>
      <div class="paragraph">
      <li><h1 id="sambharlake">SAMBHAR LAKE</h1></li>
      <li><p>Sambhar Lake, located in the state of Rajasthan, India, is the largest saltwater lake in India. Spanning over 190 square kilometers, it serves as a crucial habitat for migratory birds, particularly during the winter season. The lake's saline water and the surrounding salt flats contribute to the production of salt, making it an important salt-producing region. Sambhar Lake is not only a natural wonder but also a significant ecological hotspot, attracting nature enthusiasts and birdwatchers from around the world.</p></li>
      </div>
     
  </ul> 

</div>
<div class="list">
            <ul>
              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/117.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="birlatemple">BIRLA TEMPLE</h1></li>
            <li><p>The Lakshmi-Narayan Temple, or the Birla Temple, as it is more popularly known as, is located at the base of Moti Dungari. Built on an elevated platform, this comparatively modern temple is built entirely of white marble and dominates the skyline of south Jaipur. The temple was commissioned and built by renowned Indian industrialists, the Birlas, in 1988. The temple is dedicated to Lord Vishnu, also called Narayan, and his companion, Lakshmi, the Goddess of wealth and good fortune. The temple is a work of art and has a marvellous display of exquisite carvings and sculptures covering many mythological themes. </p></li>
                </div>
           
        </ul>
      

    </div>
                </div>



                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                The Jaipur International Airport is called Sanganer Airport.                             </p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p> A convenient way to travel to Jaipur is by road. Regular service of AC and Deluxe buses is available from all major cities in Rajasthan.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p> Jaipur is connected via rail from all major cities including Delhi, Agra, Mumbai, Ahmedabad, Bangalore, etc.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/9.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT JAIPUR</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR JAIPUR</h3>
                    <div class="place">
                    <div><a href="./ajmer"><img src="/rimages/29.jpg" alt="PUSHKAR"></a>
                    <h4>AJMER</h4>
                    <p>131KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>334KM</p></div>
                        <div><a href="./alwar"><img src="/rimages/alwar.jpg" alt="ALWAR"></a>
                        <h4>ALWAR</h4>
                        <p>133KM</p></div>
                    </div>
                    </div>
              </div>      


              <div id="footer-placeholder"></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(function() {
    $("#footer-placeholder").load("footer");
  });
</script>


  <!-- Bootstrap JavaScript Libraries -->


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html><?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/jaipur.blade.php ENDPATH**/ ?>