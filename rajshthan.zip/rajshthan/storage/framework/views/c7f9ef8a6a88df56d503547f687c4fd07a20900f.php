<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
    body{
        background-image: aquamarine;
        background-image: url(https://www.solidbackgrounds.com/images/2560x1440/2560x1440-light-yellow-solid-color-background.jpg);
    }
    .navbar{
        background-color:#fcf1b3;
        border-bottom: 5px solid orange;
      
    }
    .navbar-brand>img{
        width:150px;
        max-height: 100px;
        mix-blend-mode:multiply;
        /* margin-left: -50px; */
        
    }
    /* loader */
#loader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color:rgba(83, 83, 83, 0.83);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .loader-spinner {
    width: 300px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    font-size: 27px;
    color: orange;
  }
  
  .loader-spinner::before {
    content: "Welcome To Rajsthan";
    position: absolute;
    opacity: 0;
    animation: floatText 2s infinite;
  }
  
  @keyframes floatText {
    0%,
    100% { opacity: 0; }
    50% { opacity: 1; }
  }
  
  #loader{
    display: none;
  }
  
</style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md  ">
            <div class="container">
                <a class="navbar-brand" href="/">
                    <!-- <?php echo e(config('app.name', 'Laravel')); ?> -->
                    <img src="/rimages/logo1.png" alt="JODHPUR">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>
                         
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                         
                        <?php if(auth()->guard()->guest()): ?>
                          
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
        
</body>


</html>
<?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/layouts/app.blade.php ENDPATH**/ ?>