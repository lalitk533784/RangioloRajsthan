


<?php $__env->startSection('content'); ?>


<style>
    body{
        background-image: aquamarine;
        background-image: url(https://www.solidbackgrounds.com/images/2560x1440/2560x1440-light-yellow-solid-color-background.jpg);
    }
    .card{
        background-image: url(https://th.bing.com/th/id/R.57fa7aa57d0120834b53bcfe81803dd0?rik=rSPc0YAP6wWdyw&riu=http%3a%2f%2fstatic.dnaindia.com%2fsites%2fdefault%2ffiles%2fstyles%2ffull%2fpublic%2f2016%2f01%2f18%2f416125-rajasthan-tourism-logo.jpg&ehk=eZHi9hveGSZ5n37Up3%2bOdCW7aM4VGZGknmkQxrqbLUM%3d&risl=&pid=ImgRaw&r=0);
        background-size: cover;
        background-repeat: no-repeat;
        width: 90%;
    }
    
.list1{
    display: grid;
    grid-template-columns: 38% 62%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid red; */
    
}
.list2{
    display: grid;
    grid-template-columns: 34% 33% 33%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid black; */
    
}
.view{
  margin-top: 50px;
  border: 1px solid orange;
}

.st {
    /* background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/101.jpg'); */
    background-repeat: no-repeat;
    background-size: cover;
    /* border-radius: 20px; */
}

.list1>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed green; */
    /* margin: 0; */
}
.list2>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed gold; */
}

 .list1>ul:nth-child(2) .hit1{
    background-color: gold
} 
.list2>ul:nth-child(1) .hit1{
    background-color: rgb(153, 255, 0)
}
.list2>:nth-child(2) .hit1{
    background-color: rgb(143, 145, 151)
}
.list2>ul:nth-child(3) .hit1{
    background-color:rgb(255, 0, 200)
}

.list1>ul>li h1 {
    color: white;
    padding-top: 80px;
}
.list2>ul>li h1 {
    color: white;
    padding-top: 80px;
}

.hit1 {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: hsl(0, 97%, 64%);
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    transition: all 0.2s ease;
    /* border-radius: 20px; */
}
.hit1>p,h2{
    margin-bottom: 20px;
    /* font-family: Arial, Helvetica, sans-serif; */
    font-style: italic;
    font-variant: small-caps;
}

.hit1>a {
    color: #000;
    text-decoration: none;
    background-color: #5dd5e7;
    padding: 10px 20px;
    border-radius: 10px;
}
.hide-h1:hover{
    display: none;
}

.list1>ul>li:hover .hit1{
    display: flex;
}
.list2>ul>li:hover .hit1{
    display: flex;
}
.exraj{
  text-align: center;
          background-image: url(./orange-star-img.png),url(./orange-star-img.png);
          background-repeat: no-repeat,no-repeat;
          background-position:0 0.35em, right 0.35em;
          /* background-size: 20px auto 20px auto; */
          /* border: 2px solid black; */
          width: 50%;
          margin: auto;
          font-size: 50px;
          margin-top: 4%;
          text-shadow:2px 2px 2px goldenrod;
}

</style>
<div class="container">
<h1 class="exraj">TRIP PLANS</h1>       


<div class="view">
  <div class="list1">
    <ul style="background-color: rgb(255, 204, 127);">
        <h2 style="margin-top: 40px; color: orangered;">RAJSTHAN</h2>
        <h3>The Land Of Maharaj's</h3>
    </ul>
    <ul>
        <li class="st" style="background-image: url(https://1.bp.blogspot.com/-MdTqkXrjMIg/XXeRzDGV3mI/AAAAAAAAAAQ/s3QFO7DvZ-kXPPJHabE2viEay5QEl-MWQCLcBGAs/s1600/images.jpg);">
                <h1 class="hide-h1"></h1>
                <div class="hit1" >
                <h2>10 DAYS  TRIP PLAN</h2>
                <p>In a 10-day trip, you can visit Jaipur, Udaipur, Jaisalmer, Jodhpur, Alwar, Bikaner, Mount Abu, Ajmer, Bharatpur, and Chittorgarh.</p>
                <a href="/bookingform">BOOK</a>
                </div>
        </li>
    </ul>
    </div>
    <div class="list2">

    <ul>
        <li class="st" style="background-image: url(https://d3d5bpai12ti8.cloudfront.net/wp-content/uploads/20200911134852/Rajasthan-Approves-New-Tourism-Policy-With-Focus-On-Lesser-known-Destinations.jpg);">
                <h1 class="hide-h1"></h1>
                <div class="hit1">
                <h2>7-8 DAYS TRIP PLAN</h2>
                <p>In a 7-8 day trip, you can explore Jaipur, Udaipur, Jaisalmer, Jodhpur, Bikaner, Mount Abu, and Chittorgarh in Rajasthan.</p>
                <a href="/bookingform">BOOK</a>
                </div>
        </li>
    </ul>
    <ul>
        <li class="st" style="background-image: url(https://th.bing.com/th/id/OIP.y9YywPH4yFmwI2ErcG_MSgHaE8?w=206&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7);">
                <h1 class="hide-h1"></h1>
                <div class="hit1">
                <h2>5-6 DAYS TRIP PLAN</h2>
                <p>In a 5-6 day trip, you can discover Jaipur, Udaipur, Jaisalmer, Jodhpur, Mount Abu, and Chittorgarh in Rajasthan.</p>
                <a href="/bookingform">BOOK</a>
                </div>
        </li>
    </ul>
    <ul>
        <li class="st" style="background-image: url(https://th.bing.com/th/id/OIP.GAzQyIuBEP03wMD6uGULvwHaDt?w=350&h=175&c=7&r=0&o=5&dpr=1.5&pid=1.7);">
                <h1 class="hide-h1"></h1>
                <div class="hit1" >
                <h2>1-3 DAYS TRIP PLAN</h2>
                <p>In a 1-3 day trip, you can visit Jaipur, the capital city of Rajasthan, known for its magnificent palaces and vibrant culture.</p>
                <a href="/bookingform">BOOK</a>
            </div>
        </li>
    </ul>
     <ul>
        </div>
</div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/home.blade.php ENDPATH**/ ?>