<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Places</title>
    <link rel="stylesheet" href="./rcss/main.css">
    <link rel="stylesheet" href="./rcss/navbar.css">

</head>
<body>
    <header>
        <div class="navbaar" id="topbar">
          <div class="nav-top"></div>
        
        <ul class="navbar">
         <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Discover</a>
          <ul class="dropdown-menu">
            <li class="dropdown-submenu">
                <a href="./destination" class="dropdown-toggle">Destination </a>
                <ul class="sub-dropdown-menu">
                  <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
                  <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
                  <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
                  <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
                  <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
                  <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
                  <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
                  <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
                  <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
                  <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
                </ul>
                </li>
            <li class="dropdown-submenu">
              <a href="./forts" class="dropdown-toggle">Fort</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
                <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
                <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
                <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
                <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
                <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
                <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
                <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
                <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
                <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
                <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
                <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
                <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
                <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
              </ul>
            </li>
            <li class="dropdown-submenu">
              <a href="./lakes" class="dropdown-toggle">Lake</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
                <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
                <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
                <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
                <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
                <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
              </ul>
            </li>
    
    
            <li class="dropdown-submenu">
              <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
                <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
                <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
                <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
                <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
                <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
                <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
                <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
                <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
                <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
              </ul>
            </li>
    
    
            <li class="dropdown-submenu">
              <a href="./place" class="dropdown-toggle">Places</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
                <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
                <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
                <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
                <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
                <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
                <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
                <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
                <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
                <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
                <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
                <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
                <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
                <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
                <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
                <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
                <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
                <li><a class="dropdown-item" href="./chittorghar#padminipalace">Padmini's Palace   </a></li>
                <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
                <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
                <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
                <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
                <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
                <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
                <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
                <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
                <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
                <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
                <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
                <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
                <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
                <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
                <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
                <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
                <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
                <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
                
              </ul>
            </li>
            
            <li class="dropdown-submenu">
              <a href="./museum" class="dropdown-toggle">Museum</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
                <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
                <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
                <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
                <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
                <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
                <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
                <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
                <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
                <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
                <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
                <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
                <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
                <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
               
              </ul>
            </li>
            <li class="dropdown-submenu">
              <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
                <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
                <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
                <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
                <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
                <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
                <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
                <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
                <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
                <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
                <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
                <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
                <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
                <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
                <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
                <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
                <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
                <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
                <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
                <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
                <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
              </ul>
            </li> 
          </ul>
          
    
    
        </li>
    
    
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Experience</a>
          <ul class="dropdown-menu">
             <li class="dropdown-submenu">
                <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
                </li>
                <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
                <a href="./adventures" class="dropdown-toggle">Adventures </a>
          </ul>
        </li>
    
    
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Plan</a>
          <ul class="dropdown-menu">
             <li class="dropdown-submenu">
                <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
                </li>
                <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
                <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
          </ul>
        </li>
        
    
        <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
       
      </ul>
      
        <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
      
    </div>
    <script>
        window.addEventListener('DOMContentLoaded', function () {
      var dropdowns = document.getElementsByClassName('dropdown');
      for (var i = 0; i < dropdowns.length; i++) {
        dropdowns[i].addEventListener('mouseover', function () {
          this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
        });
        dropdowns[i].addEventListener('mouseout', function () {
          this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
        });
      }
    });
    
    
    </script>
    </header>
</body>
<div class="top-bar">
    <h1>PLACE IN RAJASTHAN</h1>
    <h5>EXPLORE THE SPLENDOUR</h5>
</div>
 <div class="list">
            <ul>
                <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/The-Crystal-Gallery.jpg');">
                        <h1 class="hide-h1">THE CRYSTAL GALLERY</h1>
                        <div class="hit">
                        <h2>THE CRYSTAL GALLERY</h2>
                        <p>The Crystal Gallery is a unique museum located within Fateh Prakash Palace in Udaipur, Rajasthan, India. It houses a remarkable collection of crystal artifacts, including furniture, chandeliers, and decorative pieces, showcasing the opulence of the bygone era......</p>
                        <a href="./udaipur#thecrystalgallery">Explore</a>
                        </div>
                </li>
            </ul>
            <ul>
                <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/234.jpg);">
                        <h1 class="hide-h1">BAGORE KI HAVELI</h1>
                        <div class="hit" >
                        <h2>BAGORE KI HAVELI</h2>
                        <p>Bagore Ki Haveli is a historic mansion located in Udaipur, Rajasthan, India. It has been converted into a museum and cultural center, showcasing Rajput heritage, folk art, traditional costumes, and hosting cultural performances.....</p>
                        <a href="./udaipur#bagorekihaveli">Explore</a>
                        </div>
                </li>
            </ul>
            <ul>
                <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/224.jpg);">
                        <h1 class="hide-h1">MONSOON PALACE</h1>
                        <div class="hit">
                        <h2>MONSOON PALACE</h2>
                        <p>Monsoon Palace, also known as Sajjangarh Palace, is a hilltop palace located in Udaipur, Rajasthan, India. It offers panoramic views of the surrounding Aravalli hills and the city below, making it a popular tourist destination.......</p>
                        <a href="./udaipur#monsoonpalace">Explore</a>
                        </div>
                </li>
            </ul>
            <ul>
                <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/221.jpg);">
                        <h1 class="hide-h1">CITY PALACE</h1>
                        <div class="hit">
                        <h2>CITY PALACE</h2>
                        <p>City Palace, located in the heart of Udaipur, Rajasthan, India, is a magnificent palace complex. It showcases a fusion of Rajput and Mughal architectural styles, stunning courtyards, intricate artwork, and picturesque views of Lake Pichola.......</p>
                        <a href="./udaipur#citypalaceudaipur">Explore</a>
                        </div>
                </li>
            </ul>
            <ul>
                <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/162.jpg);">
                        <h1 class="hide-h1">RANISAR PADAMSAR</h1>
                        <div class="hit" >
                        <h2>RANISAR PADAMSAR</h2>
                        <p>Ranisar Padamsar are two artificial lakes located in the city of Jodhpur, Rajasthan, India. They were built to provide water to the city and add to its scenic beauty, offering a tranquil environment for visitors......</p>
                        <a href="./jodhpur#ranipadamsar">Explore</a>
                    </div>
                </li>
            </ul>
             <ul>
                <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/159.jpg);">
                    <h1 class="hide-h1">PHOOL MAHAL</h1>
                        <div class="hit" >
                        <h2>PHOOL MAHAL</h2>
                        <p>Phool Mahal, meaning "Flower Palace," is a stunning chamber located within the Mehrangarh Fort in Jodhpur, Rajasthan, India. It was built for the pleasure of the Maharajas and features intricate floral motifs, beautiful stained glass windows, and exquisite paintings.....</p>
                        <a href="./jodhpur#phoolmahal">Explore</a>
                    </div>
                </div>
                <div class="list">
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/JAISALMERLUNGEMEMORIAL.jpg);">
                                <h1 class="hide-h1">LAUNGEWALA WAR MEMORIAL</h1>
                                <div class="hit" >
                                <h2>LAUNGEWALA WAR MEMORIAL</h2>
                                <p>Laungewala War Memorial is a memorial site in Jaisalmer, Rajasthan, India, commemorating the Battle of Laungewala during the Indo-Pakistani War of 1971. It honors the bravery of Indian soldiers in defending the border......</p>
                                <a href="./jaisalmer#laungewalawarmemorial">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/suggested-itineraries/shahid-smarak.jpg');">
                                <h1 class="hide-h1">SHAHID SMARAK, AJMER</h1>
                                <div class="hit">
                                <h2>SHAHID SMARAK, AJMER</h2>
                                <p>Shahid Smarak in Ajmer is a memorial dedicated to the brave soldiers who sacrificed their lives for the nation. It stands as a tribute to their valor and serves as a reminder of their supreme sacrifice.....</p>
                                <a href="./ajmer#shahidsmarkajmer">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/VCT01.jpg);">
                                <h1 class="hide-h1">VICTORIA CLOCK TOWER</h1>
                                <div class="hit" >
                                <h2>VICTORIA CLOCK TOWER</h2>
                                <p>The Victoria Clock Tower, also called Rajabai Clock Tower, is an iconic Mumbai landmark known for its Victorian Gothic architecture and a clock brought from England, symbolizing the city's colonial heritage....</p>
                                <a href="./ajmer#victoriaclocktower">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://i.pinimg.com/originals/5d/aa/61/5daa61a6dd7b6062d12a8c84c0ae36b8.jpg);">
                                <h1 class="hide-h1">SONIJI KI NASIYAN</h1>
                                <div class="hit" >
                                <h2>SONIJI KI NASIYAN</h2>
                                <p>Soniji Ki Nasiyan is a Jain temple in Ajmer, India. Also known as Ajmer Jain Temple, it is famous for its intricate architecture, intricate carvings, and a stunning display of gold-plated wooden figures depicting the Jain concept of the universe.....</p>
                                <a href="./ajmer#sonijikinasiyan">Explore</a>
                            </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/19.jpg');">
                                <h1 class="hide-h1">BHANGARH</h1>
                                <div class="hit">
                                <h2>BHANGARH</h2>
                                <p>Bhangarh is a ghost town located in Rajasthan, India. Known for its eerie atmosphere and haunted reputation, it attracts curious visitors interested in paranormal experiences. The ruins of the ancient city offer a glimpse into its historical past.....</p>
                                <a href="./alwar#bhangarh">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/17.jpg);">
                                <h1 class="hide-h1">PURJAN VIHAR</h1>
                                <div class="hit" >
                                <h2>PURJAN VIHAR</h2>
                                <p>Purjan Vihar is a beautiful and aesthetic garden located in the heart of the city. Very attractive and good place for good time spent. Enjoyed with....</p>
                                <a href="./alwar#purjanvihar">Explore</a>
                                </div>
                        </li>
                    </ul>
                </div>
                <div class="list">
                    <ul>
                        <li class="s" style="background-image: url(https://preview.redd.it/tli2obdtboi41.jpg?auto=webp&s=ba164887d6709fef13875632d6a7a0d820137be2);">
                            <h1 class="hide-h1">ADHAI DIN KA JHONPDA</h1>
                                <div class="hit" >
                                <h2>ADHAI DIN KA JHONPDA</h2>
                                <p>Adhai Din Ka Jhonpda is a mosque in Ajmer, India. Originally a Sanskrit college, it was transformed into a mosque in just two-and-a-half days, hence its name....</p>
                                <a href="./ajmer#adhaidinkajhonpda">Explore</a>
                            </div>
                        </li>
                     </ul>
                     <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/15.jpg);">
                                <h1 class="hide-h1">MOOSI MAHARANI KI CHHATRI</h1>
                                <div class="hit">
                                <h2>MOOSI MAHARANI KI CHHATRI</h2>
                                <p>Moosi Maharani Ki Chhatri is a stunning cenotaph located in Alwar, Rajasthan, India. It is a magnificent example of Rajput architecture, adorned with intricate carvings and marble work, and serves as a memorial to Maharani Moosi, a queen of Alwar.......</p>
                                <a href="./alwar#moosimaharanikichhatri">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/13.png);">
                                <h1 class="hide-h1">ALWAR CITY PALACE</h1>
                                <div class="hit">
                                <h2>ALWAR CITY PALACE</h2>
                                <p>Alwar City Palace is a majestic palace complex situated in Alwar, Rajasthan, India. It showcases a blend of Rajput and Mughal architectural styles and houses a museum displaying artifacts, artworks, and historical treasures......</p>
                                <a href="./alwar#alwarcitypalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/157.jpg);">
                                <h1 class="hide-h1">UMAID BHAWAN PALACE</h1>
                                <div class="hit" >
                                <h2>UMAID BHAWAN PALACE</h2>
                                <p>Umaid Bhawan Palace is a magnificent palace located in Jodhpur, Rajasthan, India. Built in the Art Deco style, it is now a luxury hotel and museum, showcasing grand architecture and royal heritage....</p>
                                <a href="./jodhpur#umaidbhawanpalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/252.jpg);">
                                <h1 class="hide-h1">KAMAN</h1>
                                <div class="hit" >
                                <h2>KAMAN</h2>
                                <p>Kaman is a town located in the Bharatpur district of Rajasthan, India. It is known for its historical significance, including the Kaman Fort, which served as a strategic defense fortification during the Mughal period. The town also features ancient temples and mosques.....</p>
                                <a href="./bharatpur#kaman">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/250.jpg');">
                                <h1 class="hide-h1">DEEG</h1>
                                <div class="hit">
                                <h2>DEEG</h2>
                                <p>Deeg is a town in Rajasthan, India, known for its stunning Deeg Palace. The palace features impressive gardens, fountains, and palaces, showcasing the architectural grandeur of the bygone era.....</p>
                                <a href="./bharatpur#deeg">Explore</a>
                                </div>
                        </li>
                    </ul>
                </div>
                <div class="list">
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/CHjaimal.jpg');">
                                <h1 class="hide-h1">MOTI MAHAL</h1>
                                <div class="hit">
                                <h2>MOTI MAHAL</h2>
                                <p>JMoti Mahal, also known as the Pearl Palace, is a historic palace located in Jodhpur, Rajasthan, India. It is renowned for its exquisite architecture, intricate carvings, and stunning courtyard, reflecting the opulence of the Rajput era.......</p>
                                <a href="./jodhpur#motimahal">Explore</a>
                                </div>
                        </li>
                    </ul>
              
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Toad%20Rock%20View%20Point.jpg);">
                            <h1 class="hide-h1">TOAD ROCK VIEW POINT</h1>
                                <div class="hit" >
                                <h2>TOAD ROCK VIEW POINT</h2>
                                <p>Toad Rock View Point is a popular viewpoint located in Mount Abu, Rajasthan, India. It offers stunning panoramic views of the surrounding landscape, with the unique rock formation resembling a toad adding to its charm....</p>
                                <a href="./mountabu#toadrockviewpoint">Explore</a>
                                 </div>
                                 
                                 
                         </li>
                     </ul>
                     <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Guru%20Shikhar.jpg);">
                                <h1 class="hide-h1">GURU SHIKHAR</h1>
                                <div class="hit" >
                                <h2>GURU SHIKHAR</h2>
                                <p>Guru Shikhar is the highest peak in the Aravalli Range, located near Mount Abu, Rajasthan, India. It is a significant pilgrimage site with a temple dedicated to Lord Dattatreya and offers breathtaking views of the surrounding mountains and valleys.....</p>
                                <a href="./mountabu#gurushikhar">Explore</a>
                            </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Nathamal_Ji_Ki_Haweli.png);">
                                <h1 class="hide-h1">NATHMAL JI KI HAVELI</h1>
                                <div class="hit">
                                <h2>NATHMAL JI KI HAVELI</h2>
                                <p>Nathmal Ji Ki Haveli is a renowned haveli (mansion) located in Jaisalmer, Rajasthan, India. It is famous for its intricate architecture, including ornate carvings, exquisite jharokhas (balconies), and unique craftsmanship that displays a symmetrical design created by two brothers......</p>
                                <a href="./jaisalmer#nathmaljikihaveli">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/140.jpg);">
                                <h1 class="hide-h1">MANDIR PALACE</h1>
                                <div class="hit">
                                <h2>MANDIR PALACE</h2>
                                <p>Mandir Palace, located in Jaisalmer, Rajasthan, India, is a historic palace that has been converted into a heritage hotel. It showcases intricate Rajput and Mughal architectural styles and offers luxurious accommodations for guests.......</p>
                                <a href="./jaisalmer#mandirpalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/125.jpg');">
                                <h1 class="hide-h1">AMBER PALACE</h1>
                                <div class="hit">
                                <h2>AMBER PALACE</h2>
                                <p>Amber Palace, also known as Amer Palace, is a majestic fort located in Jaipur, Rajasthan, India. It showcases a blend of Rajput and Mughal architectural styles and offers stunning views of the surrounding landscape......</p>
                                <a href="./jaipur#amberpalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                </div>
                <div class="list">
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/103.jpg);">
                            <h1 class="hide-h1">CITY PALACE</h1>
                                <div class="hit" >
                                <h2>CITY PALACE</h2>
                                <p>City Palace is a splendid palace complex situated in the heart of Jaipur, Rajasthan, India. It showcases a fusion of Rajput and Mughal architectural elements and houses museums, courtyards, gardens, and stunning royal halls......</p>
                                <a href="./jaipur#citypalacejaipur">Explore</a>
                            </div>
                        </li>
                     </ul>
              
                     <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/107.jpg);">
                                <h1 class="hide-h1">HAWA MAHAL</h1>
                                <div class="hit" >
                                <h2>HAWA MAHAL</h2>
                                <p>Hawa Mahal, also known as the "Palace of Winds," is an iconic architectural marvel in Jaipur, Rajasthan, India. Its unique façade with numerous small windows and balconies was designed to allow royal women to observe street festivities while maintaining their privacy......</p>
                                <a href="./jaipur#hawamahal">Explore</a>
                            </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/366.jpg);">
                                <h1 class="hide-h1">AMAR JAWAN JYOTI</h1>
                                <div class="hit">
                                <h2>AMAR JAWAN JYOTI</h2>
                                <p>Amar Jawan Jyoti, located in India Gate, New Delhi, is a perpetual flame memorial dedicated to the unknown soldiers who sacrificed their lives for the country, serving as a symbol of India's valor and patriotism.......</p>
                                <a href="./jaipur#amarjawanjyoti">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/S551.jpg);">
                                <h1 class="hide-h1">MADHVENDRA PALACE, NAHARGARH</h1>
                                <div class="hit">
                                <h2>MADHVENDRA PALACE, NAHARGARH</h2>
                                <p>Madhavendra Palace, located in Nahargarh Fort, Jaipur, Rajasthan, India, is a stunning palace complex built for the queens of Jaipur. It features intricate frescoes, beautiful architecture, and offers panoramic views of the city........</p>
                                <a href="./jaipur#madhvendrapalace,nahargarh">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/81.jpg);">
                                <h1 class="hide-h1">RANA KUMBHA PALACE</h1>
                                <div class="hit" >
                                <h2>RANA KUMBHA PALACE</h2>
                                <p>Rana Kumbha Palace is a historic palace situated within the Chittorgarh Fort in Rajasthan, India. It was constructed by Rana Kumbha and showcases impressive architecture, intricate carvings, and stunning views of the surrounding area.....</p>
                                <a href="./chittorghar#ranakumbhapalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/destinations/CHjaimal.jpg');">
                                <h1 class="hide-h1">JAIMAL AND PATTA’S PALACE</h1>
                                <div class="hit">
                                <h2>JAIMAL AND PATTA’S PALACE</h2>
                                <p>Jaimal and Patta's Palace, located within the Chittorgarh Fort in Rajasthan, India, is a significant historical structure. It is associated with the valiant Rajput warriors Jaimal and Patta, known for their defense during the siege of Chittorgarh......</p>
                                <a href="./chittorghar#jaimalandpatta'spalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                </div>
                <div class="list">
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/72.jpg);">
                            <h1 class="hide-h1">PADMINI'S PALACE</h1>
                                <div class="hit" >
                                <h2>PADMINI'S PALACE</h2>
                                <p>Padmini's Palace, also known as Rani Padmini's Palace, is a historic structure in Chittorgarh, Rajasthan, India. It is renowned for its architectural beauty and is associated with the legendary Queen Padmini.....</p>
                                <a href="./chittorghar#padminipalace">Explore</a>
                            </div>
                        </li>
                     </ul>
              
                     <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/80.jpg);">
                                <h1 class="hide-h1">RATAN SINGH PALACE</h1>
                                <div class="hit">
                                <h2>RATAN SINGH PALACE</h2>
                                <p>Ratan Singh Palace is a majestic palace located in Chittorgarh, Rajasthan, India. It was built during the Rajput era and is known for its architectural grandeur and historical significance, attracting visitors from around the world.......</p>
                                <a href="./chittorghar#ratansinghpalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/40.jpg);">
                                <h1 class="hide-h1">LAXMI NIWAS PALACE</h1>
                                <div class="hit">
                                <h2>LAXMI NIWAS PALACE</h2>
                                <p>Laxmi Niwas Palace is a grand heritage hotel in Bikaner, Rajasthan, India. It boasts exquisite Indo-Saracenic architecture and offers luxurious accommodations for a regal and memorable experience......</p>
                                <a href="./bikaner#laxminiwaspalace">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/38.jpg');">
                                <h1 class="hide-h1">RAMPURIA HAVELI</h1>
                                <div class="hit">
                                <h2>RAMPURIA HAVELI</h2>
                                <p>Rampuria Haveli is a historic mansion located in the city of Bikaner, Rajasthan, India. It is known for its exquisite architecture and intricate designs......</p>
                                <a href="./bikaner#rampuriahaveli">Explore</a>
                                </div>
                        </li>
                    </ul>
                    <ul>
                        <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/305.jpg);">
                            <h1 class="hide-h1">MOTI DOONGRI</h1>
                                <div class="hit" >
                                <h2>MOTI DOONGRI</h2>
                                <p>Moti Dungri Alwar is a historic fort situated in Alwar, Rajasthan, India. Built on a hill, it offers panoramic views of the city. The fort is known for its beautiful architecture, including intricate carvings and stunning frescoes. It also houses a temple dedicated to Lord Krishna, attracting devotees and tourists alike.</p>
                                <a href="./alwar#motidoongri">Explore</a>
                            </div>
                        </li>
                   </ul>
                   <ul>
                    <li class="s" style="background-image: url(https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Raisar-dunes-camp-bikaner.jpg);">
                            <h1 class="hide-h1">RAISAR DUNES</h1>
                            <div class="hit" >
                            <h2>RAISAR DUNES</h2>
                            <p>Raisar Dunes is a picturesque desert destination located near Bikaner, Rajasthan, India. It offers breathtaking sand dunes, camel safaris, and a serene environment, making it a popular spot for desert exploration and camping....</p>
                            <a href="./bikaner#raisardunes">Explore</a>
                            </div>
                    </li>
                </ul>
                </div>
                
            </body>
            <footer>
                <div id="footer-placeholder"></div>
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script>
                  $(function() {
                    $("#footer-placeholder").load("footer");
                  });
                  </script>
     

     
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
                </html><?php /**PATH C:\xampp\htdocs\prjct\rajshthan\resources\views/place.blade.php ENDPATH**/ ?>