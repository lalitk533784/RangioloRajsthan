<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomePage</title>
    <link rel="stylesheet" href="./rcss/navbar.css">
    <link rel="stylesheet" href="./rcss/main.css">
</head>
<style>
   .slider {
  width: 100%;
  height: 500px;
  overflow: hidden;
  position: relative;
  /* margin-top: 200px; */
}

.slider img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s ease;
}

.slider-controls {
  position: absolute;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
}


.prev-btn,
.next-btn {
  padding: 10px 20px;
  background-color: transparent;
  /* color: #fff; */
  border: none;
  cursor: pointer;
  margin: 0 5px;
}


.list1{
    display: grid;
    grid-template-columns: 38% 62%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid red; */
    
}
.list2{
    display: grid;
    grid-template-columns: 34% 33% 33%;
    /* grid-template-rows: 33% 33%; */
    text-align: center;
    /* border: 2px solid black; */
    
}
.view{
  margin-top: 50px;
  border: 1px solid orange;
}

.st {
    /* background-image: url('https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/101.jpg'); */
    background-repeat: no-repeat;
    background-size: cover;
    /* border-radius: 20px; */
}

.list1>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed green; */
    /* margin: 0; */
}
.list2>ul>li {
    height: 200px;
    list-style: none;
    position: relative;
    /* border: 2px dashed gold; */
}

 .list1>ul:nth-child(2) .hit1{
    background-color: gold
} 
.list2>ul:nth-child(1) .hit1{
    background-color: rgb(153, 255, 0)
}
.list2>:nth-child(2) .hit1{
    background-color: rgb(143, 145, 151)
}
.list2>ul:nth-child(3) .hit1{
    background-color:rgb(255, 0, 200)
}

.list1>ul>li h1 {
    color: white;
    padding-top: 80px;
}
.list2>ul>li h1 {
    color: white;
    padding-top: 80px;
}

.hit1 {
    display: none;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: hsl(0, 97%, 64%);
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    transition: all 0.2s ease;
    /* border-radius: 20px; */
}
.hit1>p,h2{
    margin-bottom: 20px;
    /* font-family: Arial, Helvetica, sans-serif; */
    font-style: italic;
    font-variant: small-caps;
}

.hit1>a {
    color: #000;
    text-decoration: none;
    background-color: #5dd5e7;
    padding: 10px 20px;
    border-radius: 10px;
}
.hide-h1:hover{
    display: none;
}

.list1>ul>li:hover .hit1{
    display: flex;
}
.list2>ul>li:hover .hit1{
    display: flex;
}
.exraj{
  text-align: center;
          background-image: url(./orange-star-img.png),url(./orange-star-img.png);
          background-repeat: no-repeat,no-repeat;
          background-position:0 0.35em, right 0.35em;
          /* background-size: 20px auto 20px auto; */
          /* border: 2px solid black; */
          width: 50%;
          margin: auto;
          font-size: 50px;
          margin-top: 4%;
          text-shadow:2px 2px 2px goldenrod;
}
.iframe{
  width: 95%;
  margin: auto;
  display: grid;
  grid-template-columns: 48% 48%;
  justify-content: space-between;
  margin-top: 10px;
}


</style>
  <header class="nnavbar">
  <div class="navbaar" id="topbar">
    <div class="nav-top"></div>
  
  <ul class="navbar">
   <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Discover</a>
    <ul class="dropdown-menu">
      <li class="dropdown-submenu">
          <a href="./destination" class="dropdown-toggle">Destination </a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
            <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
            <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
            <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
            <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
            <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
            <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
            <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
            <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
          </ul>
          </li>
      <li class="dropdown-submenu">
        <a href="./forts" class="dropdown-toggle">Fort</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
          <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
          <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
          <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
          <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
          <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
          <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
          <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./lakes" class="dropdown-toggle">Lake</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
          <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
          <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
          <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
          <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
          <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
          <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
          <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
          <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
          <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
        </ul>
      </li>


      <li class="dropdown-submenu">
        <a href="./place" class="dropdown-toggle">Places</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
          <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
          <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
          <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
          <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
          <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
          <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
          <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
          <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
          <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
          <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
          <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
          <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
          <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
          <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
          <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
          <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
          <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
          <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
          <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
          <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
          <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
          <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
          <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
          <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
          <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
          <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
          <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
          <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
          <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
          <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
          
        </ul>
      </li>
      
      <li class="dropdown-submenu">
        <a href="./museum" class="dropdown-toggle">Museum</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
          <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
          <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
          <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
          <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
          <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
          <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
          <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
          <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
          <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
          <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
          <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
         
        </ul>
      </li>
      <li class="dropdown-submenu">
        <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
        <ul class="sub-dropdown-menu">
          <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
          <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
          <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
          <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
          <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
          <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
          <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
          <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
          <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
          <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
          <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
          <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
          <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
          <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
          <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
          <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
          <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
          <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
          <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
          <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
          <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
          <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
          <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
        </ul>
      </li> 
    </ul>
    


  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Experience</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
          <a href="./adventures" class="dropdown-toggle">Adventures </a>
    </ul>
  </li>


  <li class="dropdown">
    <a href="#" class="dropdown-toggle ">Plan</a>
    <ul class="dropdown-menu">
       <li class="dropdown-submenu">
          <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
          </li>
          <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
          <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
    </ul>
  </li>
  

  <li class="dropdown-toggle"><a href="./aboutus">About Us</a></li>

  <!-- <li><button id="changeColorButton">Change Color</button></li> -->

</ul>

  <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->

</div>
<script>
  window.addEventListener('DOMContentLoaded', function () {
var dropdowns = document.getElementsByClassName('dropdown');
for (var i = 0; i < dropdowns.length; i++) {
  dropdowns[i].addEventListener('mouseover', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
  });
  dropdowns[i].addEventListener('mouseout', function () {
    this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
  });
}
});




 
  // const changeColorButton = document.getElementById('changeColorButton');

  
  // changeColorButton.addEventListener('click', function() {
 
  //   document.body.style.backgroundColor = ' #ceec74';

   
  //   const navbar = document.querySelector('.navbar');
  //   navbar.style.backgroundColor = ' #ceec74';

  //   const navtop=document.querySelector('.nav-top');
  //   navtop.style.backgroundColor=' #ceec74';
    
  //   const footer = document.querySelector('.foot');
  //   footer.style.backgroundColor = ' #ceec74';
  // });







</script>
</header>
<body>
    <!-- images slide -->
    <div class="slider">
        <img src="./rimages/21.png" alt="Image 1">
        <img src="https://th.bing.com/th/id/R.765ffc2d89cdf17e8a514a80dfa7a270?rik=vint93mRpu3%2bLg&riu=http%3a%2f%2fwww.delhirajasthancartour.com%2fimages%2fwildlife-Ranthambore-in-Rajasthan.jpg&ehk=fb%2fj3%2fdjfQySPV4T3Hya4uDFaUJdUkHL6A%2b4bj0wY9U%3d&risl=&pid=ImgRaw&r=0" alt="Image 2">
        <img src="https://pickyourtrail.com/blog/wp-content/uploads/2020/05/sreehari-devadas-5ClFC_CmboA-unsplash-scaled.jpg" alt="Image 3">
        <img src="https://images.pexels.com/photos/9179927/pexels-photo-9179927.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Image 3">
        <img src="https://images.pexels.com/photos/13458334/pexels-photo-13458334.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Image 3">  
      
        <div class="slider-controls">
          <button class="prev-btn"><span style="font-size: 25px; color: orange;">&#8810</span></button>
          <button class="next-btn"><span style="font-size: 25px;  color: orange;">&#8811</span></button>
        </div>
      </div>
      
    
       <h1 class="exraj">Explore The Rajasthan</h1>       


    <div class="view">
      <div class="list1">
        <ul style="background-color: rgb(255, 204, 127);">
            <h2 style="margin-top: 40px; color: orangered;">RAJSTHAN</h2>
            <h3>The Land Of Maharaj's</h3>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://c0.wallpaperflare.com/preview/308/232/8/amber-fort-fort-jaipur-rajasthan.jpg);">
                    <h1 class="hide-h1">FORTS</h1>
                    <div class="hit1" >
                    <h2>FORTS</h2>
                    <!-- <p>Kishangarh Fort: Ancient Splendor of Rajasthan's Architectural Heritage.</p> -->
                    <a href="./forts">Explore</a>
                    </div>
            </li>
        </ul>
        </div>
        <div class="list2">

        <ul>
            <li class="st" style="background-image: url(https://c4.wallpaperflare.com/wallpaper/135/524/987/jaguar-big-cute-wild-cat-desktop-hd-wallpaper-for-mobile-phones-tablet-and-pc-3840%C3%972160-wallpaper-preview.jpg);">
                    <h1 class="hide-h1">WILDLIFE</h1>
                    <div class="hit1">
                    <h2>WILDLIFE</h2>
                    <!-- <p>Bala Qila: Majestic Fortress Overlooking the City's Rich History.</p> -->
                    <a href="./WILDLIFE">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://media.gettyimages.com/photos/pichola-lake-udaipur-rajasthan-india-picture-id929981226);">
                    <h1 class="hide-h1">LAKES</h1>
                    <div class="hit1">
                    <h2>LAKES</h2>
                    <!-- <p>"Neemrana Fort: Majestic Heritage, Architectural Splendor, Timeless Luxury Retreat".</p> -->
                    <a href="./lakes">Explore</a>
                    </div>
            </li>
        </ul>
        <ul>
            <li class="st" style="background-image: url(https://c1.wallpaperflare.com/preview/754/592/45/architecture-travel-wood-building-ornament-oriental.jpg);">
                    <h1 class="hide-h1">PALACES</h1>
                    <div class="hit1" >
                    <h2>PALACES</h2>
                    <!-- <p>Junagarh Fort is a historical fort located in Bikaner, Rajasthan, India..</p> -->
                    <a href="./palace">Explore</a>
                </div>
            </li>
        </ul>
         <ul>
            </div>
    </div>
     
<div style="width:98%;margin:auto;margin-top: 50px; "><img style="width: 100%;" src="./rimages/map.jpg" alt=""></div>
<div style="width:98%;margin:auto; ">
  <h1 style="text-align: center;">History Of Rajasthan</h1>
  <p style="margin-top: 10px;text-indent:14px">Rajasthan, located in the northwest part of India, has a fascinating and diverse history that spans several centuries. From ancient civilizations to Rajput kingdoms, Mughal influence, and British rule, Rajasthan's history is a tapestry of cultural, architectural, and historical significance.</p>
  <p style="margin-top: 8px;text-indent:14px">In the ancient period, Rajasthan was inhabited by early humans since prehistoric times. Evidence of human settlements dating back to the Stone Age has been found in the region. Over time, various ancient civilizations, including the Indus Valley Civilization and the Mauryan Empire, flourished in Rajasthan. Powerful kingdoms such as the Matsya Kingdom, the Malavas, the Arjunyas, and the Yaudheyas emerged, shaping the early history of the region.

During the medieval period, Rajasthan witnessed the rise of Rajput clans, who became synonymous with valor, chivalry, and independence. Prominent Rajput dynasties like the Chauhans of Ajmer and Delhi, the Rathores of Marwar (Jodhpur), the Sisodiyas of Mewar (Udaipur), the Kachwahas of Amber (Jaipur), and the Hadas of Kota ruled over various parts of Rajasthan. The Rajput rulers constructed magnificent forts, palaces, and temples, leaving behind a remarkable architectural legacy.

The Mughal Empire exerted its influence over Rajasthan during the 16th century. Mughal emperors like Akbar and Shah Jahan held control over certain regions of Rajasthan. The Mughals left an indelible mark on the art, culture, and architecture of Rajasthan, leading to a unique blend of Rajput and Mughal styles.</p>
  <p style="margin-top: 8px;text-indent:14px">In the 18th century, Rajasthan experienced the domination of the Marathas, who established their rule in parts of the region. With the decline of the Mughal Empire, several Rajput states formed alliances with the British East India Company. Gradually, the British expanded their influence, resulting in the formation of the princely states of Rajasthan under indirect British rule.

After India gained independence from British colonial rule in 1947, the princely states of Rajasthan were integrated into the newly formed Union of India. Rajasthan became a separate state on March 30, 1949, and underwent administrative reorganization to its present form.

Rajasthan's rich cultural heritage is a testament to its history. The state is renowned for its vibrant folk music, dance forms like Ghoomar and Kalbeliya, exquisite handicrafts, colorful attire, and traditional festivals. Magnificent palaces, forts, and havelis, such as Amber Fort, Mehrangarh Fort, Umaid Bhawan Palace, and City Palace, stand as architectural marvels, attracting tourists from around the world.</p>
  <p style="margin-top: 8px;text-indent:14px">Today, Rajasthan stands as a vibrant testament to its historical past. Its captivating history, cultural traditions, and architectural wonders continue to enchant visitors, making it a sought-after destination for those seeking a glimpse into the royal and cultural heritage of India.</p>
</div>

    <div class="iframe">
    <iframe width="100%" height="400" src="https://www.youtube.com/embed/oTTSBK_ahMI?autoplay=1&loop=1" title="Best Place To Visit In Summer In Rajasthan" frameborder="0" allow="accelerometer;  clipboard-write; gyroscope;" allowfullscreen></iframe>
      <iframe width="100%" height="400"  src="https://www.youtube.com/embed/qD7TlZuPdKs" title="Mukundara Hills Tiger Reserve Kota | Rajasthan Tourism |" frameborder="0" allow="accelerometer;  clipboard-write;" allowfullscreen></iframe></div>


      

    
</body>
<footer>
        <div id="footer-placeholder"></div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
          $(function() {
            $("#footer-placeholder").load("footer");
          });
          </script>
</footer>
<html>
<script>
let slideIndex = 1;
const images = document.querySelectorAll('.slider img');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');

function showSlide(n) {
  if (n < 1) {
    slideIndex = images.length;
  } else if (n > images.length) {
    slideIndex = 1;
  }

  for (let i = 0; i < images.length; i++) {
    images[i].style.display = 'none';
  }
  images[slideIndex - 1].style.display = 'block';
}
function prevSlide() {
  showSlide(slideIndex -= 1);
}
function nextSlide() {
  showSlide(slideIndex += 1);
}
setInterval(() => {
  showSlide(slideIndex += 1);
}, 2500);

prevBtn.addEventListener('click', prevSlide);
nextBtn.addEventListener('click', nextSlide);

showSlide(slideIndex);

</script>


<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>





<?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/welcome.blade.php ENDPATH**/ ?>