<!DOCTYPE HTML>
 <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foreign Torists</title>
    <link rel="stylesheet" href="./rcss/navbar.css">
</head>

<style>
    *{
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
    body{
        height: auto;
        width: 100%;
        background-color: rgb(250, 245, 228);
    }
    .container{
        height: 70vh;
        width: 100%;
        background-image: url(https://www.lifeberrys.com/img/article/foreign-tourist-in-rajastha-1614592578-lb.jpg);
        background-repeat: no-repeat;
        background-size: cover;

    }
    .main h2{
        text-align: center;
    }
    li{
    list-style: none   ;
    }
    .main {
        margin-left: 50px;
        margin-right: 50px;
    }
    .main1{
        margin-left: 50px;
        margin-right: 50px;
    }
</style>
<body>
    <header>
        <div class="navbaar" id="topbar">
          <div class="nav-top"></div>
        
        <ul class="navbar">
         <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Discover</a>
          <ul class="dropdown-menu">
            <li class="dropdown-submenu">
                <a href="./destination" class="dropdown-toggle">Destination </a>
                <ul class="sub-dropdown-menu">
                  <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
                  <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
                  <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
                  <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
                  <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
                  <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
                  <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
                  <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
                  <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
                  <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
                </ul>
                </li>
            <li class="dropdown-submenu">
              <a href="./forts" class="dropdown-toggle">Fort</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
                <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
                <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
                <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
                <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
                <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
                <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
                <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
                <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
                <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
                <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
                <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
                <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
                <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
              </ul>
            </li>
            <li class="dropdown-submenu">
              <a href="./lakes" class="dropdown-toggle">Lake</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
                <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
                <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
                <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
                <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
                <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
                <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
                <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
              </ul>
            </li>
    
    
            <li class="dropdown-submenu">
              <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
                <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
                <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
                <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
                <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
                <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
                <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
                <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
                <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
                <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
              </ul>
            </li>
    
    
            <li class="dropdown-submenu">
              <a href="./place" class="dropdown-toggle">Places</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
                <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
                <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
                <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
                <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
                <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
                <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
                <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
                <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
                <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
                <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
                <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
                <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
                <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
                <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
                <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
                <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
                <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
                <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
                <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
                <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
                <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
                <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
                <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
                <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
                <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
                <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
                <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
                <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
                <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
                <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
                <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
                <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
                <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
                <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
                <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
                
              </ul>
            </li>
            
            <li class="dropdown-submenu">
              <a href="./museum" class="dropdown-toggle">Museum</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
                <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
                <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
                <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
                <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
                <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
                <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
                <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
                <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
                <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
                <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
                <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
                <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
                <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
                <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
               
              </ul>
            </li>
            <li class="dropdown-submenu">
              <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
                <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
                <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
                <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
                <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
                <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
                <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
                <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
                <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
                <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
                <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
                <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
                <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
                <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
                <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
                <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
                <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
                <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
                <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
                <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
                <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
                <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
                <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
                <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
                <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
              </ul>
            </li> 
          </ul>
          
    
    
        </li>
    
    
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Experience</a>
          <ul class="dropdown-menu">
             <li class="dropdown-submenu">
                <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
                </li>
                <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
                <a href="./adventures" class="dropdown-toggle">Adventures </a>
          </ul>
        </li>
    
    
        <li class="dropdown">
          <a href="#" class="dropdown-toggle ">Plan</a>
          <ul class="dropdown-menu">
             <li class="dropdown-submenu">
                <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
                </li>
                <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
                <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
          </ul>
        </li>
        
    
        <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
       
      </ul>
      
        <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
      
    </div>
    <script>
        window.addEventListener('DOMContentLoaded', function () {
      var dropdowns = document.getElementsByClassName('dropdown');
      for (var i = 0; i < dropdowns.length; i++) {
        dropdowns[i].addEventListener('mouseover', function () {
          this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
        });
        dropdowns[i].addEventListener('mouseout', function () {
          this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
        });
      }
    });
    
    
    </script>
    </header>


    <div class="container">

    </div>
    <div class="main">
        <h2>FOREIGN TOURISTS</h2>
        <p>If Rajasthan is your choice for an international vacation getaway, then you couldn't have picked a better destination. This 'royal state' is a beautiful representation of India's rich architectural heritage, cultural diversity and hospitality.</p>
        <p>But don't take our word for it. We wholeheartedly welcome you to revel in the sights, sounds and flavours of Rajasthan.

        </p>
        <p>
            Below are a few things you will need to know:


        </p>
    </div>
    <div class="main1">
        <h3>VISA RULES</h3>
        <p>
            The below instructions and information are general in nature; however, for specific information, we urge you to visit or contact the Indian Mission / Embassy website as per your country of residence.
        </p>
<p>
    
A passport that is valid for a minimum of six months beyond the date of intended return from India should ideally accompany your visa applications.
</p>
<p>
Foreign tourists holding other nationalities (other than the country where applying for visa), should submit proof of long-term (at least three years)/ permanent residence in the country (where applying). For citizens of other countries, a reference has to be made to their country of residence for which an additional fee is chargeable and will also involve extra processing time. Please refrain from making inquiries about the status of the application during this time.
</p>

<p>
Following visas are available from the Indian missions abroad:
        </p>

        <div class="main2">
            <h3>
                TOURIST VISA
            </h3>
            <p>
                This is given for 6 months normally; it may vary depending on the country of residence. The applicant is required to produce/submit documents in proof of his financial standing. Tourists travelling in groups of not less than four members under the auspices of a recognized travel agency may be considered for grant of collective tourist visa.
            </p>

        </div>
        <div class="main2">
            <h3>
                BUSINESS VISA
            </h3>
            <p>
                This is valid for one year or more with multiple entries. A letter from the sponsoring organization indicating nature of business, probable duration of stay, places and organizations to be visited incorporating therein a guarantee to meet maintenance expenses, etc. should accompany the application.


            </p>

        </div>
        <div class="main2">
            <h3>
                STUDENT VISA
            </h3>
            <p>
                These is issued for the duration of the academic course of study or for a period of five years whichever is less, on the basis of firm letters of admission from universities/recognized colleges or educational institutions in India. Change of purpose and institutions are not permissible.
            </p>

        </div>
        <div class="main2">
            <h3>
                EMPLOYMENT VISA
            </h3>
            <p>
                This is issued to skilled and qualified professionals or persons who are engaged or appointed by companies, organizations, economic undertakings as technicians, technical experts, senior executives etc. Applicants are required to submit proof of
            </p>

        </div>
        <div class="main2">
            <h3>
                CONFERENCE VISA
            </h3>
            <p>
                This is issued for attending conferences/seminars/meetings in India. A letter of invitation from the organizer of the conference is to be submitted along with the visa application. Delegates coming for conferences may combine tourism with attending conferences.
            </p>

        </div>
        <div class="main2">
            <h3>
                JOURNALIST VISA

            </h3>
            <p>
                This is issued to professional journalists and photographers for visiting India. The applicants are required to contact on arrival in New Delhi, the External Publicity Division of the Ministry of External Affairs and, in other places, the Office of the Government of India's Press Information Bureau.
            </p>

        </div>
        <div class="main2">
            <h3>
                VISA TO MISSIONARIES
            </h3>
            <p>
                This is valid for single entry and duration as permitted by Government of India. A letter in triplicate from sponsoring organization indicating intended destination in India, probable length of stay, and nature of duties to be discharged should be submitted along with guarantee for applicant's maintenance while in India.
            </p>

        </div>
        <div class="main2">
            <h3>
                TRANSIT VISA
            </h3>
            <p>
                This is issued for a maximum period of 15-days with single/double entry facilities to bonafide transit passengers only.
            </p>

        </div>
        

    </div>
    <div class="main1">
        <h3>GUIDELINES</h3>
        <p>
            To ensure comfortable and safe stay in Rajasthan, we have listed out Code of Conduct for the tourists.
        </p>

        <div class="main2">
            <h3>DO's</h3>
            <h3>
                ACCOMMODATION:
            </h3>
            <p>
Always check in to the Approved/Classified Hotels, Approved Guest Houses/Paying Guest Houses, Bed-and-Breakfast Units, Government-run hotels, and hotels with credible reviews.
</p>
<p>

Whenever possible, make enquiries at nearby Tourist Reception Centres or Information Bureaus run by Rajasthan Tourism.
</p>
<h3>
TRANSPORT:
</h3>
<p>
Whenever required, hire auto-rickshaws or taxis only from the pre-paid kiosks at Airports, Railway Stations or Bus Stands, Government approved Travel Agencies and transport unit of RTDC. Aggregator Apps are also recommended for hiring a taxi/cab.
</p>

<p>
If a prepaid auto-rickshaw/taxi is not available, fare/charges should be negotiated in advance before embarking on the journey.
</p>
<p>

Make enquiries about total distances and tourist places to be covered before setting out on sightseeing.</p>
<h3>SHOPPING:</h3>
<p>Prefer purchasing from reputed/recognised shops or Government emporiums such as Rajasthali.</p>
<p>Always insist for a bill against the purchases made.</p>

<p>Payments made by credit cards must have the amount mentioned on the Bill/Voucher/Receipt in both, words and numbers. Don’t share Unique Identification Number(UID) or credit card number.</p>
<p>Avoid associating with unknown persons for shopping.</p>
<p>Avoid taking help of guides /drivers in shopping.</p>
<h3>MONEY EXCHANGE:</h3>
<p>Money exchange transactions should be done only from the authorised money exchangers, always get a receipt for every transaction.</p>

<p>IN CASE OF ANY MISHAPPENING:</p>


<p>Inform the nearest Police Station/Police Control Room/ Dial- 100 immediately or TAF (Tourist Assistance Force) personnel posted near monuments.</p>
<p>Miscellaneous:</p>

<p>You are advised to dress according to local cultural ethos and sensibilities. Ensure your passport and other precious belongings are safe, never give these to strangers, shopkeepers or hotel staff. </p>










           

        </div>
        <div class="main2">
            <h3>DON'Ts</h3>
  <h3>ACCOMMODATION:</h3>    
  <p>It is advisable to interact only with persons at tourist places and places of stay who carry some valid ID. Interaction with total strangers should be avoided.</p>    


<p>Avoid low-priced/ free rides offered by taxi/cab drivers to a hotel. Cross check for hotels/ PG/ lodges with the Tourist</p>

           

        </div>
        <div class="main2">
            <h3>MOBILE OPERATORS</h3>
            <li>Airtel
                
                
              </li>
            <li>BSNL</li>
            <li>VI</li>
            <li>JIO</li>
            <p>"All major telecom service providers have centres in main cities and also can be found at airports."</p>
           </div>
          </div>
          

        
</body>


<footer>
    <div id="footer-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#footer-placeholder").load("footer");
      });
      </script>

      
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
</html>
<?php /**PATH C:\xampp\htdocs\rajshthan5\rajshthan\resources\views/forgin.blade.php ENDPATH**/ ?>