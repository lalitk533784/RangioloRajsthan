<!doctype HTML>
 <html lang="en">

<head>
  <title>MountAbu</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
  
   

</head>


    <header>
      <div class="navbaar" id="topbar">
        <div class="nav-top"></div>
      
      <ul class="navbar">
       <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Discover</a>
        <ul class="dropdown-menu">
          <li class="dropdown-submenu">
              <a href="./destination" class="dropdown-toggle">Destination </a>
              <ul class="sub-dropdown-menu">
                <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
                <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
                <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
                <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
                <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
                <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
                <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
                <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
                <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
                <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
              </ul>
              </li>
          <li class="dropdown-submenu">
            <a href="./forts" class="dropdown-toggle">Fort</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
              <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
              <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
              <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
              <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
              <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
              <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
              <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
              <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
              <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
              <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
              <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
              <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
              <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
            </ul>
          </li>
          <li class="dropdown-submenu">
            <a href="./lakes" class="dropdown-toggle">Lake</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
              <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
              <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
              <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
              <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
              <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
              <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
              <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
            </ul>
          </li>
  
  
          <li class="dropdown-submenu">
            <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
              <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
              <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
              <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
              <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
              <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
              <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
              <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
              <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
              <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
            </ul>
          </li>
  
  
          <li class="dropdown-submenu">
            <a href="./place" class="dropdown-toggle">Places</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
              <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
              <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#sahidsmarkajmer">Sahid Smark Ajmer</a></li>
              <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
              <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
              <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
              <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
              <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
              <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
              <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
              <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
              <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
              <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
              <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
              <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
              <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
              <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
              <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
              <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
              <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
              <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
              <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
              <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
              <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
              <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
              <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
              <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
              <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
              <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
              <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
              <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
              <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
              <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
              <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
              <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
              <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
              
            </ul>
          </li>
          
          <li class="dropdown-submenu">
            <a href="./museum" class="dropdown-toggle">Museum</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
              <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
              <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
              <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
              <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
              <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
              <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
              <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
              <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
              <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
              <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
              <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
              <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
              <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
             
            </ul>
          </li>
          <li class="dropdown-submenu">
            <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
              <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
              <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
              <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
              <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
              <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
              <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
              <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
              <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
              <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
              <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
              <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
              <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
              <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
              <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
              <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
              <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
              <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
              <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
              <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
              <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
              <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
              <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
              <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
              <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
            </ul>
          </li> 
        </ul>
        
  
  
      </li>
  
  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Experience</a>
        <ul class="dropdown-menu">
           <li class="dropdown-submenu">
              <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
              </li>
              <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
              <a href="./adventures" class="dropdown-toggle">Adventures </a>
        </ul>
      </li>
  
  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle ">Plan</a>
        <ul class="dropdown-menu">
           <li class="dropdown-submenu">
              <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
              </li>
              <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
              <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
        </ul>
      </li>
      
  
      <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
     
    </ul>
    
      <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
    
  </div>
  <script>
      window.addEventListener('DOMContentLoaded', function () {
    var dropdowns = document.getElementsByClassName('dropdown');
    for (var i = 0; i < dropdowns.length; i++) {
      dropdowns[i].addEventListener('mouseover', function () {
        this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
      });
      dropdowns[i].addEventListener('mouseout', function () {
        this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
      });
    }
  });
  
  
  </script>
  </header>
  <body>
  <main>
    <div class="container-fluid front " style="  background-image: url(https://images.unsplash.com/photo-1611076763501-55d80ccc93cb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bW91bnQlMjBhYnV8ZW58MHx8MHx8fDA%3D&w=1000&q=80);">
      <h1 class="home"> MOUNT ABU </h1>
      <h3 class="home1">HILL STATION OF RAJASTHAN</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>Mount Abu</h1>
          <h2>The Oasis of Rajasthan</h2>
          </div>
          <div class="conte">
            <p>
                Nestled amidst the Aravalli range, Mount Abu, the lone hill station in Rajasthan, offers respite from the scorching desert climate. With tribal dwellings, elegant British-style bungalows, and royal holiday lodges, it captivates with its diverse architecture. Surrounded by lush forests, tranquil lakes, and cascading waterfalls, the region presents breathtaking panoramas year-round. Mount Abu holds religious significance for Jains and attracts history enthusiasts with its remarkable architectural wonders. It remains a prominent destination in Rajasthan tour packages, including those by Rajasthan Tourism.
            </p>
            
            </div>

            <div class="title">
                <h4>A little into the background</h4>
                  </div>
                  <div class="conte">
                    <p>
                      
Mount Abu's history dates back to the Puranic Age, where it served as a retreat for Sage Vashistha after his conflict with Sage Vishwamitra. Legends speak of a serpent named Arbhuda saving Lord Shiva's mount, Nandi, leading to the name "Mount Abu." Sage Vashistha's yajna on the peak brought forth the Agnivamsha Rajputs.
                    </p>
                    
                    </div>
                    <div class="title">
                        <h4>History of Mount Abu</h4>
                          </div>
                          <div class="conte">
                            <p>
                                Mount Abu, also known as Arbhuda Mountains, holds historical significance as the home of the Gurjaras, as highlighted by inscriptions like Dhanpala's "Tilakamanjari."
                            </p>
                            
                            </div>
                           
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN AJMER
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://mountabu.tourismindia.co.in/images/places-to-visit/header/achalgarh-fort-mount-abu-tourism-entry-fee-timings-holidays-reviews-header.jpg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="achalgarhfort">ACHALGARH FORT</h1></li>
                                        <li><p>Achalgarh Fort is a historic fort located near Mount Abu in Rajasthan, India. It was built in the 14th century by Maharana Kumbha of Mewar. The fort is known for its impressive architecture and strategic location atop a hill, offering panoramic views of the surrounding area. It houses several ancient temples, including the famous Achaleshwar Mahadev Temple. Achalgarh Fort is a popular tourist destination, attracting visitors with its rich history and scenic beauty.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Nakki%20Lake.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="nakkilake">NAKKI LAKE</h1></li>
                                        <li><p>Nakki Lake, located in Mount Abu, Rajasthan, is a serene and picturesque lake that holds great significance. Surrounded by hills and offering breathtaking views, it is believed to have been created by the gods using their nails (nakki in Hindi). The lake is a popular tourist attraction, offering boating facilities and a peaceful ambiance for visitors to enjoy. Its tranquil waters and stunning surroundings make Nakki Lake a must-visit destination in Mount Abu.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/AMS01.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="mountabusanctuary">MOUNT ABU SANCTUARY</h1></li>
                                  <li><p>The Mount Abu Sanctuary is a wildlife sanctuary located in the Aravalli Range in Rajasthan, India. Spanning an area of approximately 290 square kilometers, it is known for its diverse flora and fauna. The sanctuary is home to various species including Indian leopard, sloth bear, wild boar, sambar deer, and many bird species. It offers breathtaking natural beauty with its rugged terrain, dense forests, and serene lakes, making it a popular destination for nature enthusiasts and wildlife lovers.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Dilwara%20Jain%20Temple.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="dilwarajaintemple">DILWARA JAIN TEMPLE</h1></li>
                                  <li><p>The Dilwara Jain Temple is a renowned religious site located in the hill town of Mount Abu, Rajasthan, India. Known for its exquisite marble architecture and intricate stone carvings, the temple complex consists of five temples dedicated to different Jain Tirthankaras. Built between the 11th and 13th centuries, the Dilwara Jain Temple is considered a masterpiece of craftsmanship and a significant pilgrimage site for Jains worldwide. It attracts visitors with its stunning beauty and spiritual ambiance.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Guru%20Shikhar.jpg" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="gurushikhar">GURU SHIKHAR</h1></li>
                                <li><p>Guru Shikhar is the highest peak in the Aravalli Range of Rajasthan, India. Located near Mount Abu, it stands at an elevation of 1,722 meters (5,650 feet) above sea level. The peak is named after Dattatreya, a revered sage and deity in Hinduism. Guru Shikhar offers breathtaking panoramic views of the surrounding hills and valleys, making it a popular destination for tourists and spiritual seekers.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/explore/Toad%20Rock%20View%20Point.jpg" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="toadrockviewpoint">TOAD ROCK VIEW POINT</h1></li>
                                <li><p>Toad Rock Viewpoint is a picturesque location renowned for its natural beauty and panoramic vistas. Situated atop a rocky outcrop, it offers stunning views of the surrounding landscape, including lush green valleys, cascading waterfalls, and distant mountain ranges. The distinctive rock formation, resembling a toad, adds to the charm of this popular tourist spot. Visitors can enjoy hiking trails, capture breathtaking photographs, and immerse themselves in the serenity of nature at Toad Rock Viewpoint.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                       
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                Mount Abu lacks its own airport. The nearest one is Maharana Pratap Airport in Dabok, Udaipur, approximately 176 kilometers away.    
                            </p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Mount Abu has well-connected roads to Ajmer, Bundi, and Delhi. Self-driving, state transport, and private buses are available for travel.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p> 
                                Mount Abu's railway station is 28 km from the city, connecting Delhi, Mumbai, Jaipur, Pune, Bangalore, Ahmedabad, and Chennai.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/Mount-abu-Map.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT MOUNT ABU</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                  <div class="down">
                    <h3> PLACES TO VISIT NEAR MOUNT ABU</h3>
                    <div class="place">
                    <div><a href="./chittorghar"><img src="/rimages/chittorgarh.jpg" alt="PUSHKAR"></a>
                    <h4>CHITTORGARH</h4>
                    <p>266KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>261KM</p></div>
                        <div><a href="./udaipur"><img src="/rimages/udaipur.jpg" alt="JODHPUR"></a>
                        <h4>UDAIPUR</h4>
                        <p>163KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>




<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {

  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {

  var minimumDuration = 4000;

  
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);


  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>
  </html><?php /**PATH C:\xampp\htdocs\prjct\rajshthan\resources\views/mountabu.blade.php ENDPATH**/ ?>