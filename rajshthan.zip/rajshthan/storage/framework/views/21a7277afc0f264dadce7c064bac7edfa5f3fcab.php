<HTML !doctype>
 <html lang="en">

<head>
  <title>Ajmer</title>
  <link rel="stylesheet" href="./rcss/page.css">
  <link rel="stylesheet" href="./rcss/navbar.css">
 
  
   

</head>


  <header>
    <div class="navbaar" id="topbar">
      <div class="nav-top"></div>
    
    <ul class="navbar">
     <li><a href="/"><img src="https://www.nicepng.com/png/full/17-178841_home-png-home-icon-free.png" alt="home"></li></a>
    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Discover</a>
      <ul class="dropdown-menu">
        <li class="dropdown-submenu">
            <a href="./destination" class="dropdown-toggle">Destination </a>
            <ul class="sub-dropdown-menu">
              <li><a class="dropdown-item" href="./alwar">Alwar</a></li>
              <li><a class="dropdown-item" href="./bharatpur">Bharatpur</a></li>
              <li><a class="dropdown-item" href="./bikaner">Bikaner</a></li>
              <li><a class="dropdown-item" href="./chittorghar">Chittorgarh</a></li>
              <li><a class="dropdown-item" href="./mountabu">Mount Abu</a></li>
              <li><a class="dropdown-item" href="./jaipur">Jaipur</a></li>
              <li><a class="dropdown-item" href="./jaisalmer">Jaisalmer</a></li>
              <li><a class="dropdown-item" href="./jodhpur">Jodhpur</a></li>
              <li><a class="dropdown-item" href="./ajmer">Ajmer</a></li>
              <li><a class="dropdown-item" href="./udaipur">Udaipur</a></li>
            </ul>
            </li>
        <li class="dropdown-submenu">
          <a href="./forts" class="dropdown-toggle">Fort</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#nahargarhfort">Nahargarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaigarhfort">Jaigarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#taragarhfort">Taragarh Fort </a></li>
            <li><a class="dropdown-item" href="./ajmer#kishangarhfort">Kishangarh Fort </a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#neemranafort">Neemrana Fort </a></li>
            <li><a class="dropdown-item" href="./bikaner#junagarhfort">Junagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#chittorgarhfort">Chittorgarh Fort  </a></li>
            <li><a class="dropdown-item" href="./chittorghar#bhainsrorgarhfort">Bhainsrorgarh Fort </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerfort">Jaisalmer Fort </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfort">Mehrangarh Fort  </a></li>
            <li><a class="dropdown-item" href="./jodhpur#khejarlafort">Khejarala Fort </a></li>
            <li><a class="dropdown-item" href="./bharatpur#lohagarhfort">Lohagarh Fort  </a></li>
            <li><a class="dropdown-item" href="./udaipur#kumbhalgarhfort">Kumbhalgarh Fort   </a></li>
            <li><a class="dropdown-item" href="./mountabu#anchalgarhfort">Anchalgarh Fort </a></li>
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./lakes" class="dropdown-toggle">Lake</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#sambharlake">Sambhar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#anasagarlake">Anasagar Lake</a></li>
            <li><a class="dropdown-item" href="./ajmer#lakefoysagar">Lake Foy Sagar </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#gadisarlake">Gadisar Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#kailanalake">Kailana Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./jodhpur#balsamandlake">Balsamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#doodhtalailake">Doodh Talai Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#jaisamandlake">Jaisamand Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#fatehsagarlake">Fateh Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#lakephichola">Lake Phichola</a></li>
            <li><a class="dropdown-item" href="./udaipur#udaisagarlake">Udai Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#amarsagarlake">Amar Sagar Lake</a></li>
            <li><a class="dropdown-item" href="./udaipur#badilake">Badi Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#silliserhlake">Silliserh Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#nakkilake">Nakki Lake</a></li>
            <li><a class="dropdown-item" href="./chittorghar#darbarilake">Darbari Lake</a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./WILDLIFE" class="dropdown-toggle">Wildlife</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./jaipur#jhalanasafaripark">Jhalana Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#nahargarhbilogicalpark">Nahargarh Bilogical Park</a></li>
            <li><a class="dropdown-item" href="./jaipur#ramniwaspark">Ramniwas Gardan</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#akalwoodfosialpark">Akal wood Fosial Park</a></li>
            <li><a class="dropdown-item" href="./jodhpur#machiyasafaripark">Machiya Safari Park</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#desertnationalpark">Desert National Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#sajjangarhbiologicalpark"> Sajjangarh Biological Park</a></li>
            <li><a class="dropdown-item" href="./udaipur#menar"> Menar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kelodeoghananationalpark"> Kelo deo ghana national Park</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bandbarethapark"> Band Baretha Park</a></li>
            <li><a class="dropdown-item" href="./alwar#sariskatigerreserve"> Sariska Tiger Reserve</a></li>
            <li><a class="dropdown-item" href="./chittorghar#bassivillageandwildlife"> Bassi Village and Wildlife </a></li>
          </ul>
        </li>


        <li class="dropdown-submenu">
          <a href="./place" class="dropdown-toggle">Places</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#adhaidinkajhonpada">Adhai Din Ka Jhonpda</a></li>
            <li><a class="dropdown-item" href="./ajmer#sonijikinasiyan">Soniji Ki Nasiyan</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#shahidsmarkajmer">Sahid Smark Ajmer</a></li>
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#victoriyaclocktower">Victoriya Clock Tower</a></li>
            <li><a class="dropdown-item" href="./alwar#balaqila">Bala Qila </a></li>
            <li><a class="dropdown-item" href="./alwar#alwarcitypalace"> Alwar City  Palace</a></li>
            <li><a class="dropdown-item" href="./alwar#moosimaharanikichhatri"> Moosi Maharani ki Chhatri</a></li>
            <li><a class="dropdown-item" href="./alwar#purjanvihar"> Purjan Vihar </a></li>
            <li><a class="dropdown-item" href="./alwar#bhangarh"> Bhangarh</a></li>
            <li><a class="dropdown-item" href="./alwar#motidoongri"> Moti Doongri </a></li>
            <li><a class="dropdown-item" href="./bharatpur#deeg">Deeg</a></li>
            <li><a class="dropdown-item" href="./bharatpur#kaman">Kaman</a></li>
            <li><a class="dropdown-item" href="./bikaner#rampurahaveli">Rampura Haveli</a></li>
            <li><a class="dropdown-item" href="./bikaner#laxmi   ">Laxmi Niwas Palace </a></li>
            <li><a class="dropdown-item" href="./bikaner#raisardunes">Raisar Dunes</a></li>
            <li><a class="dropdown-item" href="./chittorghar#ratansinghpalace">Ratan Singh Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#padmini'spalace">Padmini's Palace   </a></li>
            <li><a class="dropdown-item" href="./chittorghar#ranakumbhapalace"> Rana Kumbha Palace </a></li>
            <li><a class="dropdown-item" href="./chittorghar#jaimalandpatta'spalace"> Jaimal and Patta's Palace </a></li>
            <li><a class="dropdown-item" href="./jaipur#amberpalace"> Amber  Palace  </a></li>
            <li><a class="dropdown-item" href="./jaipur#citypalacejaipur"> City Palace</a></li>
            <li><a class="dropdown-item" href="./jaipur#hawamahal"> Hawa Mahal </a></li>
            <li><a class="dropdown-item" href="./jaipur#madhvendrapalace,nahargarh"> Madhvendra Palace, Nahargarh </a></li>
            <li><a class="dropdown-item" href="./jaipur#amarjavanjyoti"> Amar Javan Jyoti </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#nathmaljikihaveli"> Nathmal Ji Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#mandirpalace">Mandir Palace  </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#laungewalawarmemorial">Laungewala War Memorial</a></li>
            <li><a class="dropdown-item" href="./jodhpur#umaidbhawanpalace">Umaid Bhawan Palace</a></li>
            <li><a class="dropdown-item" href="./udaipur#thecrystalgallery">The Crystal Gallery</a></li>
            <li><a class="dropdown-item" href="./udaipur#bagorekihaveli">Bagore Ki Haveli</a></li>
            <li><a class="dropdown-item" href="./jodhpur#ranisarpadamsar">Ranisar Padamsar </a></li>
            <li><a class="dropdown-item" href="./jodhpur#phoolmahal">Phool Mahal </a></li>
            <li><a class="dropdown-item" href="./jodhpur#motimahal">Moti Mahal   </a></li>
            <li><a class="dropdown-item" href="./udaipur#citypalaceudaipur"> City Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#monsoonpalace"> Monsoon Palace </a></li>
            <li><a class="dropdown-item" href="./udaipur#shilpgram"> Shilpgram </a></li>
            <li><a class="dropdown-item" href="./mountabu#gurushikhar"> Guru Shikhar</a></li>
            <li><a class="dropdown-item" href="./mountabu#toadrockviewpoint"> Toad Rock View Point </a></li>
            
          </ul>
        </li>
        
        <li class="dropdown-submenu">
          <a href="./museum" class="dropdown-toggle">Museum</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#ajmergovernmentmuseum">Ajmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./alwar#govtmuseumalwar">Govt Museum Alwar</a></li>
            <li><a class="dropdown-item" href="./bharatpur#bharatpurpalaceandmuseum">Bharatpur Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#lalgarhpalaceandmuseum">Lalgarh Palace and Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#gangagovernmentmuseum">Ganga Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./bikaner#prachinamuseum">Prachina Museum</a></li>
            <li><a class="dropdown-item" href="./chittorghar#fatehprakashpalace">Fateh Prakash Palace (Govt. Museum) </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumonpoliticalnarratives"> Musuem on Political Narratives</a></li>
            <li><a class="dropdown-item" href="./jaipur#museumoflegacies"> Museum of  Legacies</a></li>
            <li><a class="dropdown-item" href="./jaipur#amrapalimuseum"> Amrapali Museum </a></li>
            <li><a class="dropdown-item" href="./jaipur#museumofgemandjewellary"> Museum of Gem and Jewellary </a></li>
            <li><a class="dropdown-item" href="./jaipur#jaipurwaxmuseum"> Jaipur wax Museum</a></li>
            <li><a class="dropdown-item" href="./jaipur#anokhimuseumofhandprinting">Anokhi Museum of  Hand Printing </a></li>
            <li><a class="dropdown-item" href="./jaipur#alberthallmuseum">Albert Hall Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmergovtmuseum">Jaisalmer Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#jaisalmerwarmuseum">Jaisalmer War Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#jodhpurgovtmuseum">Jodhpur Govt. Museum</a></li>
            <li><a class="dropdown-item" href="./jodhpur#mehrangarhfortandmuseum">Mehrangarh Fort and Museum </a></li>
            <li><a class="dropdown-item" href="./udaipur#aharmuseum">Ahar Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#waxmuseum"> Wax Museum  </a></li>
            <li><a class="dropdown-item" href="./udaipur#vintagecarcollection"> Vintage Car Collection  </a></li>
           
          </ul>
        </li>
        <li class="dropdown-submenu">
          <a href="./RELIGIOUS" class="dropdown-toggle">Religions Palace</a>
          <ul class="sub-dropdown-menu">
            <li><a class="dropdown-item" href="./ajmer#pragyashikhartodgarh">Pragya Shikhar Todgarh</a></li>
            <li><a class="dropdown-item" href="./ajmer#narelijaintemple">Nareli Jain Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#saibabatemple">Sai Baba Temple</a></li>
            <li><a class="dropdown-item" href="./ajmer#theajmesharifdargah">The Ajme Sharif  Dargah</a></li>
            <li><a class="dropdown-item" href="./alwar#narainimata">Naraini Mata </a></li>
            <li><a class="dropdown-item" href="./alwar#neelkanth">Neelkanth </a></li>
            <li><a class="dropdown-item" href="./alwar#bhartriharitemple">Bhartrihari Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#tijarajaintemple"> Tijara Jain Temple</a></li>
            <li><a class="dropdown-item" href="./alwar#pandupol"> Pandu Pol</a></li>
            <li><a class="dropdown-item" href="./bharatpur#laxmanmandir"> Laxman Mandir</a></li>
            <li><a class="dropdown-item" href="./bharatpur#gangamandir"> Ganga Mandir </a></li>
            <li><a class="dropdown-item" href="./bikaner#jaintemplebhandarsar"> Jain Temple Bhandarsar </a></li>
            <li><a class="dropdown-item" href="./bikaner#deshnokkarnimatatemple">Deshnok Karni Mata Temple </a></li>
            <li><a class="dropdown-item" href="./chittorghar#sanwaliyajitemple">Sanwaliya Ji Temple</a></li>
            <li><a class="dropdown-item" href="./chittorghar#meerabaitemple">Meera Bai Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#jagatshiromanitemple">Jagat Shiromani Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#akshardhamtemple">Akshar Dham Temple</a></li>
            <li><a class="dropdown-item" href="./jaipur#galtaji">Galtaji </a></li>
            <li><a class="dropdown-item" href="./jaipur#motidoongriganeshtemple"> Moti Doongri Ganesh Temple  </a></li>
            <li><a class="dropdown-item" href="./jaipur#govinddevjitemple"> Govind Devji Temple </a></li>          
            <li><a class="dropdown-item" href="./jaipur#birlatemple"> Birla Temple </a></li>
            <li><a class="dropdown-item" href="./jodhpur#mandaleshwarmahadev"> Mandaleshwar Mahadev </a></li>
            <li><a class="dropdown-item" href="./jodhpur#chamundamatajitemple">Chamunda Mataji Temple </a></li>
            <li><a class="dropdown-item" href="./jaisalmer#tanotmatatemple">Tanot Mata Temple</a></li>
            <li><a class="dropdown-item" href="./jaisalmer#ramdevratemple">Ramdevra Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#jagdishtemple">Jagdish Temple</a></li>
            <li><a class="dropdown-item" href="./udaipur#sahastrabahutemple">Sahastrabahu Temple</a></li>
            <li><a class="dropdown-item" href="./mountabu#dilwarajaintemple">Dilwara Jain Temple </a></li>
          </ul>
        </li> 
      </ul>
      


    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Experience</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="/fair and festival " class="dropdown-toggle">Fairs & Festivals  </a>
            </li>
            <li class="dropdown-submenu">
            <li class="dropdown-submenu">
          <a href="/culture " class="dropdown-toggle">Culture Of Rajsthan  </a>
          </li>
          <li class="dropdown-submenu">
          <a href="/foods" class="dropdown-toggle">Food Of Rajsthan  </a>
          </li>
            <a href="./adventures" class="dropdown-toggle">Adventures </a>
      </ul>
    </li>


    <li class="dropdown">
      <a href="#" class="dropdown-toggle ">Plan</a>
      <ul class="dropdown-menu">
         <li class="dropdown-submenu">
            <a href="./besttime to visit" class="dropdown-toggle">Best Time to Visit  </a>
            </li>
            <a href="./forgin" class="dropdown-toggle dropdown-toggle2">Foreign Tourists</a>
            <a href="./SUGGESTED ITINERARIES" class="dropdown-toggle dropdown-toggle2">Suggested ltineraries</a>
      </ul>
    </li>
    

    <li class="dropdown-toggle"><a href="/aboutus">About Us</a></li>
    <li class="dropdown-toggle "><a href="./home">Login</a></li>
   
  </ul>
  
    <!-- <li class="dropdown-toggle navbar-right"><a href="./contact">Account</a></li> -->
  
</div>
<script>
    window.addEventListener('DOMContentLoaded', function () {
  var dropdowns = document.getElementsByClassName('dropdown');
  for (var i = 0; i < dropdowns.length; i++) {
    dropdowns[i].addEventListener('mouseover', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'block';
    });
    dropdowns[i].addEventListener('mouseout', function () {
      this.getElementsByClassName('dropdown-menu')[0].style.display = 'none';
    });
  }
});


</script>
</header>
  <!-- <header> -->
    <!-- place navbar here -->
    <!-- <div id="navbar-placeholder"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(function() {
        $("#navbar-placeholder").load("navbar");
      });
    </script> -->
  <!-- <div id="navbar-placeholder"></div>

  <script>
    fetch('navbar')
      .then(response => response.text())
      .then => {
        document.getElementById('navbar-placeholder').innerHTML =;
      });
  </script>
   -->

<body>
<!-- loader -->
<div id="loader">
  <div class="loader-spinner"></div>
</div>
<script>document.addEventListener("DOMContentLoaded", function() {
  // Show loader
  document.getElementById("loader").style.display = "flex";
});

window.addEventListener("load", function() {
  // Add a minimum duration for the loader (in milliseconds)
  var minimumDuration = 4000;

  // Calculate the time remaining until the minimum duration is reached
  var currentTime = new Date().getTime();
  var pageLoadTime = currentTime - window.performance.timing.navigationStart;
  var timeRemaining = Math.max(0, minimumDuration - pageLoadTime);

  // Hide loader after the minimum duration
  setTimeout(function() {
    document.getElementById("loader").style.display = "none";
  }, timeRemaining);
});

</script>






<!-- main -->
  <main>
    <div class="container-fluid front " style="background-image: url(https://www.adotrip.com/public/images/city/5c3f069ac90c0-Ajmer%20Package%20Tour.jpg);">
      <h1 class="home"> AJMER </h1>
      <h3 class="home1">JAIN TEMPLE</h3>
    </div>

    <div class="history">
      <div class="title">
        <h1>Ajmer </h1>
          <h2>Heart of Rajasthan</h2>
          </div>
          <div class="conte">
            <p>
                Ajmer is a historic city located in the state of Rajasthan, India. It holds immense cultural, religious, and historical significance. Nestled amidst the Aravalli Mountains, Ajmer is best known for being the home of the famous Ajmer Sharif Dargah, the shrine of Sufi saint Khwaja Moinuddin Chishti. The dargah attracts millions of devotees from different faiths, who come seeking blessings and to experience the spiritual ambiance.

                Apart from its religious importance, Ajmer is also famous for its splendid architecture and historical landmarks. The magnificent Taragarh Fort, built in the 7th century, offers panoramic views of the city and showcases the rich Rajputana heritage. The Ana Sagar Lake, built by Emperor Anaji Chauhan, is another popular attraction where visitors can enjoy boating and relax amidst the serene surroundings.</p><p>

                    Ajmer is also known for its educational institutions, including the renowned Mayo College, one of the country's oldest and prestigious boarding schools. The city has a vibrant and colorful market where one can find traditional Rajasthani handicrafts, textiles, and jewelry.
                  </p><p>
                    The annual Urs festival at the Ajmer Sharif Dargah is a major event that draws pilgrims and tourists from far and wide. It is a celebration of the saint's life and teachings, with qawwali performances and a festive atmosphere.
                </p><p>
                Ajmer encapsulates the essence of Rajasthan's rich history, spirituality, and architectural grandeur, making it a must-visit destination for travelers seeking a glimpse into India's cultural tapestry.
                </p>
            </div>
          </div>


                        <div class="part2">
                            <div class="title2">
                                <h2>
                                    ATTRACTIONS & PLACES TO VISIT AND EXPLORE IN AJMER
                                </h2>
                            </div>
                                    <div class="list">
                                        <ul>
                                          <li>
                                          <div> <img src="https://www.dargahkhwajagharibnawaz.com/images/newgal2019/lighting1.jpeg" alt=""  class="c"></div></li>     
                                          <div class="paragraph">
                                        <li><h1 id="theajmersharifdargah">THE AJMER SHARIF DARGAH</h1></li>
                                        <li><p>The Ajmer Sharif Dargah is a renowned Sufi shrine located in Ajmer, Rajasthan, India. It is the final resting place of the Sufi saint Khwaja Moinuddin Chishti and is considered one of the holiest Muslim shrines in the country. Devotees from various faiths visit the dargah to seek blessings and fulfill their wishes. The dargah's mystical aura and the atmosphere of devotion make it a significant spiritual destination in India.</p></li>
                                          </div>  
                                  </ul>

                                    <ul>
                                      <li> <img src="https://www.erajasthantourism.net/wp-content/uploads/2019/01/adhai-din-ka-jhopra.jpg" alt=""  class="c"></li>
                                        <div class="paragraph">
                                        <li><h1 id="adhaidinkajhonpda">ADHAI DIN KA JHONPDA</h1></li>
                                        <li><p>Adhai Din Ka Jhonpda is a historical monument located in Ajmer, Rajasthan, India. Built during the reign of Sultan Alauddin Khilji, it was originally a Sanskrit college that was converted into a mosque in just two and a half days. The structure is known for its intricate architecture, including beautifully carved pillars, arches, and screens. Adhai Din Ka Jhonpda is a fascinating blend of Hindu and Islamic architectural styles, reflecting the cultural and artistic heritage of the region. It is a popular attraction among history enthusiasts and tourists visiting Ajmer.</p></li>
                                        </div>  
                                    </ul>
                                </div>


                                <div class="list">
                                  <ul>
                                    <li>
                                    <div> <img src="https://i.pinimg.com/originals/84/1a/35/841a35f75e5023bed73dda6ab54bd4ca.jpg" alt=""  class="c"></div></li>     
                                    <div class="paragraph">
                                  <li><h1 id="mayocollege">MAYO COLLEGE</h1></li>
                                  <li><p>Mayo College is a prestigious boarding school located in Ajmer, Rajasthan, India. Established in 1875, it is one of the oldest and most renowned educational institutions in the country. Mayo College follows the British public school system and provides education from grades 4 to 12. The college campus boasts impressive colonial-era architecture, sprawling grounds, and excellent facilities. Known for its academic excellence and emphasis on all-round development, Mayo College has produced many distinguished alumni who have excelled in various fields. It is considered a symbol of educational heritage in India.</p></li>
                                    </div>  
                                  </ul>

                                   <ul>
                                    <li> <img src="https://www.tourism-rajasthan.com/wp-content/uploads/2019/05/Taragarh-Fort-Ajmer-Rajasthan-2.jpg" alt=""  class="c"></li>
                                  <div class="paragraph">
                                  <li><h1 id="taragarhfort">TARAGARH FORT</h1></li>
                                  <li><p>Taragarh Fort, also known as the Star Fort, is a historic fortress located in Ajmer, Rajasthan, India. Built in the 14th century, it stands atop the Nagpahari Hill and offers breathtaking views of the city. The fort is known for its impressive architecture, with massive walls, towers, and gates. Inside, visitors can explore various structures, including the Bhim Burj, a cannon platform, and the Rani Mahal, a palace with beautiful frescoes. Taragarh Fort is not only a historical landmark but also a popular tourist attraction, offering a glimpse into the region's rich Rajputana history and providing panoramic vistas.</p></li>
                                  </div>  
                              </ul>
                          </div>



                            

                            <div class="list">

                                <ul>
                                  <li> <img src="https://th.bing.com/th/id/R.a49f44668017c3406c826df868cc9f7c?rik=aes5KXJVQSrKXg&riu=http%3a%2f%2fedge.ixigo.com%2fimg%2fana-sagar-lake-images-photos-513efd18e4b02898ecace765.jpg&ehk=b33tDP%2f2KX%2bDSw%2b8v9ZeYm9E8Y1vLzZjmpC2HFb4lXQ%3d&risl=&pid=ImgRaw&r=0" alt=""  class="c"></li>
                                    <div class="paragraph">
                                <li><h1 id="anasagarlake">ANASAGAR LAKE</h1></li>
                                <li><p>Anasagar Lake is a picturesque artificial lake located in Ajmer, Rajasthan, India. Constructed by King Anaji Chauhan in the 12th century, it is a popular tourist attraction and a serene oasis in the city. Spread over a vast area, the lake is surrounded by lush gardens, marble pavilions, and beautiful marble steps known as 'baradaris'. Visitors can enjoy boating on the lake's calm waters and relish the tranquility of the surroundings. The Anasagar Lake offers a peaceful escape from the bustling city and provides a scenic setting for leisurely walks and picnics.</p></li>
                                    </div>
                                
                            </ul>

                            <ul>
                              <li> <img src="https://th.bing.com/th/id/R.72246e7dfc69ae74fe9d03a8c5b4be92?rik=WNN9sRt3uLHrEw&riu=http%3a%2f%2f2.bp.blogspot.com%2f-EuAMMi3-KFc%2fUTjbE6zxmgI%2fAAAAAAAAXPw%2ftWeFY6AWWts%2fs1600%2fSoni-ji-ki-nasiyan-ajmer.jpg&ehk=qTvW9u%2b2Eizyk%2fu0OTYkTDQZT%2bbc6XYzoYF6BaIv%2bdw%3d&risl=&pid=ImgRaw&r=0" alt="" class="c"></li>
                                <div class="paragraph">
                                <li><h1 id="sonijikinasiyan">SONIJI KI NASIYAN </h1></li>
                                <li><p>Soniji Ki Nasiyan, also known as Ajmer Jain Temple or Red Temple, is a famous Jain temple located in Ajmer, Rajasthan, India. It is dedicated to Lord Rishabhdev, the first Jain Tirthankara. The temple is renowned for its stunning architecture and intricate carvings. The main attraction is the Swarna Nagari (Golden City), a hall adorned with gold-plated wooden figures depicting various scenes from Jain mythology. The temple also houses a museum that exhibits a collection of Jain artifacts, manuscripts, and ancient artifacts, providing insight into Jainism and its rich cultural heritage.</p></li>
                                </div>
                                
                            </ul>
                        </div>
                        
                        <div class="list">
                            <ul>
                              <li> <img src="https://img.veenaworld.com/wp-content/uploads/2019/07/Foy-Sagar-Lake.jpg?imwidth=1080" alt=""  class="c"></li>
                                <div class="paragraph">
                            <li><h1 id="lakefoysagar">LAKE FOY SAGAR</h1></li>
                            <li><p>TLake Foy Sagar is a serene and scenic artificial lake located on the outskirts of Ajmer, Rajasthan, India. Built in 1892 by the English engineer Mr. Foy, it was constructed as a means to combat famine and provide employment during that period. The lake offers breathtaking panoramic views, with the Aravalli Hills as a backdrop. Visitors can enjoy the tranquility of the surroundings, indulge in picnics, and capture stunning sunset views. Lake Foy Sagar is a popular spot for locals and tourists alike, providing a peaceful retreat away from the city's hustle and bustle.</p></li>
                                </div>
                            
                        </ul>
                        <ul>
                          <li> <img src="https://i.pinimg.com/originals/b9/19/1b/b9191b062ffd4ecc39b4850e9eeb77b7.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                            <li><h1 id="narelijaintemple">NARELI JAIN TEMPLE</h1></li>
                            <li><p>Nareli Jain Temple, also known as Shri Gyanshwar Tirth, is a magnificent Jain temple located near Ajmer, Rajasthan, India. Situated on a hill, it offers stunning views of the surrounding landscape. The temple complex is an architectural marvel, featuring intricate marble carvings and intricate designs. The main deity worshipped here is Lord Adinath, the first Jain Tirthankara. Visitors can explore the temple's intricate corridors, prayer halls, and gardens. Nareli Jain Temple is not only a religious site but also a serene and peaceful place for spiritual seekers and nature lovers.</p></li>
                            </div>
                           
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                          <li> <img src="https://wirally.com/wp-content/uploads/2016/01/sai-baba-1068x601.jpg" alt=""  class="c"></li>
                            <div class="paragraph">
                        <li><h1 id="saibabatemple">SAI BABA TEMPLE</h1></li>
                        <li><p>Spread over an area of over five bheegas (or over two acres) at Ajay Nagar, the Sai Baba Temple in Ajmer was constructed by Suresh K Lal, a resident of the Garib Nawaz City in 1999. It’s one of the most recent pieces of architecture and is very popular among all Sai Baba devotees. The temple is built with the purest form of marble that possesses the unique quality of a translucent stone, allowing light to pass through it. Every Sai Baba disciple should definitely visit this shrine once in their lifetime.</p></li>
                            </div>
                       
                    </ul>
                    <ul>
                      <li> <img src="https://img.theculturetrip.com/768x/wp-content/uploads/2019/04/p3wrjp.jpg" alt=""  class="c"></li>
                        <div class="paragraph">
                        <li><h1 id="ajmergovernmentmuseum">AJMER GOVERNMENT MUSEUM</h1></li>
                        <li><p>The Ajmer Government Museum is a notable museum located in Ajmer, Rajasthan, India. It houses a diverse collection of artifacts that showcase the rich cultural and historical heritage of the region. The museum exhibits a wide range of artifacts, including ancient sculptures, miniature paintings, arms and armor, coins, textiles, and archaeological finds. Visitors can explore the various galleries and learn about the history, art, and archaeology of Ajmer and its surrounding regions. The Ajmer Government Museum serves as a valuable resource for preserving and showcasing the cultural legacy of the area.</p></li>
                        </div>
                       
                    </ul> 
                    

                </div>
                <div class="list">
                    <ul>
                      <li> <img src="https://www.holidify.com/images/cmsuploads/compressed/36748401_10156756299387176_5685740580471046144_o_20200422130144.jpg" alt=""  class="c"></li>
                        <div class="paragraph">
                    <li><h1 id="kishangarhfort">KISHANGARH FORT</h1></li>
                    <li><p>Taragarh Fort, also known as the Star Fort, is a historic fortress located in Ajmer, Rajasthan, India. Built in the 14th century, it stands atop the Nagpahari Hill and offers breathtaking views of the city. The fort is known for its impressive architecture, with massive walls, towers, and gates. Inside, visitors can explore various structures, including the Bhim Burj, a cannon platform, and the Rani Mahal, a palace with beautiful frescoes. Taragarh Fort is not only a historical landmark but also a popular tourist attraction, offering a glimpse into the region's rich Rajputana history and providing panoramic vistas.</p></li>
                        </div>
                   
                </ul>
                <ul>
                  <li> <img src="https://th.bing.com/th/id/R.7a62f766a77678f259292ef92d79bd68?rik=CSw%2fAHFmAHXV5A&riu=http%3a%2f%2fwww.theuntourists.com%2fwp-content%2fuploads%2f2015%2f02%2fDSCF3341.jpg&ehk=b6qzytynYzGsldtMoCRYgh4t92XcDYPelL9YgTZwTqI%3d&risl=&pid=ImgRaw&r=0" alt=""  class="c"></li>
                    <div class="paragraph">
                    <li><h1 id="pragyashikhartodgarh">PRAGYA SHIKHAR TODGARH</h1></li>
                    <li><p>Built by the Jain community in 2005 in the memory of Jain Acharya Tulsi, Pragya Shikhar is a temple made completely out of black granite. It is located in Todgarh, which is a scenic village set in the Aravalis. Dr. APJ Abdul Kalam inaugurated it, and it was erected by an NGO. Pragya Shikhar is a serene place which one should definitely visit to revel in the peaceful environment of the temple. Other places to see in Todgarh & around are Old C.N.I. Church, Katar Ghati, Dudhaleshwar Mahadev, Bheel beri,& Raoli-Todgarh wild life Sanctuary.</p></li>
                    </div>
                   
                </ul> 
                

            </div>
            <div class="list">
                <ul>
                  <li> <img src="https://img.veenaworld.com/wp-content/uploads/2019/07/Prithviraj-Smarak.jpg?imwidth=1080" alt=""  class="c"></li>
                    <div class="paragraph">
                <li><h1 id="">PRITHVI RAJ SMARAK</h1></li>
                <li><p>Prithvi Raj Smarak, also known as Prithviraj Memorial, is a memorial dedicated to the legendary Rajput king Prithviraj Chauhan, located in Ajmer, Rajasthan, India. It commemorates the bravery and valor of Prithviraj Chauhan, who ruled over the region during the 12th century. The memorial features a grand statue of Prithviraj Chauhan on his horse, showcasing his warrior spirit. It serves as a reminder of the rich history and glorious past of the Rajputana dynasty. Prithvi Raj Smarak stands as a tribute to one of the iconic figures in Indian history and attracts visitors interested in Rajput heritage.</p></li>
                    </div>
               
            </ul>
            <ul>
              <li> <img src="https://live.staticflickr.com/5761/22479737377_63975f04f8_b.jpg" alt=""  class="c"></li>
                <div class="paragraph">
                <li><h1 id="anasagarbaradari">ANASAGAR BARADARI</h1></li>
                <li><p>Anasagar Baradari is a magnificent pavilion situated on the banks of Anasagar Lake in Ajmer, Rajasthan, India. The term "baradari" refers to a building with twelve doors or arches. Built by Emperor Shah Jahan in the 17th century, the Anasagar Baradari is an architectural marvel featuring twelve beautifully crafted arches. The pavilion offers stunning views of the lake and the surrounding landscape. It serves as a serene and picturesque spot for visitors to relax, enjoy the scenic beauty, and immerse themselves in the tranquility of the surroundings.</p></li>
                </div>
               
            </ul> 
            

        </div>
        <div class="list">
            <ul>
              <li> <img src="https://thumbs.dreamstime.com/b/ouside-view-ajmer-junction-railway-station-market-clock-tower-hills-ouside-view-ajmer-junction-railway-station-market-215187814.jpg" alt=""  class="c"></li>
                <div class="paragraph">
            <li><h1 id="victoriaclocktower">VICTORIA CLOCK TOWER</h1></li>
            <li><p>The Victoria Clock Tower, also known as the Ajmer Clock Tower, is an iconic landmark located in the heart of Ajmer, Rajasthan, India. Built in the 19th century, the clock tower is a fine example of British colonial architecture. It stands tall as a symbol of Ajmer's historical significance and cultural heritage. The tower features a beautiful clock face and intricate designs. The Victoria Clock Tower serves as a prominent meeting point and a beloved spot for locals and tourists to gather and admire the city's charm.</p></li>
                </div>
           
        </ul>
        <ul>
          <li> <img src="https://qph.fs.quoracdn.net/main-qimg-4ab66abeaef17c788078819484d53e5f" alt=""  class="c"></li>
            <div class="paragraph">
            <li><h1 id="shahidsmarkajmer">SHAHID SMARAK, AJMER</h1></li>
            <li><p>Shahid Smarak, located in Ajmer, Rajasthan, is a memorial dedicated to the brave soldiers who sacrificed their lives for the nation. The memorial stands as a tribute to the martyrs and serves as a reminder of their valor and patriotism. It is a solemn place where visitors can pay their respects and reflect on the sacrifices made by the soldiers. Shahid Smarak also acts as a symbol of national pride and unity, inspiring visitors with a sense of gratitude and admiration for the armed forces.</p></li>
            </div>
           
        </ul> 
        

    </div>
                </div>
                

                       <div class="visit">
                        <div class="left">
                        <h2>How to reach here</h2>
                        
                        <ul>
                          <li>
                            <span>
                            <img src="https://www.titan-airways.com/wp-content/uploads/2019/12/plane-icon.png" alt="">
                            <p>
                                 The nearest airport is Kishangarh Airport, which is about 30 kilometres away and helps Ajmer remain well-connected with major Indian cities. One can easily pre-book a cab or hire one from the taxi stands outside the airport. The journey will take around 39 mins.                            </p>
                          </span>
                          </li>
                          <li>
                           
                            <span>
                              <img src="https://th.bing.com/th/id/OIP.JE5oBM2d5Qx4lhAcJd1-RgAAAA?pid=ImgDet&rs=1" alt="">
                              
                               <p>Buses from the state capital and from other cities also ply to Ajmer regularly. Government run buses run between Jaipur and Ajmer throughout the day. Private operators also ply on the route. There are also less-frequent coach services running between Ajmer and Delhi. One can also use the cloakroom at the main bus stand.
                          </p> </span>
                          </li>
                          <li>
                            
                            <span>
                              <img src="https://rail.nridigital.com/rail/future_rail_australia_nov18/australian_high_speed_rail/178672/train.480_0_1.png" alt="">
                              <p> Ajmer is located on the Delhi-Jaipur-Marwar-Ahmedabad-Mumbai railway line. It is well connected by rail as most trains on this route halt at Ajmer.
                            </p>
                              </span>
                          </li>
                        </ul>
                        </div>

                        <div class="right">
                          <img src="https://www.tourism.rajasthan.gov.in/content/dam/rajasthan-tourism/english/city/map/1.png" alt="">
                        </div>
                      </div>

                       </div>
              <div class="visitlast">
                  <div class="up">
                    <h2>WANT TO VISIT AJMER</h2>
                    <button><a href="/home" class="trip">PLAN YOUR TRIP</a></button>
                  </div>
                

                    <div class="down">
                    <h3> PLACES TO VISIT NEAR AJMER</h3>
                    <div class="place">
                    <div><a href="./ajmer"><img src="/rimages/pushkar.jpg" alt="PUSHKAR"></a>
                    <h4>PUSHKAR</h4>
                    <p>17KM</p></div>
                    <div><a href="./jodhpur"><img src="/rimages/jodhpur.jpg" alt="JODHPUR"></a>
                        <h4>JODHPUR</h4>
                        <p>207KM</p></div>
                        <div><a href="./jaipur"><img src="/rimages/jaipur.jpg" alt="JODHPUR"></a>
                        <h4>JAIPUR</h4>
                        <p>132KM</p></div>
                    </div>
                    </div>
              </div>      

  <!-- Bootstrap JavaScript Libraries -->


  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"> -->
  </script>
</body>
<footer>
  <div id="footer-placeholder"></div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(function() {
      $("#footer-placeholder").load("footer");
    });
    </script>
    </footer>
  </html><?php /**PATH C:\xampp\htdocs\prjct\rajshthan\resources\views/ajmer.blade.php ENDPATH**/ ?>